import { useEffect } from "react";

const useRefresh = ({ history, path, resetRoute }) => {
  let handler;
  const refresh = () => {
    history.push(resetRoute);
    handler = setTimeout(() => history.push(path), 10);
  };
  useEffect(() => {
    return () => handler && clearTimeout(handler);
  }, [handler]);
  return refresh;
};
// Hook Usage//
// const location = useLocation();
// const history = useHistory();
// const refresh = useRefresh(location, redirectPath);

// const handleSuccess = () => {
//   if (location.pathname === redirectPath) {
//     refresh();
//   } else {
//     history.push(redirectPath);
//   }
// };
// useEffect(() => {
//   handleSuccess();
// }, []);
export default useRefresh;
