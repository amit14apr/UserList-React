import React from "react";
import { AnimatePresence } from "framer-motion";
import { Routes, Route, useLocation, Switch, useRoutes } from "react-router-dom";
import Home from "./pages/Home";
import DiaStructure from "./pages/DiaStructure";
//import DiaTeam from "./pages/DiaTeam";
import AvailableResource from "./pages/availableResources";
// import AvailableResource from "./pages/AvailableResources"
import System from "./pages/System";
import SolutionPortfolio from "./pages/SolutionPortfolio";
import AnalyticsRequest from "./pages/AnalyticsRequest";
import SolutionPortfoliol4 from "./pages/SolutionPortfolio/l4";
import MissionContent from "./pages/MissionContent/MissionContent";

function AnimatedRoutes() {
  const element = useRoutes([
    { path: "/data-innovation-analytics/homepage", element: <Home/> },
    { path: "/data-innovation-analytics/:slug/:slug",
      element: <SolutionPortfolio/>,
      // children: [
      //   { path: ":slug", element: <SolutionPortfoliol4/> }
      // ],
    },
    { path: "/data-innovation-analytics/solutionPortfolio/:slug/:slug",
      element: <SolutionPortfoliol4/>,
      children: [
        { path: ":slug", element: <SolutionPortfoliol4/> }
      ],
    },
    { path: "/data-innovation-analytics/dia-structure", element: <DiaStructure/> },
    { path: "/data-innovation-analytics/available-data-sources", element: <AvailableResource/> },
    { path: "/data-innovation-analytics/systems", element: <System/> },
    { path: "/data-innovation-analytics/systems/:slug", element: <System/> },
    { path: "/data-innovation-analytics/analytics-request", element: <AnalyticsRequest/> },
    { path: "/data-innovation-analytics/mission/know-more", element: <MissionContent />},
    { path: "*", element: <Home/>}
  ]);
  return element;
  // return (
  //   <AnimatePresence initial={false}>
  //     <Routes location={location} key={location.pathname}>
  //       <Route path="/" element={<Home />} />
  //       <Route path="/data-innovation-analytics/dia-structure" element={<DiaStructure />} />
  //       <Route path="/data-innovation-analytics/available-data-sources" element={<AvailableResource />} />
  //       <Route path="/data-innovation-analytics/systems/:slug" element={<System />} />
  //       <Route path="/data-innovation-analytics/:slug" element={<SolutionPortfolio />} />
  //       <Route path="/data-innovation-analytics/solutions-portfolio/l4/:id" element={<SolutionPortfoliol4 />} />
  //       <Route path="/data-innovation-analytics/analytics-request" element={<AnalyticsRequest />} />
  //       <Route path="*" element={<Home />} />
  //     </Routes>
  //   </AnimatePresence>
  // );
}

export default AnimatedRoutes;
