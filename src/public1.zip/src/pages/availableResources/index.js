import React, { useEffect, useContext } from "react";
import PageTransition from "../../components/ui/Animations/PageTransition";
import Slide from "../../components/ui/Animations/Slide";
import HeroBanner from "../../components/ui/HeroBanner";
import {
  AvailableSourcesContext,
  AvailableSourcesProvider,
} from "./AvailableSourcesContext";
import DataSystemSection from "./dataSystemSection";
import AccountAccessSection from "./accountAccessSection";
import SolutionsOfferedSection from "./solutionsOfferedSection";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import useFetch from "../../hooks/useFetch";
const AvailableResources = () => {
  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}availabledatasources/11`
  );
  return (
        <section className="content-section">
          <HeroBanner
            title={data?.data?.banners[0]?.bannername}
            subTitle={data?.data?.banners[0]?.bannerdescription}
            imgSrc={data?.data?.banners[0]?.bannerimage}
            shape="box"
            variant="slide-down-boxes"
          />
          {/* <Slide delay={0.3}>
            <> */}
              <SolutionsOfferedSection data={data?.data?.solutions}/>
            {/* </>
          </Slide> */}
          {/* <Slide delay={0.5}>
            <> */}
              <AccountAccessSection data={data?.data?.systems}/>
            {/* </>
          </Slide>
          <Slide delay={0.5}>
            <> */}
              <DataSystemSection data={data?.data?.softwares}/>
            {/* </>
          </Slide> */}
        </section>
  );
};

export default AvailableResources;
