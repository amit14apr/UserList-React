import React, { useContext } from "react";

const AccountAccessSection = ({data}) => {
  return (
    <div className="accountAccessSection">
      <div className="contentWrap">
        <div className="accountAccessWrap">
          <h3>Systems We Use</h3>
          <div className="accountAccessList">
            {data?.map((item, i) => <div className="accountAccessGroup">
              <h4>{item.title}</h4>
              <h5>Service Account Access</h5>
              <ul>
                {item.serviceaccountaccess.split(',').map((el, i) => <li key={i}>{el}</li>)}
              </ul>
            </div>)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountAccessSection;
