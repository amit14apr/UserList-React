import React, { useContext } from "react";
import { AvailableSourcesContext } from "./AvailableSourcesContext";

const SolutionsOfferedSection = ({data}) => {
  // const { responseData } = useContext(AvailableSourcesContext);
  return (
    <div className="solutionsOfferedSection">
      <div className="contentWrap">
        <div className="offeredWrap">
          <h3>Digital Solutions Offered</h3>
          <ul className="offeredList">
            {data?.map((item, i) => <li key={i}>
              <div className="solutionsItem">
                <div className="solutionsItem-icon">
                  <img
                    alt="#"
                    src={item.imagepath}
                  />
                </div>
                <div className="solutionsItem-title">
                  <h4>{item.title}</h4>
                  <p>{item.description}</p>
                </div>
              </div>
            </li>)}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SolutionsOfferedSection;
