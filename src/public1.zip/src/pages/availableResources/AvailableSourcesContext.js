import React, { createContext, useState } from "react";

export const AvailableSourcesContext = createContext();

export const AvailableSourcesProvider = ({ children }) => {
  const [responseData, setResponseData] = useState([]);
  return (
    <AvailableSourcesContext.Provider value={{ responseData, setResponseData }}>
      {children}
    </AvailableSourcesContext.Provider>
  );
};
