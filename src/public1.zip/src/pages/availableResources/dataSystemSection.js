import React, { useContext } from "react";
import { AvailableSourcesContext } from "./AvailableSourcesContext";

const DataSystemSection = ({ data }) => {
  // const { responseData } = useContext(AvailableSourcesContext);
  return (
    <div className="dataSystemSection">
      <div className="contentWrap">
        <div className="dataSystemWrap">
          <h3>Systems and Softwares</h3>
          <ul className="dataSystemList">
           {data?.map((item, i) => <li>
              <div className="dataSystemItem">
                <div className="dataSystemItem-icon">
                  <img
                    alt="#"
                    src={item.uploadthumbnail}
                  />
                </div>
                <div className="dataSystemItem-text">
                  <p>
                   {item.description}
                  </p>
                </div>
              </div>
            </li>) }
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DataSystemSection;
