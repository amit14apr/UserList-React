import React from "react";
import HeroBanner from "../../components/ui/HeroBanner";
import DigitalDictionaryBG from "../../assets/img/page_banners/digital_bg.png";
import DictionarySection from "./dictionarySection";
import PageTransition from "../../components/ui/Animations/PageTransition";

const DigitalDictionary = () => {
  return (
    <PageTransition>
      <section className="content-section">
        <HeroBanner
          title="Digital Dictionary"
          subTitle="The digital team is taking on an initiative to supply a dictionary of all currently data
              fields being used throughout their assets. Below, please find the document library where these dictionaries are stored.
              As this is a new initiative. The list will be updated over time, and the addition of new fields is always
              ongoing so be sure to check back for updates!"
          imgSrc={DigitalDictionaryBG}
          shape="box"
          variant="slide-down-boxes"
        />
        <DictionarySection title="Digital Dictionary Library" />
      </section>
    </PageTransition>
  );
};
export default DigitalDictionary;
