import React from "react";
import ExcelLogo from "../../assets/img/page_icons/xls-icon.png";

const DictionarySection = ({ title }) => {
  return (
    <div className="dictionarySection">
      <div className="contentWrap">
        <div className="systemTitle">
          <h3>{title}</h3>
        </div>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th></th>
                <th></th>
                <th>Modified</th>
                <th>Modified by</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td width="100">
                  <img src={ExcelLogo} alt="#" />
                </td>
                <td>
                  Document.xls
                  <span>60 KB of 120 KB</span>
                </td>
                <td>
                  <span>5th Feb 2024</span>
                </td>
                <td>
                  <span>Craig Cameron</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
export default DictionarySection;
