import React from "react";
const MissionContent = ()=>{
  return (
    <section className="content-section">
    <div className="missionBanner">
      <div className="missionBanner-item">
        <div className="contentWrap">
          <div className="missionBanner-info">
            <h2 className="text-capitalize">Our Mission</h2>
            <p>Enable the GA&A organization to become a best-in-class audit organization delivering data-driven,
              risk-based audit and assurance projects by:</p>
              <p>Ultimately, to optimize the benefit of the digital program and achieve the broader GA&A vision, there will
              be a focus on developing and shifting our mindset on how we approach audit and assurance.</p>
            {/* <a>Know More <b></b></a> */}
          </div>
        </div>
        <div className="missionBanner-bg"><img alt="#" src={require("../../assets/img/home/banner/banner_04.png")} /> </div>
      </div>
    </div>

    <div className="missionContent">
      <div className="contentWrap">
        <div className="missionContent-img"><img alt="#" src={require("../../assets/img/mission_points.png")} /></div>
        <div className="missionContent-text">
          <div className="missionContent-para">
            <p>Identifying and leveraging <span>Advanced Data Analytics, Robotic Process Automation (RPA), Artificial
                Intelligence (Al)</span>, and other digital solutions independently and in concert</p>
          </div>
          <div className="missionContent-para">
            <p>Simplifying execution, enhancing <span>insights for decision-making,</span> and <span>implementing
                innovation</span> for GA&A's tactical and strategic objectives "Core + More"</p>
          </div>
          <div className="missionContent-para">
            <p>The focus areas of <span>GANS Digital program</span> include:</p>
            <ul>
              <li>Talent/People</li>
              <li>Processes</li>
              <li>Technology</li>
              <li>Results</li>
            </ul>
          </div>
        </div>

      </div>
    </div>

  </section>
  );
};

export default MissionContent;
