import HeroBanner from "../../components/ui/HeroBanner";
import DiaTeamBG from "../../assets/img/page_banners/di_a_teams.png";
import MemberGroup from "./memberGroup";
import MemberGroupSlide from "./memberGroupSlide";
import {
  MemberGroupItems1,
  MemberGroupItems2,
  MemberGroupItems3,
} from "./data_diaTeam";
import PageTransition from "../../components/ui/Animations/PageTransition";

const DiaTeam = () => {
  return (
    <PageTransition>
      <section className="content-section">
        <HeroBanner
          title="DI&A Team"
          subTitle="Lorem ipsum dolor sit amet consectetur. Commodo sit eget egestas ipsum bibendum sapien."
          imgSrc={DiaTeamBG}
          shape="box"
          variant="fade-in-boxes"
        />
        <MemberGroup
          title="Digital Innovation & Analytics Leadership"
          memberGroupItems={MemberGroupItems1}
        />
        <MemberGroupSlide
          slideTitle="Digital Analytics & Analytics Team"
          memberGroupSlideItems={MemberGroupItems2}
        />
        <MemberGroup
          title="Digital Analytics & System Team"
          memberGroupItems={MemberGroupItems3}
        />
      </section>
    </PageTransition>
  );
};
export default DiaTeam;
