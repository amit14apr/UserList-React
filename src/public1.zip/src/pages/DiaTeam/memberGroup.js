import React from "react";

const MemberGroup = ({ title, memberGroupItems }) => {
  return (
    <div className="memberGroup">
      <div className="contentWrap">
        <div className="memberWrap">
          <h3>{title}</h3>
          <div className="membersList">
            {memberGroupItems.map((item, i) => {
              return (
                <div className="membersList-Item show">
                  <div className="membersList-Itemover">
                    <h4>{item.name}</h4>
                    <p>{item.designation}</p>
                  </div>
                  <div className="membersList-quotes">
                    <p>{item.quote}</p>
                  </div>
                  <img
                    className="membersList-Itembg"
                    alt="#"
                    src={item.image}
                  />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
export default MemberGroup;
