import Person1 from "../../assets/img/members/person_12.png";
import Person2 from "../../assets/img/members/person_13.png";
import Person3 from "../../assets/img/members/person_15.png";
import Person4 from "../../assets/img/members/person_14.png";
import Person5 from "../../assets/img/members/person_06.png";
import Person6 from "../../assets/img/members/person_03.png";
import Person7 from "../../assets/img/members/person_04.png";
import Person8 from "../../assets/img/members/person_05.png";
import Person9 from "../../assets/img/members/person_09.png";

export const MemberGroupItems1 = [
  {
    name: "Jessica Kahl-Winter",
    designation: "Vice President Global IT, SOX and Digital Strategy",
    quote: `“When you were made a leader, you weren't given a crown; you were given the responsibility to bring
                  out the best in others” - Jack Welch`,
    image: Person1,
  },
  {
    name: "Torian Conner",
    designation: "Director Global Tech Audit Digital Innovation",
    quote: `“There are no secrets to success. It is the result of preparation, hard work, and learning from
                  failure." - Colin Powell`,
    image: Person2,
  },
];
export const MemberGroupItems2 = [
  {
    name: "Wen Gu",
    designation: "Digital Investigations Lead",
    quote: `“We are the music makers, and we are the dreamers of dreams”. Willy Wonka`,
    image: Person4,
  },
  {
    name: "Lalit Khandelwal",
    designation: "Auditing Department",
    quote: `"The Only Constant in Life Is Change."-Heraclitus`,
    image: Person5,
  },
  {
    name: "Deana Kimbler-Muehl",
    designation: "Data Analytics and Automation Lead",
    quote: `"It does not matter how slowly you go, so long as you do not stop: -Confucius`,
    image: Person6,
  },
  {
    name: "Cameron Craig",
    designation: "Senior Digital Analyst",
    quote: `"Greatness is sifted through the grind, therefore don't despise the hard work now for surely it will be worth it in the end," -Sanjo Jendayi`,
    image: Person7,
  },
  {
    name: "Karen O'Dennis",
    designation: "Lead Data Analyst",
    quote: `"You must be the change you want to see in the world" - Mahatma Gandhi`,
    image: Person8,
  },
  {
    name: "John Doe",
    designation: "IT Audit, SOX Digital Strategy",
    quote: `Lorem ipsum dolor sit amet consectetur. Commodo sit eget egestas ipsum bibendum sapien.`,
    image: Person9,
  },
];
export const MemberGroupItems3 = [
  {
    name: "Trish Mastalski",
    designation: "Audit System Lead",
    quote: `“We are the music makers, and we are the dreamers of dreams”. Willy Wonka`,
    image: Person3,
  },
];
