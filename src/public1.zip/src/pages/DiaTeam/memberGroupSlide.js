import React from "react";

const MemberGroupSlide = ({ slideTitle, memberGroupSlideItems }) => {
  return (
    <div className="memberGroup">
      <div className="contentWrap">
        <div className="memberWrap">
          <div className="row align-items-center">
            <div className="col">
              <h3>{slideTitle}</h3>
            </div>
            <div className="col text-end">
              <a href="javascript:;" className=" button-prev">
                <b className="icon-arrow-left"></b>
              </a>
              <a href="javascript:;" className=" button-next">
                <b className="icon-arrow-right"></b>
              </a>
            </div>
          </div>
          <div className="membersList membersSlider">
            {memberGroupSlideItems.map((item, i) => {
              return (
                <div key={i} className="membersSlider-cover">
                  <div className="membersList-Item">
                    <div className="membersList-Itemover">
                      <h4>{item.name}</h4>
                      <p>{item.designation}</p>
                    </div>
                    <div className="membersList-quotes">
                      <p>{item.quote}</p>
                    </div>
                    <img
                      className="membersList-Itembg"
                      alt="#"
                      src={item.image}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
export default MemberGroupSlide;
