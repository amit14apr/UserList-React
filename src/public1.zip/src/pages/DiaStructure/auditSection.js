import React, { useContext } from "react";

const AuditSection = ({ data }) => {
  return (
    <div className="auditSection">
      <div className="contentWrap">
        <div className="row">
          <div className="col-5">
            <div className="auditContent">
              <div className="systemTitle">
                <h3>{data?.title}</h3>
              </div>
              <div className="color-linear-line"></div>
              <p>
               {data?.description}
              </p>
            </div>
          </div>
          <div className="col-7">
            <img
              src={require("../../assets/img/structure_images/audit_risk_img.png")}
              alt="Audit Risk"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuditSection;
