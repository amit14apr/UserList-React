import React from "react";
import DiaTemplate from "./diaTemplate";
import AnalyticsMiddleSection from "./analyticsMiddleSection";
import BackgroundAnimation from "../../components/ui/Animations/BackgroundAnimation";
import AutomationSection from "./automationSection";
import AuditSection from "./auditSection";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import  useFetch from "../../hooks/useFetch";

const DiaStructure = () => {
  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}dia/2`
  );
  
  return (
    <>
    <section className="content-section">
          <div className="innerBanner">
            <div className="innerBanner-item">
              <div className="innerBanner-info">
                <div className="contentWrap">
                 <h2>{data?.data?.banners[0]?.bannername}</h2> 
                  <p>
                    {data?.data?.banners[0]?.bannerdescription}
                  </p>
                </div>
              </div>
              <div className="innerBanner-bg">
                <img
                  alt="#"
                  src={data?.data?.banners[0]?.bannerimage}
                />
                 <BackgroundAnimation shape="box" variant="slide-down-boxes" />
              </div>
            </div>
          </div>
          {/* <Slide delay={0.3}> */}
            {/* <> */}
              <DiaTemplate detail={data?.data?.detail}/>
            {/* </> */}
          {/* </Slide> */}
          {/* <Slide delay={0.5}> */}
            {/* <> */}
              <AnalyticsMiddleSection data={data?.data?.sections[0]}/>
            {/* </>
          </Slide> */}
          {/* <Slide delay={0.5}>
            <> */}
              <AutomationSection data={data?.data?.sections[1]}/>
            {/* </> */}
          {/* // </Slide> */}
          {/* <Slide delay={0.5}>
            <> */}
              <AuditSection data={data?.data?.sections[2]}/>
            {/* </>
          </Slide> */}
        </section>
    </>
        
    // </DiaStructureProvider>
  );
};

export default DiaStructure;
