import React, { useContext } from "react";

const DiaTemplate = ({detail}) => {
  console.log('data !!', detail)
  return (
    <div className="diaTemplate">
      <div className="diaTemplate-content">
        <div className="systemTitle">
          <div className="contentWrap">
            <h3>Digital Analytics & Automation Team Methodology</h3>
            <p>{detail?.organizationalcharttitle}</p>
          </div>
        </div>
        <div className="contentWrap">
          <img
            src={detail?.organizationalchartimage}
            alt="Org Chart"
          />
        </div>
      </div>
    </div>
  );
};

export default DiaTemplate;
