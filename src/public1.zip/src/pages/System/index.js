import BackgroundAnimation from "../../components/ui/Animations/BackgroundAnimation";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import useFetch from "../../hooks/useFetch";
import { Link } from "react-router-dom";
import { useEffect } from 'react';


function System() {
  const slugId = window.location.pathname.slice(35)

  const { data: navData } = useFetch(
    `${COCKPIT_BASE_URL}navigation`
  );

  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}systemchild/${slugId || 'systems-i-sight'}/0`
  );

  useEffect(() => {
    window.history.scrollRestoration = 'manual'
  }, []);
  return (
    <section className="content-section">
      <div className="innerBanner">
        <div className="innerBanner-item">
          <div className="innerBanner-info">
            <div className="contentWrap">
              <h2>{data?.data?.banners[0]?.bannername}</h2>
              <p>
                {data?.data?.banners[0].bannerdescription}
              </p>
            </div>
          </div>
          <div className="innerBanner-bg">
            <img
              alt="#"
              src={data?.data?.banners[0].bannerimage}
            />
            <BackgroundAnimation shape="box" variant="fade-out-boxes" />
          </div>
        </div>
      </div>
      <div className="contentWrap">
        <div className="pageTemplate">
          <div className="pageTemplate-links">
            <ul>
              {navData?.data[3]?.children?.map((el, i) => (
                <li
                  className={slugId == el.slug && "active"}
                >
                  <Link to={`/data-innovation-analytics/systems/${el.slug}`}>
                    {el.pagename} <b className="icon-chevron-right noMove"></b>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          {/* </Slide>
              <Slide delay={0.5}> */}
          <div className="pageTemplate-content">
            <div className="systemTitle">
              <h3>{data?.data?.detail.title}</h3>
              <p>
                {data?.data?.detail?.description}
              </p>
            </div>

            {data?.data?.SystemsLinks.length > 0 &&
              <div className="systemLinkSection">
                <div className="systemLinkSection-wrap">
                  <h3>System Links</h3>

                  {data?.data?.SystemsLinks.map((el, i) =>

                    <div key={i} className="systemLinkSection-links">
                      <div class="systemLinkGroup-list">

                        <div class="systemLinkGroup">
                          <img alt="#" src={el.uploadlogo} />
                          <h4>{el.title}</h4>

                          <a href={el.url} target="_blank" rel="noopener noreferrer">Click Here <b class="icon-chevrons-right"></b></a>
                        </div>


                      </div>
                    </div>
                  )}
                </div>
              </div>
            }


            {data?.data?.systemBusinessContact.length > 0 && 
                  <div className="contactList">
                    <h3>Business Contact</h3>
                    <ul>
                        {data?.data?.systemBusinessContact.map((el, i) => <div key={i} className="contactMember">
                        <a href="mailto:tmastals@its.jnj.com">
                          <div className="contactMember-img">
                            <img
                              alt="#"
                              src={el.profileimagepath}
                            />
                          </div>
                          <div className="contactMember-info">
                            <h4>{el.contact}</h4>
                            <p>{el.designation}</p>
                            <span>{el.department}</span>
                          </div>
                          </a>
                        </div>)}
                    </ul>
                  </div>
}
            
                    {data?.data?.SystemsTrainingDocs.length > 0 &&
                      <div  className="trainingList">
                      <h3>Training Materials &amp; Documentation</h3>
                      <ul>
                      {data?.data?.SystemsTrainingDocs?.map((el, i) =>  <li key={i}>
                          <div className="trainingItem">
                            <div className="trainingItem-img">
                              <img
                                alt="#"
                                src={el.uploadthumbnail}
                              />
                            </div>
                            <div className="trainingItem-info">
                              <p>
                                <span>{data?.data?.title}</span> {el.description}
                              </p>
                              <a href={el.link} target="_blank" rel="noopener noreferrer"><b>
                          Click Here <b class="icon-chevrons-right"></b>
                        </b>
                        </a>
                            </div>
                          </div>
                        </li>)}
                      </ul>
                    </div>
         }
         
          </div>

        </div>
      </div>

    </section>
  );
}

export default System;
