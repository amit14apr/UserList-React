import React, { createContext, useState } from "react";

export const AnalyticsRequestContext = createContext();

export const AnalyticsRequestProvider = ({ children }) => {
  const [responseData, setResponseData] = useState(null);
  return (
    <AnalyticsRequestContext.Provider value={{ responseData, setResponseData }}>
      {children}
    </AnalyticsRequestContext.Provider>
  );
};
