import React from "react";

const AnalyticsSection = ({ title, children, image }) => {
  return (
      <div className="analyticsIntro">
      <div className="contentWrap">
          <h3>{title}</h3>
        <div className="analyticsContent">
          <p>{children}</p>
          <iframe frameborder="0" allowFullScreen allowTransparency width="100%" height="675" src="https://apps.powerapps.com/play/e/default-3ac94b33-9135-4821-9502-eafda6592a35/a/a8011cd3-ae93-4902-bef9-edd4cf4cbede" />
        </div>
        </div>
      </div>
  );
};
export default AnalyticsSection;
