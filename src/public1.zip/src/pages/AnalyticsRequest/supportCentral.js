import React, { useContext } from "react";
import { AnalyticsRequestContext } from "./AnalyticsRequestContext";

const SupportCentral = ({supportCentralData}) => {
  
  return (
    <div className="analyticsSupport">
      <div className="contentWrap">
        <h3>{supportCentralData?.detail.Support_central_title}</h3>
        <div className="analyticsText">
          <div className="analyticsText-points">
            {supportCentralData?.sections.id === 1 && (
              <>
                <h4>{supportCentralData?.sections.title}</h4>
                <p>{supportCentralData?.sections.description}</p>
                <ul>
                  {supportCentralData?.sections.subSection.map((item) => {
                    return (
                      <li key={item.id}>
                        <div className="pointsBar">
                          <div className="pointsBar-left">
                            <p>{item.title}</p>
                          </div>
                          <div className="pointsBar-right">
                            <ul>
                              {item.description.map((point) => {
                                return <li>{point}</li>;
                              })}
                            </ul>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </>
            )}
          </div>
          <div className="analyticsText-img">
            <img
              alt="#"
              src="../../assets/img/analytic_images/application.jpg"
            />
          </div>
        </div>
        <div className="analyticsText">
          <div className="analyticsText-img">
            <img
              alt="#"
              src="../../assets/img/analytic_images/useraccess.jpg"
            />
          </div>
          <div className="analyticsText-points">
            {supportCentralData?.sections.id === 2 && (
              <>
                <h4>{supportCentralData?.sections.title}</h4>
                <p>{supportCentralData?.sections.description}</p>
                <ul>
                  {supportCentralData?.sections.subSection.map((item) => {
                    return (
                      <li key={item.id}>
                        <div className="pointsBar">
                          <div className="pointsBar-left">
                            <p>{item.title}</p>
                          </div>
                          <div className="pointsBar-right">
                            <ul>
                              {item.description.map((point) => {
                                return <li>{point}</li>;
                              })}
                            </ul>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupportCentral;
