import React, { useEffect, useContext } from "react";
import {
  AnalyticsRequestContext,
  AnalyticsRequestProvider,
} from "./AnalyticsRequestContext";
import HeroBanner from "../../components/ui/HeroBanner";
import AnalyticsRequestBG from "../../assets/img/page_banners/analytics_bg.png";
import AnalyticsSection from "./analyticsSection";
import AnalyticsSecImg from "../../assets/img/analytic_images/analytic_01.png";
import ContactDetails from "./contactDetails";
import SupportCentral from "./supportCentral";
import PageTransition from "../../components/ui/Animations/PageTransition";
import Slide from "../../components/ui/Animations/Slide";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import useFetch from "../..//hooks/useFetch";

const AnalyticsRequest = () => {
  const { loading, data } = useFetch(`${COCKPIT_BASE_URL}analyticsrequest/3`);
  console.log("data ads", data);

  return (
    <section className="content-section">
      <HeroBanner
        title="Analytics Request"
        subTitle={data?.data?.banners[0].bannerdescription}
        imgSrc={AnalyticsRequestBG}
        shape="box"
        variant="fade-in-boxes"
      />
      <div className="analyticsSection">
        <AnalyticsSection
          title="Digital Innovation & Analytics"
          image={AnalyticsSecImg}
          children={
            <>
              "Welcome to the{" "}
              <span className="red-color">Digital Innovation & Analytics</span>{" "}
              Request Site. Please use the form below to submit a request for a
              New Asset, Enhancement, Refresh, or Break Fix!"
            </>
          }
        />
        {/* <div>
              <SupportCentral supportCentralData={data?.data}/>
            </div> */}

        <div class="analyticsSupport">
          <div class="contentWrap">
            <h3>Support Central</h3>
            <div class="analyticsText">
              {data?.data?.sections.slice(0, 1).map((item) => (
                <div class="analyticsText-points">
                  <h4>{item.title}</h4>
                  <p>{item.description}</p>
                  <ul>
                    {item.subSections.map((el, i) => (
                      <li>
                        <div class="pointsBar">
                          <div class="pointsBar-left">
                            <p>{el.title}</p>
                          </div>
                          <div class="pointsBar-right">
                            <ul>
                              {[el.description].map((el) => (
                                <li>{el}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
              <div class="analyticsText-img">
                <img
                  alt="#"
                  src={require("../../assets/img/analytic_images/application.png")}
                />
              </div>
            </div>
            <div class="analyticsText">
              <div class="analyticsText-img">
                <img
                  alt="#"
                  src={require("../../assets/img/analytic_images/useraccess.png")}
                />
              </div>
              {data?.data?.sections.slice(1).map((item) => (
                <div class="analyticsText-points">
                  <h4>{item.title}</h4>
                  <p>{item.description}</p>
                  <ul>
                    {item.subSections.map((el, i) => (
                      <li>
                        <div class="pointsBar">
                          <div class="pointsBar-left">
                            <p>{el.title}</p>
                          </div>
                          <div class="pointsBar-right">
                            <ul>
                              {[el.description].map((el) => (
                                <li>{el}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div>
          <ContactDetails contactDetails={data?.data} />
        </div>
      </div>
    </section>
  );
};

export default AnalyticsRequest;
