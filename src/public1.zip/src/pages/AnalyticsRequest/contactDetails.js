import React, { useContext } from "react";
import { AnalyticsRequestContext } from "./AnalyticsRequestContext";
import StaggeredDiv from "../../components/ui/Animations/StaggeredListItem/staggeredDiv";

const ContactDetails = ({contactDetails}) => {
  return (
    <div class="contactList">
      <div class="contentWrap">
        <h3>{contactDetails?.detail.businesscontacttitle}</h3>
        <p>
          If you have any questions,{" "}
          <span class="red-color">please reach out to the below pillar</span>{" "}
          leads for more information!
        </p>
        <ul>
          {contactDetails?.contacts?.map((contact) => <li>
              <StaggeredDiv
                key={contact?.id}
                index={contact?.id}
                className="col"
              >
                <div class="contactMember">
                  <span class="contactMember-group">{contact?.department}</span>
                  <div class="contactMember-img">
                    <img alt="#" src={contact?.profileimagepath} />
                  </div>
                  <div class="contactMember-info">
                    <h4>{contact?.name}</h4>
                    <p>{contact?.designation}</p>
                  </div>
                </div>
              </StaggeredDiv>
            </li>
          )}
        </ul>
      </div>
    </div>
  );
};
export default ContactDetails;
