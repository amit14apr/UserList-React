import React, { useEffect, useState } from "react";
import HeroBanner from "../../components/ui/HeroBanner";
import SolutionPortfolioBG from "../../assets/img/page_banners/solution_portfolio.png";
import PageTemplateLinks from "./pageTemplateLinks";
import PageTemplateContent from "./pageTemplateContent";
import { PageTemplateContentItems } from "./data_solutionPortfolio";
import PageTransition from "../../components/ui/Animations/PageTransition";
import Slide from "../../components/ui/Animations/Slide";
import "../../styles/styles.scss";
import { COCKPIT_BASE_URL, visitedPagesTracker } from "../../utils/helper";
import useFetch from "../../hooks/useFetch";

const SolutionPortfolio = () => {
  useEffect(() => {
    const url = window.location.pathname
    const urlData = url.split("/");
    visitedPagesTracker({title:urlData[urlData.length - 1], path:url})
  }, [])
  const slugId = window.location.pathname.slice(27)
  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}${slugId}/0`
  );

  useEffect(() => {
    window.history.scrollRestoration = 'manual'
  }, []);

  return (
    <PageTransition>
      <section className="content-section">
        <HeroBanner
          title={data?.data.banners[0].bannername}
          subTitle={data?.data.banners[0].bannerdescription}
          imgSrc={data?.data.banners[0].bannerimage}
          shape="box"
          variant="slide-down-boxes"
        />
        <div className="contentWrap">
            <div className="pageTemplate">
            <PageTemplateLinks />
               <PageTemplateContent
                  pageTemplateContentItems={data?.data}
                   />
            </div>
        </div>
      </section>
    </PageTransition>
  );
};
export default SolutionPortfolio;
