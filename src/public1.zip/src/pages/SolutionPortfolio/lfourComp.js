import { Link } from "react-router-dom";
import Slide from "../../components/ui/Animations/Slide";

function LFour({ data }) {
  let breadcrumb1 = localStorage.getItem("lone");
  let breadcrumb2 = localStorage.getItem("ltwo");
  let breadcrumb3 = localStorage.getItem("lthree");

  const baseUrl = "/data-innovation-analytics/solutionPortfolio";
  return (
    <div className="pageTemplate-content withBg">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <Link to={`${baseUrl}/solution-portfolio`}>Solution Portfolio</Link>
        </li>
        {breadcrumb1 && (
          <li
            class="breadcrumb-item active"
            aria-current="page"
            onClick={() => {
              localStorage.removeItem("ltwo");
              localStorage.removeItem("lthree");
            }}
          >
            <Link to={`${baseUrl}/${breadcrumb1}`}>{breadcrumb1}</Link>
          </li>
        )}
        {breadcrumb2 && (
          <li
            class="breadcrumb-item active"
            aria-current="page"
            onClick={() => {
              localStorage.removeItem("lthree");
            }}
          >
            <Link to={`${baseUrl}/${breadcrumb2}`}>{breadcrumb2}</Link>
          </li>
        )}
        {breadcrumb3 && (
          <li class="breadcrumb-item active" aria-current="page">
            <Link to={`${baseUrl}/${breadcrumb3}`}>{breadcrumb3}</Link>
          </li>
        )}
      </ol>
      <div
        className="pageTemplate-content"
        style={{ width: "100%", padding: "70px 0", position: "relative" }}
      >
        <div className="systemTitle">
          <h3>{data?.detail?.pagename}</h3>
          <p>{data?.detail?.description}</p>
        </div>
        {data?.systemsLinks?.length > 0 && (
          <div className="systemLinkSection">
            <div className="systemLinkSection-wrap">
              <h3>System Links</h3>

              {data?.systemsLinks?.map((el, i) => (
                <div key={i} className="systemLinkSection-links">
                  <div class="systemLinkGroup-list">
                    <div class="systemLinkGroup">
                      <img alt="#" src={el.uploadlogo} />
                      <h4>{el.title}</h4>

                      <a
                        href={el.url}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Click Here <b class="icon-chevrons-right"></b>
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        {data?.systemBusinessContact?.length > 0 && (
          <div className="contactList">
            <h3>Business Contact</h3>
            <ul>
              {data?.systemBusinessContact?.map((item) => (
                <li>
                  <div className="contactMember">
                    <div className="contactMember-img">
                      <img alt="#" src={item?.profileimagepath} />
                    </div>
                    <div className="contactMember-info">
                      <h4>{item?.name}</h4>
                      <p>{item?.designation} </p>
                      <span>{item?.groupname}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
        <Slide delay={0.7}>
          {data?.systemsTrainingDocs?.length > 0 && (
            <div className="trainingList">
              <h3>Training Materials & Documentation</h3>
              <ul>
                {data?.SystemsTrainingDocs?.map((el, i) => (
                  <li key={i}>
                    <div className="trainingItem">
                      <div className="trainingItem-img">
                        <img alt="#" src={el.uploadthumbnail} />
                      </div>
                      <div className="trainingItem-info">
                        <p>
                          <span>{data?.title}</span> {el.description}
                        </p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Slide>
      </div>
    </div>
  );
}

export default LFour;
