import HeroBanner from "../../../components/ui/HeroBanner";
import PageTemplateLinks from "../pageTemplateLinks";
import PageTransition from "../../../components/ui/Animations/PageTransition";
import "../../../styles/styles.scss";
import { COCKPIT_BASE_URL, visitedPagesTracker } from "../../../utils/helper";
import useFetch from "../../../hooks/useFetch";
import { useLocation } from "react-router-dom";
import LFour from "../lfourComp";
import { useEffect, useState } from "react";  

const SolutionPortfoliol4 = () => {
  const location = useLocation();

  const [lfourContent, setLfourContent] = useState({
    banners: []
  })
  const url = window.location.pathname.split('/')
  const slugId = url[url.length - 1]
  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}solutionPortfolio/l4/${slugId}/0`
  );

  useEffect(() => {
    const url = location.pathname
    const urlData = url.split("/");
    visitedPagesTracker({title:urlData[urlData.length - 1], path:url})
  }, [location.pathname])
 

  useEffect(() =>{
    setLfourContent(data?.data)
    // window.location.reload();
  }, [data])

  return (
    <PageTransition>
      <section className="content-section">
        {lfourContent?.banners?.map(item => <HeroBanner
          title={item.bannername}
          subTitle={item.bannerdescription}
          imgSrc={item.bannerimage}
          shape="box"
          variant="slide-down-boxes"
        />)}
        <div className="contentWrap">
            <div className="pageTemplate" >
            <PageTemplateLinks />
            <LFour data={lfourContent}/>
            </div>
        </div>
      </section>
    </PageTransition>
  );
};
export default SolutionPortfoliol4;
