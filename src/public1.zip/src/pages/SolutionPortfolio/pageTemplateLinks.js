import useFetch from "../../hooks/useFetch";
import React, { useEffect, useState } from "react";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import { Link, useParams } from "react-router-dom";

const PageTemplateLinks = () => {
  const [isLone, setLone] = useState('')
  const [isLtwo, setLtwo] = useState('')
  const [isLthree, setLthree] = useState('')


  useEffect(() => {
    setLone(localStorage.getItem('lone'))
    setLtwo(localStorage.getItem('ltwo'))
    setLthree(localStorage.getItem('lthree'))

    return () => {
      if(!window.location.pathname.includes('/solutionPortfolio')) {
        localStorage.removeItem('ltwo')
        localStorage.removeItem('lthree')
      }
    };
  }, [])

  const { error, data } = useFetch(`${COCKPIT_BASE_URL}solutionPortfolio/solution-portfolio/0`);

  return (
    <div class="pageTemplate-links">
      <ul>
        {data?.data?.children?.map((el, i) => {
          return (
            <li
              onClick={() => {
                setLone(el.slug)
                localStorage.setItem('lone', el.slug)
              }}
              className={el.slug == isLone ? "active" : ""}
              key={`${el.slug}_${i}`}
            >
              <Link
                to={
                  el.children.length === 1
                    ? `/data-innovation-analytics/solutionPortfolio/${el.children[i]?.slug}`
                    : `/data-innovation-analytics/solutionPortfolio/${el.slug}`
                }
              >
                {el.pagename}
                {el.slug == isLone && <b class="icon-chevron-right"></b>}
              </Link>
              <ul>
                {el.children?.map((el1, i) => (
                  <li
                    onClick={() => {
                      setLtwo(el1.slug)
                      localStorage.setItem('ltwo', el1.slug)
                    }}
                    key={`${el1.slug}_${i}`}
                    className={el1.slug == isLtwo ? "active" : ""}
                  >
                    <Link to={`/data-innovation-analytics/solutionPortfolio/${el1.slug}`}>
                      {el1.pagename} {el1.slug == isLtwo && <b class="icon-chevron-right"></b>}
                    </Link>
                    <ul>
                      {el1.children?.map((item, i) => (
                        <li
                          onClick={() => {
                            setLthree(item.slug)
                            localStorage.setItem('lthree', item.slug)
                          }
                          }
                          key={`${item.slug}_${i}`}
                          className={
                            item.slug == isLthree ? "active" : ""
                          }
                        >
                          <Link
                            to={`/data-innovation-analytics/solutionPortfolio/solution-portfolio/dashboard/${item.slug}`}
                          >
                            {item.pagename}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </li>
                ))}
              </ul>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default PageTemplateLinks;
