import React from "react";
import { Link } from "react-router-dom";

function PageTemplateContent({ pageTemplateContentItems = [] }) {
  let breadcrumb1 = localStorage.getItem("lone");
  let breadcrumb2 = localStorage.getItem("ltwo");
  let breadcrumb3 = localStorage.getItem("lthree");

  const baseUrl = "/data-innovation-analytics/solutionPortfolio";
  return (
    <div className="pageTemplate-content withBg">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <Link to={`${baseUrl}/solution-portfolio`}>Solution Portfolio</Link>
        </li>
        {breadcrumb1 && (
          <li
            class="breadcrumb-item active"
            aria-current="page"
            onClick={() => {
              localStorage.removeItem("ltwo");
              localStorage.removeItem("lthree");
            }}
          >
            <Link to={`${baseUrl}/${breadcrumb1}`}>{breadcrumb1}</Link>
          </li>
        )}
        {breadcrumb2 && (
          <li
            class="breadcrumb-item active"
            aria-current="page"
            onClick={() => {
              localStorage.removeItem("lthree");
            }}
          >
            <Link to={`${baseUrl}/${breadcrumb2}`}>{breadcrumb2}</Link>
          </li>
        )}
        {breadcrumb3 && (
          <li class="breadcrumb-item active" aria-current="page">
            <Link to={`${baseUrl}/${breadcrumb3}`}>{breadcrumb3}</Link>
          </li>
        )}
      </ol>
      <div class="pageItem-wrap">
        <h3>{pageTemplateContentItems?.detail?.pagename}</h3>
        <ul className="pageItem-list">
          {pageTemplateContentItems?.children?.map((item, i) => {
            return (
              <li>
                <Link
                  className="pageItem"
                  onClick={() => {
                    if (item.type !== "l4") {
                      localStorage.setItem("ltwo", item.slug);
                    } else {
                      localStorage.setItem("lthree", item.slug);
                    }
                  }}
                  to={
                    item.type !== "l4"
                      ? `/data-innovation-analytics/solutionPortfolio/${item.slug}`
                      : `/data-innovation-analytics/solutionPortfolio/dashboard/${item.slug}`
                  }
                >
                  <div className="pageItem-icon">
                    <img alt="#" src={item.thumnail} />
                  </div>
                  <div className="pageItem-info">
                    <h4>{item.pagename}</h4>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
export default PageTemplateContent;
