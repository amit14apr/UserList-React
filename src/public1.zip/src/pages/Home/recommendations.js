import React, { useEffect, useLayoutEffect, useState } from "react";
import RecommendationImage1 from "../../assets/img/home/img_01.png";
import RecommendationImage2 from "../../assets/img/home/img_20.png";
import RecommendationImage3 from "../../assets/img/home/img_23.jpg";
import RecommendationImage4 from "../../assets/img/home/img_22.png";
import RecommendationImage5 from "../../assets/img/home/img_21.jpg";
import RecommendationImage6 from "../../assets/img/home/img_19.png";
import { Link } from "react-router-dom";

const Recommendations = () => {
  const [visitedPages, setVisitedPages] = useState();
  
  
  
  const [activeId, setActiveId] = useState('')

  const images = [
    RecommendationImage1,
    RecommendationImage2,
    RecommendationImage3,
    RecommendationImage4,
    RecommendationImage5,
    RecommendationImage6,
  ];

  useLayoutEffect(() => {
    setVisitedPages(JSON.parse(localStorage.getItem("visitedPages")));
    setActiveId(JSON.parse(localStorage.getItem("visitedPages"))[0].title);
  }, []);

  return (
    <div className="exploreRecommend">
      <div className="contentWrap">
        <div className="recommendWrap">
          <h4 data-aos="fade-up" data-aos-delay="200">Recommendations</h4>
          <p  data-aos="fade-up" data-aos-delay="400">Building upon your prior exploration</p>
          <div className="recommendGroup" data-aos="fade-up" data-aos-delay="600">
            <a href="javascript:;" className=" button-prev">
              <b className="icon-arrow-left"></b>
            </a>

            <ul>
              {visitedPages?.map((element, index) => (
                <li key={index} className={`${activeId === element.title && "active"} recommendItem`}>
                  <Link to={element.path}>
                    <div className={`recommendItem-over`}>
                      <h5 style={{ textTransform: "uppercase" }}>
                        {element.title}
                      </h5>

                      <a
                        className="recommendItem-arrow"
                        target="_blank"
                        href="solution_portfolio_.html"
                      >
                        <b className="icon-arrow-right"></b>
                      </a>
                    </div>
                    <img
                      className="recommendItem-bg"
                      alt="#"
                      src={images[index]}
                    />
                  </Link>
                </li>
              ))}
            </ul>
            <a href="javascript:;" className="button-next">
              <b className="icon-arrow-right"></b>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Recommendations;
