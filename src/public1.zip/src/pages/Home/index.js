import React, { useEffect } from "react";
import $ from "jquery";
import "jquery-ui-dist/jquery-ui";
import HeroCarousel from "../../components/ui/HeroCarousel";
import Recommendations from "./recommendations";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import useFetch from "../../hooks/useFetch";
import { Link } from "react-router-dom";
import Spinner from 'react-bootstrap/Spinner';
import Button from 'react-bootstrap/Button';

const Home = () => {
  const { data, loading, error } = useFetch(`${COCKPIT_BASE_URL}homepage/homepage/0`);

  useEffect(() => {
    $(".recommendItem").click(function () {
      $(this).closest("ul").find("li").removeClass("active");
      $(this).addClass("active");
    });

    $(".button-next").click(function () {
      var $li = $(".recommendGroup .recommendItem");
      var currentIndex = $(".recommendGroup .active").index(
        ".recommendGroup .recommendItem"
      );
      $li.removeClass("active");
      $li.eq((currentIndex + 1) % $li.length).addClass("active");
    });

    $(".button-prev").click(function () {
      console.log("clicked");
      var $li = $(".recommendGroup .recommendItem");
      var currentIndex = $(".recommendGroup .active").index(
        ".recommendGroup .recommendItem"
      );
      $li.removeClass("active");
      $li.eq((currentIndex - 1) % $li.length).addClass("active");
    });
  }, []);

  useEffect(() => {
    window.history.scrollRestoration = 'manual'
  }, []);

  // useEffect(() => {
  //   var newVideo = document.getElementById('bgVideo');
  //   newVideo.addEventListener('ended', function() {
  //       this.currentTime = 0;
  //       this.play();
  //   }, false);

  //   newVideo.play();
  // }, [])
  return (
    <>
      {!loading ? <section className="content-section">
      <div data-aos="fade-up">
        <HeroCarousel items={data?.data?.bannerData} loading={loading}/>
      </div>
        <div className="exploreCover">
          <video id="bgVideo" class="bgVideo" autoplay loop muted>
          <source src={require("../../assets/video/background.mp4")} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
          <div className="contentWrap">
            <div className="exploreTitle">
              <h3 data-aos="fade-up">
                To learn more and explore the <b>digital team</b>,<br /> please
                use the <span>resources </span>
                below!
              </h3>
            </div>
            <div class="dashLinkWrap" data-aos="fade-up" data-aos-delay="100">
              <div class="dashLinkWrap-link" data-aos="fade-up" data-aos-delay="700">
                <ul>
                  {data?.data?.pages?.reverse().slice(0, 4).map((el, i) => (
                    <li key={i}>
                      <Link class="dashLink" to={el.bannerlink}>
                        <h4>
                          <span>{el.bannername}</span>
                        </h4>
                        <p>{el.bannerdescription}</p>
                        <span class="arrowBox">
                          <b class="icon-arrow-right"></b>
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div class="dashLinkWrap-img">
                <img
                  alt="#"
                  src={require("../../assets/img/home/img_33.jpg")}
                />
              </div>
            </div>

            <div class="dashLinkWrap" data-aos="fade-up" data-aos-delay="200">
              <div class="dashLinkWrap-img">
                <img
                  alt="#"
                  src={require("../../assets/img/home/img_34.jpg")}
                />
              </div>
              {data?.data?.pages?.slice(4).map((el, i) => (
                <div class="dashLinkWrap-link" key={i} data-aos="fade-up" data-aos-delay="700">
                  <ul>
                    <li>
                      <Link class="dashLink" to={el.bannerlink}>
                        <h4>
                          <span>{el.bannername}</span>
                        </h4>
                        <p>{el.bannerdescription}</p>
                        <span class="arrowBox">
                          <b class="icon-arrow-right"></b>
                        </span>
                      </Link>
                    </li>
                  </ul>
                </div>
              ))}
            </div>
          </div>
          <div>
            <Recommendations />
          </div>
        </div>
      </section> : 
        <div className="spinner-container">
        <Spinner animation="border" size="sm" style={{width: 100, height: 100, color: 'red'}}/>
        </div>
    }
    </>
  );
};
export default Home;
