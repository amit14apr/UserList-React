import React from "react";

const DashLinkImage = ({ dashImage }) => {
  return (
    <div className="dashLinkWrap-img">
      <img alt="#" src={dashImage} />
    </div>
  );
};

export default DashLinkImage;
