import axios from "axios"
export const COCKPIT_BASE_URL = 'https://dev.cockpit.jnj.com/api/pages/'


export const updateContent = async (url, payload) => {
    try {
        const result = await axios.put(`${COCKPIT_BASE_URL}${url}`, payload)
        return result
    } catch (e) {
        console.log('Error occured', e)
    }
}



export const visitedPagesTracker = (page) => {
    const visitedPages = JSON.parse(localStorage.getItem('visitedPages'));
    if (!visitedPages.find(item => item.title === page.title)) {
        const updatedVisitedPages = [page, ...visitedPages?.slice(0, 5)];
        localStorage.setItem('visitedPages', JSON.stringify(updatedVisitedPages));
    }
}


export function sort_by_id() {
    return function (elem1, elem2) {
        debugger
        // change banner id to id for generic sort
      if (elem1.bannerid < elem2.bannerid) {
        return 1;
      } else if (elem1.bannerid > elem2.bannerid) {
        return -1;
      } else {
        return 0;
      }
    };
  }