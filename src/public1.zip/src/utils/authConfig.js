export const msalConfig = {
      
    auth: {
        clientId: "1adcb71e-bbb4-4797-9c87-b681a8a476ba",
        authority: "https://login.microsoftonline.com/3ac94b33-9135-4821-9502-eafda6592a35",
        redirectUri: "http://localhost:3000/"
    },
    
 
    cache: {
        cacheLocation: "localStorage",
        storeAuthStateInCookie: true,
    }
};

export const loginRequest = {
   scopes: ["User.Read"]
};

export const graphConfig = {
    graphMeEndpoint: "https://graph.microsoft.com/v1.0/me"
};
