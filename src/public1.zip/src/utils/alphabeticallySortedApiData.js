import React, { useState, useEffect } from "react";

const AlphabeticallySortedAPIData = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch("YOUR_API_ENDPOINT");
      const jsonData = await response.json();
      // Sort the data alphabetically by a specific property, assuming 'name' here
      const sortedData = jsonData.sort((a, b) => a.name.localeCompare(b.name));
      setData(sortedData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  return (
    <div>
      <h1>API Response Sorted Alphabetically</h1>
      <ul>
        {data.map((item, index) => (
          <li key={index}>{item.name}</li> // Assuming 'name' is the property to display
        ))}
      </ul>
    </div>
  );
};

export default AlphabeticallySortedAPIData;
