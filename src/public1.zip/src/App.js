import { useEffect, useLayoutEffect } from "react";
import useIsInViewport from "./hooks/useIsInViewport";
import Header from "./components/Header";
import Footer from "./components/Footer";
import AnimatedRoutes from "./animatedRoutes";
import "./components/ui/Animations/animation.scss";
import "./index.css"
import { useState } from "react";
import TaskWidget from "./components/ui/FloatingWindow";
import WidgetButton from "./assets/img/imageWidget.png";
import useFetch from "./hooks/useFetch";
import { COCKPIT_BASE_URL } from "./utils/helper";
import ConfirmationModal from "./components/ui/ConfirmationModal";
import { updateContent } from "./utils/helper";
import { useLocation } from "react-router-dom";

//import { AuthenticatedTemplate, MsalContext, UnauthenticatedTemplate, useIsAuthenticated, useMsal, useMsalAuthentication } from "@azure/msal-react";
// import { InteractionType, InteractionRequiredAuthError } from '@azure/msal-browser';
// import ProtectedRoute from "./Route/ProtectedRoute";

const App = () => {


  const { error, data, reFetch } = useFetch(`${COCKPIT_BASE_URL}tasks?email=SAgosto@its.jnj.com&currentPage=1&startDate=2024-03-25&endDate=2024-03-25&status=due`);

  const { inViewport, Obs, obsOptions } = useIsInViewport();

  const [isWidgetOpen, setIsWidgetOpen] = useState(false)
  const [getConfirmation, setGetConfirmation] = useState(false);
  const [taskToMarkCompleteData, setTaskToMarkCompleteData] = useState();

  // const isAuthenticated = useIsAuthenticated();
  // const contextType = MsalContext;
  // console.log("🚀 ~ App ~ contextType:", contextType)
  // const request = {

  //   scopes: ["User.Read"]
  // }
  // const { login, result } = useMsalAuthentication(InteractionType.Silent, request);
  // useEffect(() => {
  //   if (error instanceof InteractionRequiredAuthError) {
  //     login(InteractionType.Popup, request);
  //   }
  // }, [error]);

  // const { accounts } = useMsal();
  // console.log("🚀 ~ App ~ accounts:", accounts)
  // localStorage.setItem('token', JSON.stringify(accounts));

  useLayoutEffect(() => {
    // Attaching observer to every [data-inviewport] element:
    const ELs_inViewport = document.querySelectorAll("[data-inviewport]");

    ELs_inViewport.forEach((EL) => {
      Obs.observe(EL, obsOptions);
    });
  }, [inViewport, Obs, obsOptions]);

  useEffect(() => {
    window.history.scrollRestoration = 'manual'
  }, []);

  const location = useLocation();
  useEffect(() => {
    if (!location.hash) {
      window.scrollTo(0, 0);
    }
  }, [location]);


  const initialPages = [
    {
      "title": "legal",
      "path": "/data-innovation-analytics/solutions-portfolio/legal"
    },
    {
      "title": "managemnet-reporting",
      "path": "/data-innovation-analytics/solutions-portfolio/managemnet-reporting"
    },
    {
      "title": "it",
      "path": "/data-innovation-analytics/solutions-portfolio/it"
    },
    {
      "title": "finance",
      "path": "/data-innovation-analytics/solutions-portfolio/finance"
    },
    {
      "title": "digital",
      "path": "/data-innovation-analytics/solutions-portfolio/digital"
    },
    {
      "title": "ca-i",
      "path": "/data-innovation-analytics/solutions-portfolio/ca-i"
    }
  ];

  useLayoutEffect(() => {
    // Attaching observer to every [data-inviewport] element:
    const ELs_inViewport = document.querySelectorAll("[data-inviewport]");
    ELs_inViewport.forEach((EL) => {
      Obs.observe(EL, obsOptions);
    });

    localStorage.setItem('visitedPages', JSON.stringify(initialPages));
  }, [inViewport, Obs, obsOptions]);



  const launchWidget = () => {
    setIsWidgetOpen(true)
  }

  const getConfirmationAndProcess = (data) => {

    console.log("🚀 app~ getConfirmationAndProcess ~ data:", data)
    setTaskToMarkCompleteData(data);
    setGetConfirmation(!getConfirmation)
  }

  const onClose = proceed => {
    console.log("🚀 ~ onClose ~ proceed:", proceed)
    if (proceed == true) {
      const payloadData = taskToMarkCompleteData;
      payloadData.cockpit_completed = "yes";
      console.log("🚀 ~ onClose ~ payloadData:", payloadData)
      updateContent('task', payloadData)
        .then(response => console.log(response))
        .catch(error => console.log(error));
      setGetConfirmation(!getConfirmation)
      setGetConfirmation(false);
      setTaskToMarkCompleteData();
      reFetch();
    } else {
      setGetConfirmation(!getConfirmation)
      setGetConfirmation(false);
      setTaskToMarkCompleteData();
      return;
    }
  }


  console.log('isWidgetOpen', isWidgetOpen)

  return (
    <>
      {/* {isAuthenticated && (

        <ProtectedRoute>
          <Header />
          {getConfirmation && <ConfirmationModal isOpen={getConfirmation} onClose={onClose} />}
          <AnimatedRoutes />
          <div class="floating-widget">
            <button id="toggle-widget" onClick={launchWidget}><img src={WidgetButton} width="80px" /></button>
            {isWidgetOpen && <TaskWidget isOpen={isWidgetOpen} data={data?.data} getClickedEvent={getConfirmationAndProcess} />}
          </div>
          <Footer />
        </ProtectedRoute> */}
         <Header />
      {getConfirmation && <ConfirmationModal isOpen={getConfirmation} onClose={onClose} />}
      <AnimatedRoutes />
      <div class="floating-widget">
        <button id="toggle-widget" onClick={launchWidget}><img src={WidgetButton} width="80px" /></button>
        {isWidgetOpen && <TaskWidget isOpen={isWidgetOpen} data={data?.data} getClickedEvent={getConfirmationAndProcess} />}
      </div>
      <Footer />

      )}

    </>
  );
};
export default App;
