var config_01 = {
  type: 'doughnut',
  data: {
    datasets: [{
      data: [
        "70",
        "20",
        "10"
      ],
      backgroundColor: [
        "#ad84a7",
        "#d8bfd8",
        "#595878",
      ],
      borderWidth: 0
    }],
    labels: [
      'Invoices',
      'Contracts',
      'Claim Forms'
    ]
  },
  options: {
    responsive: true,
    cutoutPercentage: 75,
    legend: {
      display: true,
      position: 'bottom',
      labels: {
        boxWidth: 10,
        boxHeight: 15,
      }
    },
	      tooltips: {
      callbacks: {
        label: function (tooltipItem, data) {
          return data['labels'][tooltipItem['index']] + ': ' + data['datasets'][0]['data'][tooltipItem['index']] + '%';
        }
      }
    }
  }
};

var config_02 = {
  type: 'doughnut',
  data: {
    datasets: [{
      data: [
        "50",
        "50"
      ],
      backgroundColor: [
        "#008d77",
        "#72C156",
      ],
      borderWidth: 0
    }],
    labels: [
      'Product 01',
      'Product 02',
    ]
  },
  options: {
    responsive: true,
    cutoutPercentage: 75,
    legend: {
      display: true,
      position: 'bottom',
      labels: {
        boxWidth: 10,
        boxHeight: 15,
      }
    },
    tooltips: {
      callbacks: {
        label: function (tooltipItem, data) {
          return data['labels'][tooltipItem['index']] + ': ' + data['datasets'][0]['data'][tooltipItem['index']] + '%';
        }
      }
    }
  }
};


// LINE CHART
var trendData = {
  type: 'line',
  data: {
    labels: ['Jan 21', 'Feb 21', 'Mar 21', 'Apr 21', 'May 21', 'Jun 21', 'Jul 21', 'Aug 21', 'Sep 21', 'Oct 21', 'Nov 21', 'Dec 21'],
    datasets: [{
      label: 'Request Raised',
      fill: false,
      borderColor: "#333399",
      //borderDash: [4, 4],
      //borderDashOffset: 0.8,
      data: [13, 34, 72, 87, 93, 106, 154, 113, 13, 34, 72, 87],
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    tooltip: {
      mode: 'index',
    },
    hover: {
      mode: 'nearest',
    },
    legend: {
      display: false,
      labels: {
        boxWidth: 10,
        fontSize: 12,
        padding: 30
      }
    },
    scales: {
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Time'
        },
        gridLines: {
          color: "rgba(0,0,0,0.03)",
          zeroLineColor: "rgba(0,0,0,0.5)",
        }
      }],
      yAxes: [{
        scaleLabel: {
          display: false,
          labelString: 'Error Comparison '
        },
        gridLines: {
          color: "rgba(0,0,0,0.03)",
          zeroLineColor: "rgba(0,0,0,0.5)",
        }
      }]
    }
  }
};


window.onload = function () {
  var ctx_01 = document.getElementById('pie_chart_01').getContext('2d');
  var ctx_02 = document.getElementById('pie_chart_02').getContext('2d');
  var trendLine = document.getElementById('trend').getContext('2d');

  window.newPie_01 = new Chart(ctx_01, config_01);
  window.newPie_02 = new Chart(ctx_02, config_02);
  window.trendLineChart = new Chart(trendLine, trendData);

};

$(document).ready(function () {
  'use strict';


  // WORD CLOUD
  var words = [{
    text: "Invoice",
    weight: 13
  }, {
    text: "Receipt",
    weight: 7.5
  }, {
    text: "Claim",
    weight: 6.4
  }, {
    text: "Accouting",
    weight: 8
  }, {
    text: "Renewal",
    weight: 6.2
  }, {
    text: "Submission",
    weight: 5
  }, {
    text: "Expiry Date",
    weight: 9
  }, {
    text: "Contract",
    weight: 9
  }, {
    text: "Denial",
    weight: 2
  }, {
    text: "Due Date",
    weight: 5.5
  }, {
    text: "Address",
    weight: 6
  }, {
    text: "Document Type",
    weight: 4.5
  }, {
    text: "Product",
    weight: 2
  }];

  $('#wordCloud').jQCloud(words, {
    autoResize: true
  });


  $('input[name="datetimes"]').daterangepicker({
    timePicker: true,
    //startDate: moment().startOf('hour'),
    //endDate: moment().startOf('hour').add(100, 'hour'),
    startDate: "1/01/21",
    endDate: "12/31/21",
    locale: {
      format: 'M/DD/YY hh:mm A'
    }
  });

});
