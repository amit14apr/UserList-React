import React from 'react'
import { useMsal, useIsAuthenticated, AuthenticatedTemplate, UnauthenticatedTemplate } from '@azure/msal-react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ children }) => {
    const isAuthenticated = useIsAuthenticated();
    console.log("🚀 ~ ProtectedRoute ~ isAuthenticated:", isAuthenticated)

    if (!isAuthenticated) {
        return <Navigate to="/" replace />
    }
    return children

}

export default ProtectedRoute