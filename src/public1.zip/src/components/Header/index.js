//import "./header.scss";
import JNJLogo from "../../assets/img/logo/JNJ_Logo_SingleLine_Red_RGB.png";
import { Link, NavLink, redirect } from "react-router-dom";
import { motion } from "framer-motion";
import { headerData } from "./data";
import ToggleThemeButton from "../../context/ThemeContext/ToggleThemeButton";
import { ThemeProvider } from "../../context/ThemeContext";
import useFetch from "../../hooks/useFetch";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Header = () => {
  const { error, data } = useFetch(`${COCKPIT_BASE_URL}navigation`);
  let navigate = useNavigate();

  const slugId = window.location.pathname;

  useEffect(() => {
    if (slugId == "/") {
      navigate("/data-innovation-analytics/homepage");
    }
  }, [slugId]);

  // console.log("headerData", data);

  // var initials = '';
  // var userName = JSON.parse(localStorage.getItem('token'))[0].name;
  // userName.split(',').forEach(element => {
  //   initials = initials+element.trim()[0]
  // })
  
  return (
    <ThemeProvider>
      <header>
        <div className="headerMain">
          <div className="contentWrap">
            <div className="row align-items-center">
              <div className="col-6">
                <a className="navbar-brand">
                  <img alt="#" src={JNJLogo} />
                  <span>Digital Innovation & Analytics</span>
                </a>
              </div>
              <div className="col-6 text-end">
                <ToggleThemeButton />

                <div className="btn-group">
                  <span
                    aria-expanded="false"
                    className="dropdown-toggle noIcon userWrap"
                    data-bs-toggle="dropdown"
                  >
                    AD
                  {/* {initials} */}
                  </span>
                  <ul className="dropdown-menu dropdown-menu-end">
                    <li>
                      <a className="dropdown-item" href="explore_main.html">
                        Logout
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="headerMenu">
          <div className="contentWrap">
            <div className="headerLinks">
              <motion.ul
                initial={{ x: -100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ type: "spring", stiffness: 120 }}
              >
                {data?.data?.map((el, i) => {
                  return (
                    <>
                      <li>
                        {el.pageid === 10 ? (
                          <NavLink
                            activeClassName="active"
                            exact
                            to={`/data-innovation-analytics/solutionPortfolio/${el.slug}`}
                            onClick={() => {
                              localStorage.removeItem("lone");
                              localStorage.removeItem("ltwo");
                              localStorage.removeItem("lthree");
                            }}
                          >
                            {el.pagename}
                          </NavLink>
                        ) : (
                          <NavLink
                            activeClassName="active"
                            exact
                            to={`/data-innovation-analytics/${el.slug}`}
                          >
                            {el.pagename}
                          </NavLink>
                        )}
                        {el.children.length > 0 && (
                          <ul>
                            {el.children?.map((item) => (
                              <li className="subMenu">
                                {el.pageid === 4 ? (
                                  <NavLink
                                    activeClassName="active"
                                    exact
                                    to={`/data-innovation-analytics/systems/${item.slug}`}
                                  >
                                    {item.pagename}
                                  </NavLink>
                                ) : (
                                  <NavLink
                                    activeClassName="active"
                                    exact
                                    to={`/data-innovation-analytics/${item.slug}`}
                                  >
                                    {item.pagename}
                                  </NavLink>
                                )}

                                {item.children?.length > 0 && (
                                  <ul>
                                    {item.children?.map((sub_el) => (
                                      <li className="subMenu">
                                        <Link
                                          to={`/data-innovation-analytics/${sub_el.slug}`}
                                        >
                                          {sub_el.pagename}
                                        </Link>
                                        {sub_el.children?.length > 0 && (
                                          <ul>
                                            {sub_el.children?.map((sub_el1) => (
                                              <li className="subMenu">
                                                <Link
                                                  to={`/data-innovation-analytics/solution-portfolio/dashboard/${sub_el1.slug}`}
                                                >
                                                  {sub_el1.pagename}
                                                </Link>
                                              </li>
                                            ))}
                                          </ul>
                                        )}
                                      </li>
                                    ))}
                                  </ul>
                                )}
                              </li>
                            ))}
                          </ul>
                        )}
                      </li>
                    </>
                  );
                })}
              </motion.ul>
            </div>
          </div>
        </div>
      </header>
    </ThemeProvider>
  );
};
export default Header;
