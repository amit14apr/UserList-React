import React from "react";
import Slider from "react-slick";

const NestedSlider = () => {
  const settings = {
    // Slick settings for the nested slider
  };

  return (
    <div>
      <Tabs>
        <Tab label="Tab 1">
          <Slider {...settings}>
            {/* Nested slider content for Tab 1 */}
            <div>Slide 1</div>
            <div>Slide 2</div>
            <div>Slide 3</div>
          </Slider>
        </Tab>
        <Tab label="Tab 2">{/* Content for Tab 2 */}</Tab>
        {/* Add more tabs as needed */}
      </Tabs>
    </div>
  );
};

export default NestedSlider;
