import React, { useState, useEffect } from "react";
import "./FadeUpEaseIn.scss";

const FadeUpEaseIn = ({ children, duration }) => {
  console.log('duration', duration)
  const [isActive, setIsActive] = useState(false);
  useEffect(() => {
    const timeout = setTimeout(() => {
      setIsActive(true);
    }, duration);
    return () => clearTimeout(timeout);
  }, []);
  return (
    <div className={`fade-up-ease-in ${isActive ? "active" : ""}`}>
      {children}
    </div>
  );
};
export default FadeUpEaseIn;
