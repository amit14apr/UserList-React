import React from "react";
import { motion } from "framer-motion";

const AnimatedLogo = ({ src, flipDuration, rotationAngle }) => {
  return (
    <motion.div
      style={{
        width: "100px", // Adjust size as needed
        height: "100px",
        cursor: "pointer", // Optional: make logo clickable
      }}
      whileHover={{
        scale: 1.1, // Optional: scale logo on hover
      }}
      whileTap={{ scale: 0.9 }} // Optional: adjust scale on tap/click
      animate={{ rotate: rotationAngle }}
      transition={{ duration: flipDuration }}
    >
      <img src={src} alt="Logo" style={{ width: "100%", height: "100%" }} />
    </motion.div>
  );
};

export default AnimatedLogo;
