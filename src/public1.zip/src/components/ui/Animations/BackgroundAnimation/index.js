// AnimatedComponent.js
import React from "react";
import "./backgroundAnimation.scss";

const BackgroundAnimation = ({ shape, variant }) => {
  //Variants as below,
  // bouncy-balls
  // fade-in-boxes
  // fade-out-boxes
  // slide-down-boxes
  // box-to-circle

  //Shapes as below,
  // box
  // ball

  const divs = Array.from({ length: 10 }, (_, index) => (
    <div key={index} className={`${shape}`}></div>
  ));
  return <div className={`animated ${variant}`}>{divs}</div>;
};

export default BackgroundAnimation;
