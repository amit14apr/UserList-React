export { default as BounceSlideHorizontal } from "./BounceSlideHorizontal";
export { default as BounceSlideVertical } from "./BounceSlideVertical";
