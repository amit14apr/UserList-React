import React, { useEffect } from "react";
import { motion, useAnimation } from "framer-motion";

const BounceSlideHorizontal = ({ children, duration, distance }) => {
  const controls = useAnimation();

  useEffect(() => {
    controls.start({
      x: 0,
      opacity: 1,
      transition: { duration, type: "spring", stiffness: 120, damping: 10 },
    });
  }, [controls, duration]);

  return (
    <motion.div initial={{ x: distance, opacity: 0 }} animate={controls}>
      {children}
    </motion.div>
  );
};

export default BounceSlideHorizontal;
