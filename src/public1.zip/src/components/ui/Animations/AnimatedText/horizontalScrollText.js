import React from "react";
import styled from "styled-components";
import { motion, useScroll, useTransform } from "framer-motion";

const Title = styled(motion.h1)`
  font-family: var(--font-primary);
  color: white;
  font-size: 20em;
  z-index: 1;
  margin: 0;
  white-space: nowrap;
  margin-top: auto;
  transition: all 2s ease-in-out;
`;
const HorizontalScrollText = ({ children }) => {
  const { scrollYProgress } = useScroll();
  const x = useTransform(scrollYProgress, [0, 1], [0, 600]);
  return <Title style={{ x }}>{children}</Title>;
};

export default HorizontalScrollText;
