import React from "react";
import { motion } from "framer-motion";

const FadeAnimationHorizontal = ({ children, duration, distance }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: distance }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: duration }}
    >
      {children}
    </motion.div>
  );
};

export default FadeAnimationHorizontal;
