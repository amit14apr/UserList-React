import React, { useState } from "react";
import { motion } from "framer-motion";

const NavbarLeft = () => {
  const [isOpen, setIsOpen] = useState(false);

  const variants = {
    open: {
      x: 0,
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
        type: "spring",
      },
    },
    closed: {
      x: "-100%",
      opacity: 0,
      transition: {
        staggerChildren: 0.05,
        staggerDirection: -1,
        type: "spring",
      },
    },
  };

  const itemVariants = {
    open: {
      x: 0,
      opacity: 1,
    },
    closed: {
      x: -50,
      opacity: 0,
    },
  };

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav>
      <button onClick={toggleMenu}>Toggle Menu</button>
      <motion.ul
        className={`menu ${isOpen ? "open" : ""}`}
        variants={variants}
        initial="closed"
        animate={isOpen ? "open" : "closed"}
      >
        <motion.li variants={itemVariants}>Home</motion.li>
        <motion.li variants={itemVariants}>About</motion.li>
        <motion.li variants={itemVariants}>Services</motion.li>
        <motion.li variants={itemVariants}>Contact</motion.li>
      </motion.ul>
    </nav>
  );
};

export default NavbarLeft;
