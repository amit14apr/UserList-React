import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import "./Navbar.css"; // Import CSS for styling

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="navbar">
      <div className="navbar-logo">Logo</div>
      <div className="navbar-toggle" onClick={toggleMenu}>
        Menu
      </div>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="navbar-menu"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
          >
            <ul>
              <motion.li whileHover={{ scale: 1.1 }}>
                <a href="#">Home</a>
              </motion.li>
              <motion.li whileHover={{ scale: 1.1 }}>
                <a href="#">About</a>
              </motion.li>
              <motion.li whileHover={{ scale: 1.1 }}>
                <a href="#">Services</a>
              </motion.li>
              <motion.li whileHover={{ scale: 1.1 }}>
                <a href="#">Contact</a>
              </motion.li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
