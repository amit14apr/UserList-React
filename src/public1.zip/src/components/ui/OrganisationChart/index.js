import React, { useState } from "react";

const OrganizationChart = () => {
  // Define state for managing the organization chart data
  const [orgChartData, setOrgChartData] = useState([
    {
      id: 1,
      name: "CEO",
      children: [
        {
          id: 2,
          name: "Manager 1",
          children: [
            { id: 4, name: "Employee 1" },
            { id: 5, name: "Employee 2" },
          ],
        },
        {
          id: 3,
          name: "Manager 2",
          children: [
            { id: 6, name: "Employee 3" },
            { id: 7, name: "Employee 4" },
          ],
        },
      ],
    },
  ]);

  // Function to add a new node to the organization chart
  const addNode = (parentId, nodeName) => {
    const newNode = { id: Math.floor(Math.random() * 1000), name: nodeName };
    const updatedOrgChartData = orgChartData.map((node) => {
      if (node.id === parentId) {
        return { ...node, children: [...(node.children || []), newNode] };
      } else if (node.children) {
        return {
          ...node,
          children: addNodeToChildren(node.children, parentId, newNode),
        };
      }
      return node;
    });
    setOrgChartData(updatedOrgChartData);
  };

  // Utility function to add a new node to children recursively
  const addNodeToChildren = (children, parentId, newNode) => {
    return children.map((child) => {
      if (child.id === parentId) {
        return { ...child, children: [...(child.children || []), newNode] };
      } else if (child.children) {
        return {
          ...child,
          children: addNodeToChildren(child.children, parentId, newNode),
        };
      }
      return child;
    });
  };

  // Render function to recursively render nodes
  const renderNode = (node) => {
    return (
      <div key={node.id} style={{ marginLeft: 20 }}>
        <div>{node.name}</div>
        {node.children && node.children.map(renderNode)}
      </div>
    );
  };

  return (
    <div>
      <h2>Organization Chart</h2>
      <div>{orgChartData.map(renderNode)}</div>
      <button onClick={() => addNode(2, "New Employee")}>Add Employee</button>
    </div>
  );
};

export default OrganizationChart;
