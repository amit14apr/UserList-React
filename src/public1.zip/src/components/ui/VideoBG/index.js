import React from "react";
import "./VideoBG.scss";

const VideoBG = ({ videoId, videoClass, video, children }) => {
  return (
    <div className="main">
      <div className="overlay"></div>
      <video
        id={videoId}
        className={videoClass}
        src={video}
        autoPlay
        loop
        muted
      >
        Your browser does not support the video tag.
      </video>
      <div className="content">{children}</div>
    </div>
  );
};
export default VideoBG;
