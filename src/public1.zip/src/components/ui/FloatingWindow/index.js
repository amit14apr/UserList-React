import React, { forwardRef, useState } from 'react'
import "./taskList.scss";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import 'react-datepicker/dist/react-datepicker-cssmodules.css';

const TaskWidget = ({ isOpen, data, getClickedEvent, setIsWidgetOpen  }) => {
    const [isChecked, setIsChecked] = useState();
    const [startDate, setStartDate] = useState(new Date());
    const [endDate, setEndDate] = useState(new Date());

    const ExampleCustomInput = forwardRef(({ value, onClick, onChange }, ref) => (
        <input
          value={value}
          className="example-custom-input"
          onClick={onClick}
          onChange={onChange}
          ref={ref}
        ></input>
      ));


    
    console.log("🚀 ~ TaskWidget ~ data:", data)

    const clickedToMarkDone = (event, clickedData, index) => {
        setIsChecked(index)
        
        
        getClickedEvent(clickedData);
        
    }
    return (
        <div className={`floating-widget ${isOpen && 'show'}`}>
            <div id="widget-content">
                <div id="header">
                    <div id="header-content">
                        <div id='widget-close' onClick={() => setIsWidgetOpen(false)}>X</div>
                        <p id="header-text">DI&A Task List</p>
                        <div id="progress-bar">
                            <svg xmlns="http://www.w3.org/2000/svg" width="270" height="10" viewBox="0 0 307 10"
                                fill="none">
                                <path
                                    d="M0 5C0 2.51472 2.01472 0.5 4.5 0.5H302.5C304.985 0.5 307 2.51472 307 5C307 7.48528 304.985 9.5 302.5 9.5H4.5C2.01472 9.5 0 7.48528 0 5Z"
                                    fill="#D9D9D9" />
                            </svg>
                            <p id="pending-text">{data?.rows?.length} pending task</p>
                        </div>
                    </div>
                    <div className='calendar-container'>
                        <div className='calendar-item'>
                            {/* <DatePicker customInput={<ExampleCustomInput />} selected={startDate} onChange={(date) => setStartDate(date)} /> */}
                        </div>
                        <div className='calendar-item'>
                            {/* <DatePicker customInput={<ExampleCustomInput />} selected={endDate} onChange={(date) => setEndDate(date)} /> */}
                        </div>

                        <div className='calendar-item'>
                            <select className='filter-status'>
                                <option>All</option>
                                <option>Completed</option>
                                <option>Due</option>
                            </select>
                        </div>
                    </div>
                </div>
                {data?.rows?.map((element, index) => {
                    return(
                    <div style={{cursor: 'pointer'}} id="list-container" key={index} onClick={(event) => clickedToMarkDone(event, element, index)}>
                        <div className="list-content">
                            {/*<input type="radio" className="form-control" data-toggle="modal" data-target="#chatModal" />*/}
                            <div className="radioBox" data-toggle="modal" data-target="#chatModal">
                                <input type="radio" name="radio" checked={index == isChecked}  />
                                <span className="checkmark"></span>
                            </div>

                            <div className="textArea">
                                <div>
                                    <p className="taskName">{element.task_name}</p>

                                    <p className="helperText">{element.task_classification}</p>
                                </div>
                                <div className="dateTime">
                                    <p className="status">
                                        Due
                                    </p>
                                    <p className="date">
                                        {element.due_date}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                )})}


            </div>
        </div>
    )
}

export default TaskWidget;