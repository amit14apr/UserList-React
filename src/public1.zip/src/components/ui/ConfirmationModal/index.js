import React from 'react'

const ConfirmationModal = ({ isOpen, onClose }) => {
    
    return (
        <div class={`modal active ${isOpen && 'show'}`} style={{ display: isOpen ? 'block' : 'none' }} id="chatModal" tabindex="-1" role="dialog" aria-labelledby="chatModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-body text-center">
                        <div class="textMain">
                            Do you want to mark this as complete?
                        </div>

                        <div class="chatButtons">
                            <button type="button" class="btn btn-primary" data-dismiss="modal" onClick={() => onClose(true)}>Yes</button>
                            <button type="button" class="btn btn-secondary-ntv ms-1" data-dismiss="modal" onClick={() => onClose(false)}>No</button>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ConfirmationModal