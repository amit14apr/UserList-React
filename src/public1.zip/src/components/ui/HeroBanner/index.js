import BackgroundAnimation from "../Animations/BackgroundAnimation";
import "./banner.scss";


const HeroBanner = ({ title, subTitle, imgSrc, shape, variant }) => {
  return (
    <div className="innerBanner">      
      <div className="innerBanner-item">
        <div className="innerBanner-info">
          <div className="contentWrap">
            <h2>{title}</h2>
            <p>{subTitle}</p>
          </div>
        </div>
        <div className="innerBanner-bg">
          <img alt="#" src={imgSrc} />;
          {/* <BackgroundAnimation shape={shape} variant={variant} /> */}
        </div>
      </div>
    </div>
  );
};
export default HeroBanner;
