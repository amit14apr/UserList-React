// Recommendation.js
import React, { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";

const Recommendation = () => {
  const [recommendation, setRecommendation] = useState("");
  const history = useHistory();

  useEffect(() => {
    // Fetch recently visited routes/pages from local storage
    const recentlyVisited =
      JSON.parse(localStorage.getItem("recentlyVisited")) || [];

    // Generate recommendation based on recently visited routes/pages
    // You can implement your recommendation logic here
    if (recentlyVisited.length > 0) {
      const lastVisited = recentlyVisited[recentlyVisited.length - 1];
      switch (lastVisited) {
        case "/about":
          setRecommendation("You might also like the Contact page.");
          break;
        case "/contact":
          setRecommendation("You might also like the About page.");
          break;
        default:
          setRecommendation("No recommendation available.");
      }
    }
  }, []);

  useEffect(() => {
    // Persist recommendation to local storage
    localStorage.setItem("recommendation", recommendation);
  }, [recommendation]);

  return (
    <div>
      <h2>Recommendation</h2>
      <p>{recommendation}</p>
      <button onClick={() => history.push("/")}>Back to Home</button>
    </div>
  );
};

export default Recommendation;
