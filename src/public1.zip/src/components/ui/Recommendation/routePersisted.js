import React, { useState, useEffect } from "react";
import { Link, useHistory } from "react-router-dom";

const RecommendationPersisted = () => {
  const [recentlyVisited, setRecentlyVisited] = useState([]);

  useEffect(() => {
    // Retrieve recently visited routes from local storage
    const storedRecentlyVisited = localStorage.getItem("recentlyVisited");
    if (storedRecentlyVisited) {
      setRecentlyVisited(JSON.parse(storedRecentlyVisited));
    }
  }, []);

  const history = useHistory();

  const handleVisit = (route) => {
    // Add the visited route to recently visited
    const updatedRecentlyVisited = [
      route,
      ...recentlyVisited.filter((item) => item !== route),
    ].slice(0, 5);
    setRecentlyVisited(updatedRecentlyVisited);
    // Update local storage
    localStorage.setItem(
      "recentlyVisited",
      JSON.stringify(updatedRecentlyVisited)
    );
    // Navigate to the selected route
    history.push(route);
  };

  return (
    <div>
      <h2>Recommendation based on recently visited:</h2>
      <ul>
        {recentlyVisited.map((route, index) => (
          <li key={index}>
            <Link to={route}>{route}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};
export default RecommendationPersisted;
