//import "./footer.css";
import JNJLogo from "../../assets/img/logo/JNJ_Logo_SingleLine_Red_RGB.png";

const Footer = () => {
  return (
    <footer className="custom-footer">
      <div className="contentWrap">
        <div className="row align-items-center">
          <div className="col-6">
            <span className="navbar-brand">
              <img alt="#" src={JNJLogo} />
            </span>
          </div>
          <div className="col-6 text-end copyright-text">
            <small>
              All contents &copy; Johnsons & Johnsons Services, Inc. 2023. All
              Right Reserved.
            </small>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
