import React from "react";
import { useTheme } from "./index";
import Dark from "../../assets/img/theme/Dark.svg";
import Mid from "../../assets/img/theme/Medium.svg";
import Light from "../../assets/img/theme/Light.svg";

const ToggleThemeButton = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="toggleTheme" title="Toggle Theme">
      <span title="Light Mode"
        onClick={() => toggleTheme("lightMode")}
        style={{
          // backgroundColor: "#DEDEDE",
          // border: "none",
          margin: "0 4px",
          display: theme === "lightMode" ? "none" : "",
        }}
      >
        <img style={{ width: "20px" }} src={Light} alt="Light Mode" />
      </span>
      <span title="Mid Mode"
        onClick={() => toggleTheme("midMode")}
        style={{
          // backgroundColor: "#DEDEDE",
          // border: "none",
          margin: "0 4px",
          display: theme === "midMode" ? "none" : "",
        }}
      >
        <img style={{ width: "20px" }} src={Mid} alt="Mid Mode" />
      </span>
      <span title="Dark Mode"
        onClick={() => toggleTheme("darkMode")}
        style={{
          // backgroundColor: "#DEDEDE",
          // border: "none",
          margin: "0 4px",
          display: theme === "darkMode" ? "none" : "",
        }}
      >
        <img style={{ width: "20px" }} src={Dark} alt="Dark Mode" />
      </span>
      <span class="tooltiptext">Tooltip text</span>
    </div>
  );
};

export default ToggleThemeButton;
