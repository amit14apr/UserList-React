import { Link } from "react-router-dom";

const HomeDark = () => {
  return (
    <main className="darkMode">
      <section className="center-section miniNav">
        <div className="appArea">
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">
                    Homepage{" "}
                    <span className="text-uppercase badge badge-success">
                      Active{" "}
                    </span>
                  </h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <Link to="/cms_pages">Pages</Link>
                      </li>
                      <li
                        className="breadcrumb-item active"
                        aria-current="page"
                      >
                        Homepage
                      </li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                  <Link to="/cms_pages" className="btn btn-text">
                    {" "}
                    Cancel
                  </Link>
                  {/* <!-- <button className="btn btn-outline-primary ms-3" title="Delete" data-bs-toggle="modal"
                data-bs-target="#deleteModal"><b className="icon-trash-2"></b> Delete</button> --> */}
                  <Link
                    to="/Home_edit"
                    className="btn btn-primary ms-3"
                  >
                    <b className="icon-edit-3"></b> Edit Page
                  </Link>
                </div>
              </div>
            </div>
            <div className="sectionbody">
              <div className="heroBanner editContent">
                <div className="slider-for">
                  <div className="heroBanner-item">
                    <div className="heroBanner-bg">
                      <img
                        alt="#"
                        src={require("../../assets/img/home/banner/banner_01.png")}
                      />
                    </div>
                  </div>
                  <div className="heroBanner-item">
                    <div className="heroBanner-bg">
                      <img
                        alt="#"
                        src={require("../../assets/img/home/banner/banner_02.png")}
                      />
                    </div>
                  </div>
                  <div className="heroBanner-item">
                    <div className="heroBanner-bg">
                      <img
                        alt="#"
                        src={require("../../assets/img/home/banner/banner_03.png")}
                      />
                    </div>
                  </div>
                  <div className="heroBanner-item">
                    <div className="heroBanner-bg">
                      <img
                        alt="#"
                        src={require("../../assets/img/home/banner/banner_04.png")}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="exploreCover">
                <div className="contentWrap">
                  <div className="exploreTitle editContent">
                    <h3>
                      To learn more and explore the <b>digital team</b>,<br />{" "}
                      please use the <span>resources</span>
                      below!
                    </h3>
                  </div>
                  <div className="dashLinkWrap editContent">
                    <div className="dashLinkWrap-link">
                      <ul>
                        <li>
                          <a className="dashLink" href="dashboard.html">
                            <h4>
                              <span>DI&A Structure</span>
                            </h4>
                            <p>
                              Lorem ipsum dolor sit amet consectetur. Commodo
                              sit eget egestas ipsum bibendum sapien.
                            </p>
                            <span className="arrowBox">
                              <b className="icon-arrow-right"></b>
                            </span>
                          </a>
                        </li>

                        <li>
                          <a className="dashLink" href="dashboard.html">
                            <h4>
                              <span>Available data sources</span>
                            </h4>
                            <p>
                              Lorem ipsum dolor sit amet consectetur. Commodo
                              sit eget egestas ipsum bibendum sapien.
                            </p>
                            <span className="arrowBox">
                              <b className="icon-arrow-right"></b>
                            </span>
                          </a>
                        </li>
                        <li>
                          <a className="dashLink" href="dashboard.html">
                            <h4>
                              <span>Systems</span>
                            </h4>
                            <p>
                              Lorem ipsum dolor sit amet consectetur. Commodo
                              sit eget egestas ipsum bibendum sapien.
                            </p>
                            <span className="arrowBox">
                              <b className="icon-arrow-right"></b>
                            </span>
                          </a>
                        </li>
                        <li>
                          <a className="dashLink" href="dashboard.html">
                            <h4>
                              <span>Solutions portfolio</span>
                            </h4>
                            <p>
                              Lorem ipsum dolor sit amet consectetur. Commodo
                              sit eget egestas ipsum bibendum sapien.
                            </p>
                            <span className="arrowBox">
                              <b className="icon-arrow-right"></b>
                            </span>
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div className="dashLinkWrap-img">
                      <img
                        alt="#"
                        src={require("../../assets/img/home/img_33.jpg")}
                      />
                    </div>
                  </div>

                  <div className="dashLinkWrap editContent">
                    <div className="dashLinkWrap-img">
                      <img
                        alt="#"
                        src={require("../../assets/img/home/img_34.jpg")}
                      />
                    </div>
                    <div className="dashLinkWrap-link">
                      <ul>
                        <li>
                          <a className="dashLink" href="dashboard.html">
                            <h4>
                              <span>digital dictionary</span>
                            </h4>
                            <p>
                              Lorem ipsum dolor sit amet consectetur. Commodo
                              sit eget egestas ipsum bibendum sapien.
                            </p>
                            <span className="arrowBox">
                              <b className="icon-arrow-right"></b>
                            </span>
                          </a>
                        </li>

                        <li>
                          <a className="dashLink" href="dashboard.html">
                            <h4>
                              <span>analytics request</span>
                            </h4>
                            <p>
                              Lorem ipsum dolor sit amet consectetur. Commodo
                              sit eget egestas ipsum bibendum sapien.
                            </p>
                            <span className="arrowBox">
                              <b className="icon-arrow-right"></b>
                            </span>
                          </a>
                        </li>
                        <li>
                          <a className="dashLink" href="dashboard.html">
                            <h4>
                              <span>DI&A Team</span>
                            </h4>
                            <p>
                              Lorem ipsum dolor sit amet consectetur. Commodo
                              sit eget egestas ipsum bibendum sapien.
                            </p>
                            <span className="arrowBox">
                              <b className="icon-arrow-right"></b>
                            </span>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="exploreRecommend editContent">
                  <div className="contentWrap">
                    <div className="recommendWrap">
                      <h4>Recommendations</h4>
                      <p>Based on your previous search</p>
                      <div className="recommendGroup">
                        <a href="javascript:;" className=" button-prev">
                          <b className="icon-arrow-left"></b>
                        </a>

                        <ul>
                          <li className="recommendItem active">
                            <div className="recommendItem-over">
                              <h5>Revenue Credit Memo</h5>
                              <p>
                                Lorem ipsum dolor sit amet consectetur. Pharetra
                                phasellus tempus bibendum ante consectetur cum
                                ultricies.
                              </p>
                              <a
                                className="recommendItem-arrow"
                                target="_blank"
                                href="https://app.powerbi.com/groups/12374026-3f6d-4aa4-8ade-2b35d34c99bc/reports/c2d813e6-93a5-4cb9-bea6-9c326ab6b927/ReportSection?experience=power-bi"
                              >
                                <b className="icon-arrow-right"></b>
                              </a>
                            </div>
                          </li>

                          <li className="recommendItem">
                            <div className="recommendItem-over">
                              <h5>Critical Reports Dashboards</h5>
                              <p>
                                Lorem ipsum dolor sit amet consectetur. Pharetra
                                phasellus tempus bibendum ante consectetur cum
                                ultricies.
                              </p>
                              <a
                                className="recommendItem-arrow"
                                target="_blank"
                                href="https://app.powerbi.com/groups/12374026-3f6d-4aa4-8ade-2b35d34c99bc/reports/c2d813e6-93a5-4cb9-bea6-9c326ab6b927/ReportSection?experience=power-bi"
                              >
                                <b className="icon-arrow-right"></b>
                              </a>
                            </div>
                            <img
                              className="recommendItem-bg"
                              alt="#"
                              src={require("../../assets/img/home/img_20.jpg")}
                            />
                          </li>

                          <li className="recommendItem">
                            <div className="recommendItem-over">
                              <h5>Revenue Price Master File</h5>
                              <p>
                                Lorem ipsum dolor sit amet consectetur. Pharetra
                                phasellus tempus bibendum ante consectetur cum
                                ultricies.
                              </p>
                              <a
                                className="recommendItem-arrow"
                                target="_blank"
                                href="https://app.powerbi.com/groups/12374026-3f6d-4aa4-8ade-2b35d34c99bc/reports/c2d813e6-93a5-4cb9-bea6-9c326ab6b927/ReportSection?experience=power-bi"
                              >
                                <b className="icon-arrow-right"></b>
                              </a>
                            </div>
                            <img
                              className="recommendItem-bg"
                              alt="#"
                              src={require("../../assets/img/home/img_23.jpg")}
                            />
                          </li>

                          <li className="recommendItem">
                            <div className="recommendItem-over">
                              <h5>Revenue Price Override</h5>
                              <p>
                                Lorem ipsum dolor sit amet consectetur. Pharetra
                                phasellus tempus bibendum ante consectetur cum
                                ultricies.
                              </p>
                              <a
                                className="recommendItem-arrow"
                                target="_blank"
                                href="https://app.powerbi.com/groups/12374026-3f6d-4aa4-8ade-2b35d34c99bc/reports/c2d813e6-93a5-4cb9-bea6-9c326ab6b927/ReportSection?experience=power-bi"
                              >
                                <b className="icon-arrow-right"></b>
                              </a>
                            </div>
                            <img
                              className="recommendItem-bg"
                              alt="#"
                              src={require("../../assets/img/home/img_22.jpg")}
                            />
                          </li>

                          <li className="recommendItem">
                            <div className="recommendItem-over">
                              <h5>Critical Reports Dashboard5</h5>
                              <p>
                                Lorem ipsum dolor sit amet consectetur. Pharetra
                                phasellus tempus bibendum ante consectetur cum
                                ultricies.
                              </p>
                              <a
                                className="recommendItem-arrow"
                                target="_blank"
                                href="https://app.powerbi.com/groups/12374026-3f6d-4aa4-8ade-2b35d34c99bc/reports/c2d813e6-93a5-4cb9-bea6-9c326ab6b927/ReportSection?experience=power-bi"
                              >
                                <b className="icon-arrow-right"></b>
                              </a>
                            </div>
                            <img
                              className="recommendItem-bg"
                              alt="#"
                              src={require("../../assets/img/home/img_21.jpg")}
                            />
                          </li>

                          <li className="recommendItem">
                            <div className="recommendItem-over">
                              <h5>Revenue Price Master File</h5>
                              <p>
                                Lorem ipsum dolor sit amet consectetur. Pharetra
                                phasellus tempus bibendum ante consectetur cum
                                ultricies.
                              </p>
                              <a
                                className="recommendItem-arrow"
                                target="_blank"
                                href="https://app.powerbi.com/groups/12374026-3f6d-4aa4-8ade-2b35d34c99bc/reports/c2d813e6-93a5-4cb9-bea6-9c326ab6b927/ReportSection?experience=power-bi"
                              >
                                <b className="icon-arrow-right"></b>
                              </a>
                            </div>
                            <img
                              className="recommendItem-bg"
                              alt="#"
                              src={require("../../assets/img/home/img_19.jpg")}
                            />
                          </li>
                        </ul>
                        <a href="javascript:;" className=" button-next">
                          <b className="icon-arrow-right"></b>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default HomeDark;
