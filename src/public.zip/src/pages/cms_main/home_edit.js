import { useFieldArray, useForm } from "react-hook-form"
import BannerTemplate from "./BannerTemplate";
import { useEffect, useState } from "react";
import { COCKPIT_BASE_URL, updateContent } from "../../utils/helper";
import useFetch from "../../hooks/useFetch";
import { initialData } from "./initialData";
import axios from 'axios';

const Home_edit = () => {


  let tempData = []
  const { data, loading, error } = useFetch(`${COCKPIT_BASE_URL}/homepage/homepage/0`);
  // const { response,  errorUpload } = useUpload(`${COCKPIT_BASE_URL}/upload`);
  // const [dataFetched, setDataFetched] = useState(data?.data);
  console.log("🚀 ~ data:", data)


  const { register, handleSubmit, control } = useForm({
    defaultValues: initialData,
    values: data?.data
  })

  const { fields, append, remove } = useFieldArray({
    control,
    name: "bannerData"
  });

  const { fields: feldsDetail, append: appendDetail, remove: removeDetail } = useFieldArray({
    control,
    name: "detail"
  });

  const { fields: fieldsPages, append: appendPages, remove: removePages } = useFieldArray({
    control,
    name: "pages"
  });

  

  const addBanner = () => {

    append({
      initialData
    })
  };
  const onSubmit = (data) => {
    console.log("🚀 ~ onSubmit ~ tempData:", tempData)
    console.log("🚀 ~ data:", data)
    const { detail, bannerData: banners, pages, ...rest } = data;
    const newData = { ...detail, banners, ...rest };
    tempData.forEach((element, index) => {
      if (element.requestFor === 'banner') {
        newData.banners.forEach((item, vaue) => {
          if (item.bannerid === element.bannerid) {
            console.log("🚀 ~ newData.banners.forEach ~ item.bannerid:", item.bannerid)
            item.bannerimage = element.url;
          }
        })
      } else {

        console.log("🚀 ~ tempData.forEach ~ element.url:", element.url)
        console.log("🚀 ~ tempData.forEach ~ newData[tempData.requestFor]:", newData[element.requestFor])
        newData[element.requestFor] = element.url;
      }
    })
    console.log("🚀 ~ onSubmit ~ newData:", newData)
   updateContent('homepage/homepage/0', newData).then(response => console.log(response)).catch(error => console.log(error));

    
  }

  const onImageSelect = (event, field, requestFor) => {
    
    const formData = new FormData();
    const token = JSON.parse(localStorage.getItem('token'))[0].idToken;
    formData.append('file', event.target.files[0]);
    formData.append("filepath", "images/banners/");
    const source = axios.CancelToken.source();
    axios.post("https://dev.cockpit.jnj.com/api/pages/upload", formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        'Authorization': token,
        'url':'cms'
        
      }
    }, { cancelToken: source.token })
      .then(res => {
        console.log(data?.data?.bannerData);
        console.log("🚀 ~ onImageSelect ~ res:", res.data.url);
        if (requestFor == 'banner') {
          data?.data?.bannerData.forEach(element => {
            if (element.bannerid == field.bannerid) {
              tempData.push({ "requestFor": requestFor, "bannerid": field.bannerid, 'url': res.data.url })
            }
          })

        } else {
          tempData.push({ requestFor: requestFor, 'url': res.data.url })
        }
      })

      .catch(err => {
        console.log("🚀 ~ onImageSelect ~ err:", err)
      })
  }

  // useEffect(() => {

  //   setDataFetched(data);
  //   console.log("🚀 ~ useEffect ~ error:", error)
  // }, []);

  // useEffect(() => {

  //   if (dataFetched) {
  //     const { bannerData, details } = dataFetched;
  //     console.log("🚀 ~ useEffect ~ details:", details)
  //     console.log("🚀 ~ useEffect ~ bannerData:", bannerData)
  //     setBannerSet(bannerData);
  //     setPageDetails(details);
  //   }

  // }, [dataFetched])


  return (
    <section className="center-section miniNav">
      <div className="appArea">
        <div className="contentWrap">
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">Edit Homepage</h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <a href="/digital-innovation-analytics">Pages</a>
                      </li>
                      <li className="breadcrumb-item">
                        <a href="/digital-innovation-analytics/homepage">Homepage</a>
                      </li>
                      <li className="breadcrumb-item active" aria-current="page">
                        Edit
                      </li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                  <a className="btn btn-text" title="Cancel" href="/digital-innovation-analytics/homepage">
                    {" "}
                    Cancel
                  </a>
                  {/*<button className="btn btn-outline-primary ms-3" title="Save as Draft"><b className="icon-save"></b>Save as Draft</button>*/}
                  <button className="btn btn-primary ms-3" type="submit" >

                    Publish

                  </button>
                </div>
              </div>
            </div>
            <div className="sectionbody">
              <div className="contentBox">
                <div>
                  <div className="row align-items-center pb-4 pt-3">
                    <div className="col-6">
                      <h2 className="contentBox-title p-0">Banner</h2>
                    </div>
                    <div className="col-6 text-end">
                      {/* <a
                        title="Add New Banner"
                        className="btn btn-outline-primary"
                        data-bs-toggle="modal"
                        data-bs-target="#bannerModal"
                        onClick={addBanner}
                      >
                        {" "}
                        Add New Banner
                      </a> */}
                    </div>
                  </div>



                  <div className="pt-2 pb-2">
                    {fields.map((field, index) => (
                      <div key={field.id}>
                        <div className="p-3 innerBox mb-3">
                          <div className="row ">
                            <div className="col-auto pt-4">{index + 1}.</div>
                            <div className="col">
                              <div className="row">
                                <div className="col-4">
                                  <div className="form-group mb-3">
                                    <label className="form-label">Banner Name</label>
                                    <div>
                                      <input {...register(`bannerData.${index}.bannername`, { required: true })} type="text" className="form-control" />
                                    </div>
                                  </div>
                                </div>

                                <div className="col-4">
                                  <div className="form-group mb-3">
                                    <label className="form-label">Banner Link</label>
                                    <div>
                                      <input {...register(`bannerData.${index}.bannerlink`, { required: true })} type="text" className="form-control" />
                                    </div>
                                  </div>
                                </div>


                                <div className="col-4">
                                  <div className="form-group mb-3">
                                    <label className="form-label">Banner Image</label>
                                    <div>
                                      <input {...register(`bannerData.${index}.bannerimage`, { required: false })} onChange={event => onImageSelect(event, field, 'banner')} type="file" className="form-control" />
                                    </div>
                                  </div>
                                </div>

                                {/*<div className="col-4">
                                  <div className="form-group mb-3">
                                    <label className="form-label">Banner Title</label>
                                    <div>
                                      <input {...register(`bannerData.${index}.bannerdescription`, { required: true })} type="text" className="form-control" />
                                    </div>
                                  </div>
                    </div>*/}

                                <div className="col-12">
                                  <div className="form-group mb-3">
                                    <label className="form-label">Banner Text <small className="text-lowercase">(Max. Character 480)</small></label>
                                    <div>
                                      <textarea maxLength={480}  {...register(`bannerData.${index}.bannerdescription`, { required: true })} className="form-control" />
                                    </div>
                                  </div>
                                </div>

                              </div>

                            </div>




                          </div>
                        </div>
                      </div>
                    ))}

                    {/*{data?.data?.bannerData?.map((item, index = 1) => (
                      <BannerTemplate number={index} key={item.bannerid} bannerMetaData={item}  />
                    ))}*/}
                  </div>
                </div>

                <hr className="mb-3" />

                <div>
                  <h2 className="contentBox-title">Title</h2>
                  <div className="pt-2 pb-2">
                    <div className="row align-items-center pb-4">
                      <div className="col">
                        <textarea className="form-control" {...register("detail.title", { required: true })}  />
                      </div>
                    </div>
                  </div>
                </div>

                <hr className="mb-3" />

                <div>
                  <h2 className="contentBox-title">Page Links Images</h2>
                  <div className="pt-2 pb-2">
                    <div className="row align-items-center pb-4">
                      <div className="col">
                        <div className="form-group">
                          <label className="form-label">Right Side Banner</label>
                          <div>
                            <input {...register("detail.homerightimage", { required: false })} onChange={event => onImageSelect(event, {}, 'homerightimage')} type="file" className="form-control"  />

                          </div>
                        </div>
                      </div>
                      <div className="col">
                        <div className="form-group">
                          <label className="form-label">Left Side Banner</label>
                          <div>
                            <input {...register("detail.homeleftimage", { required: false })} onChange={event => onImageSelect(event, {}, 'homeleftimage')} type="file" className="form-control"  />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="mb-3" />

                <div>
                  <h2 className="contentBox-title">Recommendations</h2>
                  <div className="pt-2 pb-2">
                    <div className="row align-items-center pb-4">
                      <div className="col">
                        <div className="form-group">
                          <label className="form-label">Title</label>
                          <div>
                            <input
                              {...register("detail.recomendationtitle", { required: true })}
                              type="text"
                              
                              className="form-control"

                            />
                          </div>
                        </div>
                      </div>

                      <div className="col">
                        <div className="form-group">
                          <label className="form-label">Sub-Title</label>
                          <div>
                            <input
                              {...register("detail.recomendationsubtitle", { required: true })}
                              type="text"
                              className="form-control"
                              

                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
{/*       
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div role="document" class="modal-dialog modal-dialog-centered modal-sm">
      <div class="modal-content msgContent">
        <div class="modal-body">
          <button class="close btn-close" data-bs-dismiss="modal" aria-label="Close" type="button"></button>
          <h2 class="msgContent-title">Confirmation</h2>
          <p class="msgContent-text">Are you sure you want to delete?</p>
        </div>
        <div class="modal-footer justify-content-end ">
          <button type="button" data-bs-dismiss="modal" class="btn btn-text"> Cancel </button>
          <button type="button" class="btn btn-primary">Delete</button>
        </div>
      </div>
    </div>
  </div> */}
     
    </section>
    
  );
};

export default Home_edit;
