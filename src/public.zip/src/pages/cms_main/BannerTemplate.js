import React from 'react';
import { useFieldArray, useForm } from "react-hook-form"


const BannerTemplate = ({ number, bannerMetaData }) => {
  // console.log("🚀 ~ BannerTemplate ~ number:", number)
  // console.log("🚀 ~ BannerTemplate ~ bannerMetaData:", bannerMetaData)s

  const { register, handleSubmit, control } = useForm();

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'banners'
  });

  const onSubmit = (data) => {
  console.log("🚀 ~ onSubmit ~ data:", data)

  }


  return (
    <form onChange={handleSubmit(onSubmit)}>
    <div className="p-3 innerBox mb-3">
      <div class="row ">
        <div class="col-auto pt-4"><b class="icon-more-vertical"></b> {number + 1}.</div>
        <div class="col">
          <div class="row">
            <div class="col-4">
              <div class="form-group mb-3">
                <label class="form-label">Banner Name</label>
                <div>
                  <input {...register(`banners${number}bannername`, { required: true })} type="text" class="form-control" defaultValue={bannerMetaData?.bannername} />
                </div>
              </div>
            </div>

            <div class="col-4">
              <div class="form-group mb-3">
                <label class="form-label">Banner Link</label>
                <div>
                  <input  {...register(`banners${number}bannerlink`, { required: true })}  type="text" class="form-control" defaultValue={bannerMetaData.bannerlink} />
                </div>
              </div>
            </div>


            <div class="col-4">
              <div class="form-group mb-3">
                <label class="form-label">Banner Image</label>
                <div>
                  <input type="file" class="form-control" />
                </div>
              </div>
            </div>

            {/*<div class="col-4">
                              <div class="form-group mb-3">
                                <label class="form-label">Banner Title</label>
                                <div>
                                  <input name={`banners[0].bannerTitle`} ref={register()} type="text" class="form-control" defaultValues="Our Super-Personalized Solutions the Future of Healthcare?" />
                                </div>
                              </div>
                            </div> */}
            <div class="col-12">
              <div class="form-group mb-3">
                <label class="form-label">Banner Text</label>
                <div>
                  <textarea  {...register(`banners${number}bannerdescription`, { required: true })} class="form-control" defaultValue={bannerMetaData.bannerdescription}></textarea>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>

    </div>
    </form>
  )
}

export default BannerTemplate