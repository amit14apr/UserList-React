import React from "react";
import { Link } from "react-router-dom";

function DashLinkGroup({ dashLink, dashBody, dashTitle }) {
  return (
    <div className="dashLinkWrap-link">
      <ul>
        {/* {dashLinkGroupItems.map((item) => { */}
          {/* return ( */}
            <li>
              <Link to={dashLink}>
                <a className="dashLink" href="">
                  <h4>
                    <span>{dashTitle}</span>
                  </h4>
                  <p>{dashBody}</p>
                  <span className="arrowBox">
                    <b className="icon-arrow-right"></b>
                  </span>
                </a>
              </Link>
            </li>
          {/* ); */}
        {/* })} */}
      </ul>
    </div>
  );
}
export default DashLinkGroup;
