import React from "react";
import RecommendationImage1 from "../../assets/img/home/img_01.png";
import RecommendationImage2 from "../../assets/img/home/img_20.png";
import RecommendationImage3 from "../../assets/img/home/img_23.jpg";
import RecommendationImage4 from "../../assets/img/home/img_22.png";
import RecommendationImage5 from "../../assets/img/home/img_21.jpg";
import RecommendationImage6 from "../../assets/img/home/img_19.png";

const Recommendations = ({recomendationData: item}) => {
  return (
    <div className="exploreRecommend">
      <div className="contentWrap">
        <div className="recommendWrap">
          <h4>{item?.recomendationtitle}</h4>
          <p>{item?.recomendationsubtitle}</p>
          <div className="recommendGroup">
            <a href="javascript:;" className=" button-prev">
              <b className="icon-arrow-left"></b>
            </a>

            <ul>
              <li className="recommendItem active">
                <div className="recommendItem-over">
                  <h5>Revenue Credit Memo</h5>
                  <p>
                    Lorem ipsum dolor sit amet consectetur. Pharetra phasellus
                    tempus bibendum ante consectetur cum ultricies.
                  </p>
                  <a
                    className="recommendItem-arrow"
                    target="_blank"
                    href="solution_portfolio_.html"
                  >
                    <b className="icon-arrow-right"></b>
                  </a>
                </div>
                <img
                  className="recommendItem-bg"
                  alt="#"
                  src={RecommendationImage1}
                />
              </li>

              <li className="recommendItem">
                <div className="recommendItem-over">
                  <h5>Trial Balance (TB) Dashboard</h5>
                  <p>
                    Lorem ipsum dolor sit amet consectetur. Pharetra phasellus
                    tempus bibendum ante consectetur cum ultricies.
                  </p>
                  <a
                    className="recommendItem-arrow"
                    target="_blank"
                    href="solution_portfolio_.html"
                  >
                    <b className="icon-arrow-right"></b>
                  </a>
                </div>
                <img
                  className="recommendItem-bg"
                  alt="#"
                  src={RecommendationImage2}
                />
              </li>

              <li className="recommendItem">
                <div className="recommendItem-over">
                  <h5>General Ledger (GL) Account Fluctuation</h5>
                  <p>
                    Lorem ipsum dolor sit amet consectetur. Pharetra phasellus
                    tempus bibendum ante consectetur cum ultricies.
                  </p>
                  <a
                    className="recommendItem-arrow"
                    target="_blank"
                    href="solution_portfolio_.html"
                  >
                    <b className="icon-arrow-right"></b>
                  </a>
                </div>
                <img
                  className="recommendItem-bg"
                  alt="#"
                  src={RecommendationImage3}
                />
              </li>

              <li className="recommendItem">
                <div className="recommendItem-over">
                  <h5>Advanced Payments Dashboard</h5>
                  <p>
                    Lorem ipsum dolor sit amet consectetur. Pharetra phasellus
                    tempus bibendum ante consectetur cum ultricies.
                  </p>
                  <a
                    className="recommendItem-arrow"
                    target="_blank"
                    href="solution_portfolio_.html"
                  >
                    <b className="icon-arrow-right"></b>
                  </a>
                </div>
                <img
                  className="recommendItem-bg"
                  alt="#"
                  src={RecommendationImage4}
                />
              </li>

              <li className="recommendItem">
                <div className="recommendItem-over">
                  <h5>AM14 - Permanent Privilege Access Monitoring</h5>
                  <p>
                    Lorem ipsum dolor sit amet consectetur. Pharetra phasellus
                    tempus bibendum ante consectetur cum ultricies.
                  </p>
                  <a
                    className="recommendItem-arrow"
                    target="_blank"
                    href="solution_portfolio_.html"
                  >
                    <b className="icon-arrow-right"></b>
                  </a>
                </div>
                <img
                  className="recommendItem-bg"
                  alt="#"
                  src={RecommendationImage5}
                />
              </li>
              <li className="recommendItem">
                <div className="recommendItem-over">
                  <h5>Management Reporting Suite</h5>
                  <p>
                    Lorem ipsum dolor sit amet consectetur. Pharetra phasellus
                    tempus bibendum ante consectetur cum ultricies.
                  </p>
                  <a
                    className="recommendItem-arrow"
                    target="_blank"
                    href="solution_portfolio_.html"
                  >
                    <b className="icon-arrow-right"></b>
                  </a>
                </div>
                <img
                  className="recommendItem-bg"
                  alt="#"
                  src={RecommendationImage6}
                />
              </li>
            </ul>
            <a href="javascript:;" className=" button-next">
              <b className="icon-arrow-right"></b>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Recommendations;
