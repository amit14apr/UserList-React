import HeroImage1 from "../../assets/img/home/banner/Jnj_hero_banner2-.jpg";
import HeroImage2 from "../../assets/img/home/banner/Jnj_hero_banner3.jpg";
import HeroImage3 from "../../assets/img/home/banner/Jnj_hero_banner1-.jpg";
import HeroImage4 from "../../assets/img/home/banner/Our-Mission_main-page-Banner-.jpg";
export const HeroCarouselItems = [
  {
    id: 1,
    src: "",
    alt: "",
    name: "",
    title: "",
    description: "",
    url: "",
    children: [
      {
        id: 11,
        src: "../home/banner/banner_02.jpg",
        alt: "Image 1",
        name: "Announcement 01",
        title: "Announcement 01",
        description: "Announcement 01",
        url: "www.google.com",
        children: [{}]
      },
      {
        id: 12,
        src: "../home/banner/banner_02.jpg",
        alt: "Image 1",
        name: "Announcements",
        title: "Announcements 02",
        description: "Announcement 02",
        url: "www.google.com",
        children: [{}]
      },
      {
        id: 13,
        src: "../home/banner/banner_02.jpg",
        alt: "Image 1",
        name: "Announcements",
        title: "Announcements 03",
        description: "Announcements 03",
        url: "www.google.com",
        children: [{}]
      }

    ]
  },
  {
    id: 2,
    src: "../home/banner/banner_01.jpg",
    alt: "Image 1",
    name: "Newsletters",
    title: "Our Super-Personalized Solutions the Future of Healthcare?",
    description: "Our Super-Personalized Solutions the Future of Healthcare?",
    url: "www.google.com",
    children: [{}]
  },
  {
    id: 3,
    src: "../home/banner/banner_03.jpg",
    alt: "Image 1",
    name: "Toolkit",
    title: "Our Super-Personalized Solutions the Future of Healthcare?",
    description: "Our Super-Personalized Solutions the Future of Healthcare?",
    url: "www.google.com",
    children: [{}]
  },
  {
    id: 4,
    src: "../home/banner/banner_04.jpg",
    alt: "Image 1",
    name: "Our Mission",
    title: "Our Mission",
    description: "Enable the GA&A organization to become a best-in-class audit organization delivering data-driven, risk-based audit and assurance projects by: Ultimately, to optimize the benefit of the digital program and achieve the broader GA&A vision, there will be a focus on developing and shifting our mindset on how we approach audit and assurance.",
    url: "www.google.com",
    children: [{}]
  },

];
// export const HeroCarouselItems = [
//   {
//     image: HeroImage3,
//   },
//   {
//     image: HeroImage4,
//   },
//   {
//     image: HeroImage1,
//     text: "something here",
//     subtext: "some other thing",
//   },
//   {
//     image: HeroImage2,
//     text: "something here 1",
//     subtext: "some other thing 1",
//   },
//   {
//     image: HeroImage3,
//   },
//   {
//     image: HeroImage4,
//   },
// ];
export const DashLinkGroupItems1 = [
  {
    dashTitle: "DI&A Structure",
    dashBody:
      "DI&A is comprised of a group of skilled individuals focused on providing data-driven advanced analytics, robotic process automation, and artificial intelligence.",
    dashLink: "/solution_portfolio",
  },
  {
    dashTitle: "Available Solutions, Systems & Data Sources",
    dashBody:
      "The DI&A team has secured direct data access to many systems.  This has streamlined the process for providing meaningful digital solutions.",
    dashLink: "/solution_portfolio",
  },
  {
    dashTitle: "Systems and Software",
    dashBody:
      "The DI&A team offers dedicated support for critical systems and software to the Audit Program.",
    dashLink: "/solution_portfolio",
  },
  {
    dashTitle: "Solutions Portfolio",
    dashBody:
      "Readily Available digital solutions created to enable Auditor to gain insight, increase efficiency, increase effectiveness, and reduce manual",
    dashLink: "/solution_portfolio",
  },
];
export const DashLinkGroupItems2 = [
  {
    dashTitle: "Analytic / Access Request Submission",
    dashBody:
      "The DI&A team is dedicated to providing Analytics, Automation, Artificial Intelligence and System Support for GA&A.  The Intake process is a streamline way to request support from the DI&A team.",
    dashLink: "/solution_portfolio",
  },
];
