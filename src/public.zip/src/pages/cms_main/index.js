import React, { useEffect } from "react";
import $ from "jquery";
import "jquery-ui-dist/jquery-ui";
import "./home.scss";
import HeroCarousel from "../../components/ui/HeroCarousel";
import Recommendations from "./recommendations";
import { Link } from "react-router-dom";
import Loader from "../../components/ui/Loader";



import { COCKPIT_BASE_URL } from "../../utils/helper";
import useFetch from "../../hooks/useFetch";

const Home = () => {
  const { data, loading, error } = useFetch(`${COCKPIT_BASE_URL}/homepage/homepage/0`);

  console.log("🚀 ~ Home ~ data:", data?.data?.detail)


  useEffect(() => {
    $(".recommendItem").click(function () {
      $(this).closest("ul").find("li").removeClass("active");
      $(this).addClass("active");
    });

    $(".button-next").click(function () {
      var $li = $(".recommendGroup .recommendItem");
      var currentIndex = $(".recommendGroup .active").index(
        ".recommendGroup .recommendItem"
      );
      $li.removeClass("active");
      $li.eq((currentIndex + 1) % $li.length).addClass("active");
    });

    $(".button-prev").click(function () {
      console.log("clicked");
      var $li = $(".recommendGroup .recommendItem");
      var currentIndex = $(".recommendGroup .active").index(
        ".recommendGroup .recommendItem"
      );
      $li.removeClass("active");
      $li.eq((currentIndex - 1) % $li.length).addClass("active");
    });
  }, []);
  return (
    <>
      <section className="content-section">
        <div className="exploreCover">
          <div className="contentWrap">

            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">
                    {data?.data?.detail?.pagename}
                    {
                      data?.data?.detail?.status ? (
                        <span className="text-uppercase badge badge-success">
                          Active{" "}
                        </span>
                      ) : (
                        <span className="text-uppercase badge badge-disable">
                          Inactive{" "}
                        </span>
                      )
                    }

                  </h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <a href="/digital-innovation-analytics">Pages</a>
                      </li>
                      <li className="breadcrumb-item active" aria-current="page">
                        {data?.data?.detail?.pagename}
                      </li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                  <a className="btn btn-text" title="Cancel" href="/digital-innovation-analytics">
                    {" "}
                    Cancel
                  </a>

                  <Link
                    to="/digital-innovation-analytics/homepage/edit"
                    className="btn btn-primary ms-3"
                  >
                    <b className="icon-edit-3"></b> Edit Page
                  </Link>
                </div>
              </div>
            </div>
            {!loading ? (
              <section className="content-section">
                <div data-aos="fade-up">
                  {data?.data?.bannerData && <HeroCarousel items={data?.data?.bannerData} loading={loading} />}
                </div>
                <div className="exploreCover">
                  <video id="bgVideo_" class="bgVideo" autoplay loop muted>
                    <source
                      src={require("../../assets/video/background.mp4")}
                      type="video/mp4"
                    />
                  </video>
                  <div className="contentWrap">
                    <div className="exploreTitle">
                      <h3 data-aos="fade-up">
                        To learn more and explore the <b>digital team</b>,<br />{" "}
                        please use the <span>resources </span>
                        below!
                      </h3>
                    </div>
                    <div class="dashLinkWrap" data-aos="fade-up" data-aos-delay="100">
                      <div
                        class="dashLinkWrap-link"
                        data-aos="fade-up"
                        data-aos-delay="700"
                      >
                        <ul>
                          {data?.data?.pages
                            ?.reverse()
                            .slice(0, 4)
                            .map((el, i) => (
                              <li key={i}>
                                <Link class="dashLink" to={el.bannerlink}>
                                  <h4>
                                    <span>{el.bannername}</span>
                                  </h4>
                                  <p>{el.bannerdescription}</p>
                                  <span class="arrowBox">
                                    <b class="icon-arrow-right"></b>
                                  </span>
                                </Link>
                              </li>
                            ))}
                        </ul>
                      </div>
                      <div class="dashLinkWrap-img">
                        <img
                          alt="#"
                          src={require("../../assets/img/home/img_33.jpg")}
                        />
                      </div>
                    </div>

                    <div class="dashLinkWrap" data-aos="fade-up" data-aos-delay="200">
                      <div class="dashLinkWrap-img">
                        <img
                          alt="#"
                          src={require("../../assets/img/home/img_34.jpg")}
                        />
                      </div>
                      {data?.data?.pages?.slice(4).map((el, i) => (
                        <div
                          class="dashLinkWrap-link"
                          key={i}
                          data-aos="fade-up"
                          data-aos-delay="700"
                        >
                          <ul>
                            <li>
                              <Link class="dashLink" to={el.bannerlink}>
                                <h4>
                                  <span>{el.bannername}</span>
                                </h4>
                                <p>{el.bannerdescription}</p>
                                <span class="arrowBox">
                                  <b class="icon-arrow-right"></b>
                                </span>
                              </Link>
                            </li>
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Recommendations recomendationData={data?.data?.detail} />
                  </div>
                </div>
              </section>
            ) : (
              <Loader />
            )}

          </div>
        </div>
      </section>

    </>
  );
};
export default Home;
