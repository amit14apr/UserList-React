import $ from "jquery";
import "jquery-ui-dist/jquery-ui";

const SAPCreditMemos = () => {
  $(document).on("click", ".tagBox", function () {
    var $dataID = $(this).attr("data-id");
    $(".tagBox").removeClass("active");
    $(this).toggleClass("active");
    console.log($dataID);

    if ($dataID == "All") {
      $(".dashboardArea-content ul li").show();
    } else {
      console.log("data-type=" + $dataID);
      $(".dashboardArea-content ul li").hide();
      $(".dashboardArea-content ul li[data-type=" + $dataID + "]").show();
    }
  });
  return (
    <section className="content-section">
      <div className="innerBanner">
        <div className="innerBanner-item">
          <div className="innerBanner-info">
            <div className="contentWrap">
              <h2>Solution Portfolio</h2>
              <p>Lorem ipsum dolor sit amet consectetur. .</p>
            </div>
          </div>
          <div className="innerBanner-bg">
            <img
              alt="#"
              src={require("../../assets/img/page_banners/solution_portfolio.png")}
            />
          </div>
        </div>
      </div>
      <div className="contentWrap">
        <div className="pageTemplate">
          <div className="pageTemplate-links">
            <ul>
              <li className="active">
                <a href="#">
                  Finance <b className="icon-chevron-right"></b>
                </a>

                <ul>
                  <li>
                    <a href="#">Revenue</a>
                    <ul>
                      <li>
                        <a href="#">SAP Credit Memos</a>
                      </li>
                      <li>
                        <a href="#">SAP Customer Master File</a>
                      </li>
                      <li>
                        <a href="#">SAP Price Override</a>
                      </li>
                      <li>
                        <a href="#">SAP Price Master File</a>
                      </li>
                      <li>
                        <a href="#">JDE Credit Memos</a>
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">Balance Sheet/Income Statement</a>
                  </li>
                  <li>
                    <a href="#">Critical Reports</a>
                  </li>

                  <li>
                    <a href="#">Trail Balance</a>
                  </li>

                  <li>
                    <a href="#">Management Reporting</a>
                  </li>
                  <li>
                    <a href="#">IT</a>
                  </li>
                  <li>
                    <a href="#">CA&amp;I</a>
                  </li>
                  <li>
                    <a href="#">Digital</a>
                  </li>
                  <li>
                    <a href="#">SOX IT</a>
                  </li>
                </ul>
              </li>
              <li>
                <a href="#">OSO</a>
              </li>
              <li>
                <a>SOX PMO</a>
              </li>
              <li>
                <a>SOX IT</a>
              </li>
              <li>
                <a>IT</a>
              </li>
              <li>
                <a>CA&D</a>
              </li>
              <li>
                <a>Digital</a>
              </li>
              <li>
                <a>Legal</a>
              </li>
              <li>
                <a>Management Reporting</a>
              </li>
            </ul>
          </div>
          <div className="pageTemplate-content withBg">
            <div className="systemTitle">
              <h3>SAP credit Memos </h3>
              <p>
                The Credit Memos Dashboard is populated directly from the SAP
                ERP system(s) with summary and risk views to assist auditors in
                risk-based sample selection. Using this dashboard allows the
                auditor to apply metrics and insights to easily identify
                potential exceptions.
              </p>
            </div>

            <div className="systemLinkSection">
              <div className="systemLinkSection-wrap">
                <h3>Report</h3>
                <div className="systemLinkSection-links">
                  <div className="systemLinkGroup-list">
                    <div className="systemLinkGroup">
                      <img
                        alt="#"
                        src={require("../../assets/img/link_left.png")}
                      />
                      <h4>Link to SAP Credit Memos Selection Screen</h4>
                      <a>
                        Click Here <b className="icon-chevrons-right"></b>
                      </a>
                    </div>

                    <div className="systemLinkGroup">
                      <img
                        alt="#"
                        src={require("../../assets/img/link_right.png")}
                      />
                      <h4>Link to SAP Credit Memos Selection Screen</h4>
                      <a>
                        Click Here <b className="icon-chevrons-right"></b>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 mb-2 systemXtra">
              <div className="row">
                <div className="col">
                  <h3>Dataset</h3>
                  <ul>
                    <li>SAP</li>
                    <li>WEBUAR</li>
                  </ul>
                </div>
                <div className="col">
                  <h3>Data Refresh</h3>
                  <ul>
                    <li>SAP</li>
                    <li>WEBUAR</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="contactList">
              <h3>Business Contact</h3>
              <ul>
                <li>
                  <div className="contactMember">
                    <div className="contactMember-img">
                      <img
                        alt="#"
                        src={require("../../assets/img/members/person_02.jpg")}
                      />
                    </div>
                    <div className="contactMember-info">
                      <h4>Mastalski, Trish [DPYUS]</h4>
                      <p>LEAD ANALYST GLOBAL </p>
                      <span>TeamMate + Admin</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div className="contactMember">
                    <div className="contactMember-img">
                      <img
                        alt="#"
                        src={require("../../assets/img/members/person_05.jpg")}
                      />
                    </div>
                    <div className="contactMember-info">
                      <h4>Mastalski, Trish [DPYUS]</h4>
                      <p>LEAD ANALYST GLOBAL </p>
                      <span>TeamMate + Admin</span>
                    </div>
                  </div>
                </li>
              </ul>
            </div>

            <div className="requestAccess">
              <div className="requestAccess-left">
                <h3>How To Request Access</h3>
                <p>
                  Request access for your engagement/audit using the SAP Credit
                  memo alteryx app In the link that opens, click Run, then fill
                  out the form, then click Run. If you can't access the
                  dashboard or Alteryx app, please reach out to the business
                  contact(s) listed on this page.
                </p>
                <a>
                  Click here <b className="icon-arrow-right-circle"></b>
                </a>
              </div>
              <div className="requestAccess-right">
                <img
                  alt="#"
                  src={require("../../assets/img/place_holder.png")}
                />
              </div>
            </div>

            <div className="trainingList">
              <h3>Training Materials & Documentation</h3>
              <ul>
                <li>
                  <div className="trainingItem">
                    <div className="trainingItem-img">
                      <img
                        alt="#"
                        src={require("../../assets/img/training_items/placeholder_01.png")}
                      />
                    </div>
                    <div className="trainingItem-info">
                      <p>
                        This resource supplies information on every dashboard
                        and their use in text format, rather than video along
                        with some hints.
                      </p>
                    </div>
                  </div>
                </li>

                <li>
                  <div className="trainingItem">
                    <div className="trainingItem-img">
                      <img
                        alt="#"
                        src={require("../../assets/img/training_items/placeholder_02.png")}
                      />
                    </div>
                    <div className="trainingItem-info">
                      <p>
                        This video outlines how to use the dashboard from filter
                        selection, navigation, and visualizations.
                      </p>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default SAPCreditMemos;
