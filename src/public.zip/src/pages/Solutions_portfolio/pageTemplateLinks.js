import useFetch from "../../hooks/useFetch";
import React, { useEffect, useState } from "react";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import { Link, useParams } from "react-router-dom";

const PageTemplateLinks = () => {
  const { id } = useParams();
  const [activeId, setActiveId] = useState({
    lone: "",
    ltwo: "",
    lthree: "",
  });

  console.log("activeId", activeId);
  const { error, data } = useFetch(`${COCKPIT_BASE_URL}/solutionPortfolio/10`);

  useEffect(() => {
    // setActiveId(id !== 10 && id);
  }, []);

  return (
    <div class="pageTemplate-links">
      <ul>
        {data?.data?.children?.map((el, i) => {
          return (
            <li
              onClick={() => setActiveId({ ...activeId, lone: el.slug })}
              className={el.slug == activeId.lone ? "active" : ""}
              key={`${el.slug}_${i}`}
            >
              <Link
                to={
                  el.children.length === 1
                    ? `/digital-innovation-analytics/${el.children[i]?.slug}`
                    : `/digital-innovation-analytics/${el.slug}`
                }
              >
                {el.pagename}
                <b class="icon-chevron-right"></b>
              </Link>
              <ul>
                {el.children.map((el1, i) => (
                  <li
                    onClick={() => {
                      setActiveId((prev) => ({ ...prev, ltwo: el1.slug }));
                    }}
                    key={`${el1.slug}_${i}`}
                    className={el1.slug == activeId.ltwo ? "active" : ""}
                  >
                    <Link to={`/digital-innovation-analytics/${el1.slug}`}>
                      {el1.pagename} <b class="icon-chevron-right"></b>
                    </Link>
                    <ul>
                      {el1.children.map((item, i) => (
                        <li
                          onClick={() =>
                            setActiveId((prev) => ({
                              ...prev,
                              lthree: item.slug,
                            }))
                          }
                          key={`${item.slug}_${i}`}
                          className={
                            item.slug == activeId.lthree ? "active" : ""
                          }
                        >
                          <Link
                            to={`/digital-innovation-analytics/solution-portfolio/dashboard/${item.slug}`}
                          >
                            {item.pagename}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </li>
                ))}
              </ul>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default PageTemplateLinks;
