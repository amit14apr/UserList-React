import { Link } from "react-router-dom";

const SolutionsPortfolioDark = () => {
  return (
    <main className="darkMode">
      <section className="center-section miniNav">
        <div className="appArea">
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">
                    Finance{" "}
                    <span className="text-uppercase badge badge-success">
                      Active{" "}
                    </span>
                  </h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <Link to="/cms_pages">Pages</Link>
                      </li>
                      <li className="breadcrumb-item">
                        <Link to="/solutions_portfolio">
                          Solution Portfolio
                        </Link>
                      </li>
                      <li
                        className="breadcrumb-item active"
                        aria-current="page"
                      >
                        Finance
                      </li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                  <Link to="/cms_pages" className="btn btn-text" title="Cancel">
                    {" "}
                    Cancel
                  </Link>

                  <Link
                    to="/solutions_portfolio_edit"
                    className="btn btn-primary ms-3"
                    title="Edit"
                  >
                    <b className="icon-edit-3"></b> Edit Page
                  </Link>
                </div>
              </div>
            </div>
            <div className="sectionbody">
              <div className="editContent">
                <div className="innerBanner">
                  <div className="innerBanner-item">
                    <div className="innerBanner-info">
                      <div className="contentWrap">
                        <h2>Solution Portfolio</h2>
                        <p>Lorem ipsum dolor sit amet consectetur. .</p>
                      </div>
                    </div>
                    <div className="innerBanner-bg">
                      <img
                        alt="#"
                        src={require("../../assets/img/page_banners/solution_portfolio.png")}
                      />
                    </div>
                  </div>
                </div>
                <div className="contentWrap">
                  <div className="pageTemplate">
                    <div className="pageTemplate-links">
                      <ul>
                        <li className="active">
                          <a href="#">
                            Finance <b className="icon-chevron-right"></b>
                          </a>
                        </li>
                        <li>
                          <a href="#">OSO</a>
                        </li>
                        <li>
                          <a>SOX PMO</a>
                        </li>
                        <li>
                          <a>SOX IT</a>
                        </li>
                        <li>
                          <a>IT</a>
                        </li>
                        <li>
                          <a>CA&D</a>
                        </li>
                        <li>
                          <a>Digital</a>
                        </li>
                        <li>
                          <a>Legal</a>
                        </li>
                        <li>
                          <a>Management Reporting</a>
                        </li>
                      </ul>
                    </div>
                    <div className="pageTemplate-content">
                      <h3>Finance</h3>
                      <ul className="pageItem-list">
                        <li>
                          <a className="pageItem" target="_blank" href="#">
                            <div className="pageItem-icon">
                              <img
                                alt="#"
                                src={require("../../assets/img/page_icons/icon_01.png")}
                              />
                            </div>
                            <div className="pageItem-info">
                              <h4>Revenue</h4>
                            </div>
                          </a>
                        </li>
                        <li>
                          <a className="pageItem" target="_blank" href="#">
                            <div className="pageItem-icon">
                              <img
                                alt="#"
                                src={require("../../assets/img/page_icons/icon_02.png")}
                              />
                            </div>
                            <div className="pageItem-info">
                              <h4>Balance Sheet/ Income Statement</h4>
                            </div>
                          </a>
                        </li>
                        <li>
                          <a className="pageItem" target="_blank" href="#">
                            <div className="pageItem-icon">
                              <img
                                alt="#"
                                src={require("../../assets/img/page_icons/icon_03.png")}
                              />
                            </div>
                            <div className="pageItem-info">
                              <h4>Critical Reports</h4>
                            </div>
                          </a>
                        </li>
                        <li>
                          <a className="pageItem" target="_blank" href="#">
                            <div className="pageItem-icon">
                              <img
                                alt="#"
                                src={require("../../assets/img/page_icons/icon_04.png")}
                              />
                            </div>
                            <div className="pageItem-info">
                              <h4>Trail Balance</h4>
                            </div>
                          </a>
                        </li>
                        <li>
                          <a className="pageItem" target="_blank" href="#">
                            <div className="pageItem-icon">
                              <img
                                alt="#"
                                src={require("../../assets/img/page_icons/icon_05.png")}
                              />
                            </div>
                            <div className="pageItem-info">
                              <h4>General Ledger Account Flux</h4>
                            </div>
                          </a>
                        </li>
                        <li>
                          <div className="pageItem">
                            <div className="pageItem-icon">
                              <img
                                alt="#"
                                src={require("../../assets/img/page_icons/icon_06.png")}
                              />
                            </div>
                            <div className="pageItem-info">
                              <h4>Manual Journal Entries</h4>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div className="pageItem">
                            <div className="pageItem-icon">
                              <img
                                alt="#"
                                src={require("../../assets/img/page_icons/icon_07.png")}
                              />
                            </div>
                            <div className="pageItem-info">
                              <h4>Advanced Payment</h4>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div className="pageItem">
                            <div className="pageItem-icon">
                              <img
                                alt="#"
                                src={require("../../assets/img/page_icons/icon_08.png")}
                              />
                            </div>
                            <div className="pageItem-info">
                              <h4>User Access</h4>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div className="pageItem">
                            <div className="pageItem-icon">
                              <img
                                alt="#"
                                src={require("../../assets/img/page_icons/icon_09.png")}
                              />
                            </div>
                            <div className="pageItem-info">
                              <h4>Payroll</h4>
                            </div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default SolutionsPortfolioDark;
