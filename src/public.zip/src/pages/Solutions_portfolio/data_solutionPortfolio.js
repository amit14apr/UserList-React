import PageTempImg1 from "../../assets/img/page_icons/icon_01.png";
import PageTempImg2 from "../../assets/img/page_icons/icon_02.png";
import PageTempImg3 from "../../assets/img/page_icons/icon_03.png";
import PageTempImg4 from "../../assets/img/page_icons/icon_04.png";
import PageTempImg5 from "../../assets/img/page_icons/icon_05.png";
import PageTempImg6 from "../../assets/img/page_icons/icon_06.png";
import PageTempImg7 from "../../assets/img/page_icons/icon_07.png";
import PageTempImg8 from "../../assets/img/page_icons/icon_08.png";
import PageTempImg9 from "../../assets/img/page_icons/icon_09.png";

export const PageTemplateContentItems = [
  {
    title: "Revenue",
    imgsrc: PageTempImg1,
  },
  {
    title: "Balance Sheet/ Income Statement",
    imgsrc: PageTempImg2,
  },
  {
    title: "Critical Reports",
    imgsrc: PageTempImg3,
  },
  {
    title: "Trail Balance",
    imgsrc: PageTempImg4,
  },
  {
    title: "General Ledger Account Flux",
    imgsrc: PageTempImg5,
  },
  {
    title: "Manual Journal Entries",
    imgsrc: PageTempImg6,
  },
  {
    title: "Advanced Payment",
    imgsrc: PageTempImg7,
  },
  {
    title: "User Access",
    imgsrc: PageTempImg8,
  },
  {
    title: "Payroll",
    imgsrc: PageTempImg9,
  },
];
