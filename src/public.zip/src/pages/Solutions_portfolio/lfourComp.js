// import PageTransition from "../../components/ui/Animations/PageTransition";
// import Slide from "../../components/ui/Animations/Slide";
// import StaggeredListItem from "../../components/ui/Animations/StaggeredListItem";

function LFour({ data }) {
  return (
    // <PageTransition>
      <div className="pageTemplate-content withBg" >
        {/* <Slide delay={0.3}>
              <Slide delay={0.5}> */}
                <div className="pageTemplate-content" style={{width: '100%', padding: '70px 0', position: 'relative'}}>
                  <div className="systemTitle">
                    <h3>{data?.detail?.pagename}</h3>
                    <p>{data?.detail?.description}</p>
                  </div>

                  <div className="systemLinkSection">
                    <div className="systemLinkSection-wrap">
                      <h3>System Links</h3>
                      {data?.banners.map(item => <div className="systemLinkSection-links">
                        <img
                          alt="#"
                          src={item.bannerimage}
                        />
                      </div>)}
                    </div>
                  </div>

                  <div className="contactList">
                    <h3>Business Contact</h3>
                    <ul>
                      {/* <StaggeredListItem> */}
                        {data?.systemBusinessContact?.map(item => <li><div className="contactMember">
                          <div className="contactMember-img">
                            <img
                              alt="#"
                              src={item?.profileimagepath}
                            />
                          </div>
                          <div className="contactMember-info">
                            <h4>{item?.name}</h4>
                            <p>{item?.designation} </p>
                            <span>{item?.groupname}</span>
                          </div>
                        </div></li>)}
                      {/* </StaggeredListItem> */}
                      {/* <!-- <li>
                <div className="contactMember">
                  <div className="contactMember-img"><img alt="#" src={require("assets/img/members/person_06.jpg")} /></div>
                  <div className="contactMember-info">
                    <h4>Mastalski, Trish [DPYUS]</h4>
                    <p>LEAD ANALYST GLOBAL </p>
                    <span>TeamMate + Admin</span>
                  </div>
                </div>
              </li>
              <li>
                <div className="contactMember">
                  <div className="contactMember-img"><img alt="#" src={require("assets/img/members/person_07.jpg")} /></div>
                  <div className="contactMember-info">
                    <h4>Mastalski, Trish [DPYUS]</h4>
                    <p>LEAD ANALYST GLOBAL </p>
                    <span>TeamMate + Admin</span>
                  </div>
                </div>
              </li> --> */}
                    </ul>
                  </div>

                  {/* <!-- <div className="requestAccess">
            <div className="requestAccess-left">
              <h3>How To Request Access</h3>
              <p><span>To request access to TeamMate+ use the form!</span></p>
              <p>TeamMate+ user Access form needs your permission to use the following, Please allow the permissions to
                proceed,</p>
              <a>Click here <b className="icon-arrow-right-circle"></b></a>
            </div>
            <div className="requestAccess-right">
              <img alt="#" src="assets/img/place_holder.png">
            </div>
          </div> --> */}
                  {/* <Slide delay={0.7}> */}
                    <div className="trainingList">
                      <h3>Training Materials & Documentation</h3>
                      <ul>
                        <li>
                          <div className="trainingItem">
                            <div className="trainingItem-img">
                              <img
                                alt="#"
                                src={require("../../assets/img/training_items/placeholder_01.png")}
                              />
                            </div>
                            <div className="trainingItem-info">
                              <p>
                                <span>TeamMate +</span> is a Windows-based Audit
                                Management System. designed to bring efficiency
                                and consistency to the entire audit/evaluation
                                process Of Globa
                              </p>
                            </div>
                          </div>
                        </li>

                        <li>
                          <div className="trainingItem">
                            <div className="trainingItem-img">
                              <img
                                alt="#"
                                src={require("../../assets/img/training_items/placeholder_02.png")}
                              />
                            </div>
                            <div className="trainingItem-info">
                              <p>
                                <span>TeamMate +</span> is a Windows-based Audit
                                Management System. designed to bring efficiency
                                and consistency to the entire audit/evaluation
                                process Of Globa
                              </p>
                            </div>
                          </div>
                        </li>

                        <li>
                          <div className="trainingItem">
                            <div className="trainingItem-img">
                              <img
                                alt="#"
                                src={require("../../assets/img/training_items/placeholder_03.png")}
                              />
                            </div>
                            <div className="trainingItem-info">
                              <p>
                                <span>TeamMate +</span> is a Windows-based Audit
                                Management System. designed to bring efficiency
                                and consistency to the entire audit/evaluation
                                process Of Globa
                              </p>
                            </div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  {/* </Slide> */}
                </div>
              {/* </Slide> */}
        {/* </Slide> */}
      </div>
    // </PageTransition>
  );
}

export default LFour;
