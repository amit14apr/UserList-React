import React from "react";
// import StaggeredListItem from "../../components/ui/Animations/StaggeredListItem";
import { Link } from "react-router-dom";

function PageTemplateContent({ pageTemplateContentItems = [], slugId }) {
  return (
    <div className="pageTemplate-content withBg">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="solution_portfolio_.html">Solution Portfolio</a>
        </li>
        <li class="breadcrumb-item active" aria-current="page">
          {pageTemplateContentItems?.detail?.pagename}
        </li>
      </ol>
      <div class="pageItem-wrap">
        <h3>{pageTemplateContentItems?.detail?.pagename}</h3>
        <ul className="pageItem-list">
          {pageTemplateContentItems?.children?.map((item, i) => {
            return (
              // <StaggeredListItem key={i} index={i}>
                <Link
                  className="pageItem"
                  to={
                    item.type !== "l4"
                      ? `/digital-innovation-analytics/solution-portfolio/${item.slug}`
                      : `/digital-innovation-analytics/solution-portfolio/dashboard/${item.slug}`
                  }
                >
                  <div className="pageItem-icon">
                    <img alt="#" src={item.thumnail} />
                  </div>
                  <div className="pageItem-info">
                    <h4>{item.pagename}</h4>
                  </div>
                </Link>
              // </StaggeredListItem>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
export default PageTemplateContent;
