import React, { useEffect, useState } from "react";
import HeroBanner from "../../components/ui/HeroBanner";
import SolutionPortfolioBG from "../../assets/img/page_banners/solution_portfolio.png";
import PageTemplateLinks from "./pageTemplateLinks";
import PageTemplateContent from "./pageTemplateContent";
import { PageTemplateContentItems } from "./data_solutionPortfolio";
// import PageTransition from "../../components/ui/Animations/PageTransition";
// import Slide from "../../components/ui/Animations/Slide";
import "../../styles/styles.scss";
import { COCKPIT_BASE_URL, visitedPagesTracker } from "../../utils/helper";
import useFetch from "../../hooks/useFetch";
import LFour from "./l4";
import { Link, useParams } from "react-router-dom";

const SolutionPortfolio = () => {
  // useEffect(() => {

  //   console.log(url)
  //   visitedPagesTracker({title:urlData[urlData.length - 1], path:url})
  // }, [])
  const url = window.location.pathname
  const urlData = url.split("/");
  const slugId = urlData[urlData.length - 1]
  console.log("🚀 ~ SolutionPortfolio ~ slugId:", slugId)
  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}/solutionPortfolio/${slugId}/0`
  );

  console.log("🚀 ~ SolutionPortfolio ~ data:", data)
  return (
    // <PageTransition>
    <>



      <section className="content-section">
        <div className="appArea">
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">
                    {data?.data?.detail?.pagename}{" "}
                    <span className="text-uppercase badge badge-success">
                      Active{" "}
                    </span>
                  </h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <Link to="/digital-innovation-analytics">Pages</Link>
                      </li>
                      <li className="breadcrumb-item">
                        <Link to="/solutions_portfolio">Solution Portfolio</Link>
                      </li>
                      <li className="breadcrumb-item active" aria-current="page">
                        {slugId}
                      </li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                  <Link to="/digital-innovation-analytics" className="btn btn-text" title="Cancel">
                    {" "}
                    Cancel
                  </Link>

                  <Link
                    to={`/digital-innovation-analytics/solution-portfolio/${slugId}/edit`}
                    className="btn btn-primary ms-3"
                    title="Edit"
                  >
                    <b className="icon-edit-3"></b> Edit Page
                  </Link>
                </div>
              </div>
            </div>
            <HeroBanner
              title={data?.data.banners[0].bannername}
              subTitle={data?.data.banners[0].bannerdescription}
              imgSrc={data?.data.banners[0].bannerimage}
              shape="box"
              variant="slide-down-boxes"
            />
          </div>
        </div>

        <div className="contentWrap">
          <div className="pageTemplate">
            <PageTemplateLinks />
            <PageTemplateContent parentSlug={slugId}
              pageTemplateContentItems={data?.data}
            />
          </div>
        </div>
      </section>
    </>
    // </PageTransition>
  );
};
export default SolutionPortfolio;
