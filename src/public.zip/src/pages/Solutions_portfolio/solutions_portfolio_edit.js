import { Link } from "react-router-dom";
import useFetch from "../../hooks/useFetch";
import { useFieldArray, useForm } from "react-hook-form";
import { COCKPIT_BASE_URL, updateContent } from "../../utils/helper";
import { initialData } from "./initialData";
import { useEffect } from "react";
const Solutions_portfolio_edit = () => {

  const url = window.location.pathname
  const urlData = url.split("/");
  const slugId = urlData[urlData.length - 2]

  let tempData = []
  const { data, loading, error } = useFetch(`${COCKPIT_BASE_URL}/solutionPortfolio/${slugId}/0`);

  console.log("🚀 ~ data:", data)


  const { register, handleSubmit, control } = useForm({
    defaultValues: initialData,
    values: data?.data
  })

  const { fields: detailField, append: a1, remove: r1 } = useFieldArray({
    control,
    name: "detail"
  });

  const { fields: requestFormsField, append: a2, remove: requestFormsRemove } = useFieldArray({
    control,
    name: "requestForms"
  });


  const onSubmit = data => {

    console.log("🚀 ~ onSubmit ~ data:", data)
    const { detail, banners, requestForms, ...rest } = data;
    banners.length = 0;


    const newData = { ...detail, requestforms: requestForms, banners, ...rest }
    console.log("🚀 ~ onSubmit ~ newData:", newData)
    
    updateContent(`/solutionPortfolio/${slugId}/0`, newData).then(response => console.log(response)).catch(error => console.log(error));

  }

  return (
    <section className="center-section miniNav">

      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="appArea">
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">Edit {slugId}</h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <Link to="/cms_pages">Pages</Link>
                      </li>
                      <li className="breadcrumb-item">
                        <Link to="/solutions_portfolio">Solution Portfolio</Link>
                      </li>
                      <li className="breadcrumb-item active" aria-current="page">
                        Finance
                      </li>

                      <li className="breadcrumb-item active" aria-current="page">
                        Edit
                      </li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                  <Link
                    to={`/digital-innovation-analytics/solution-portfolio/${slugId}`}
                    className="btn btn-text"
                    title="Cancel"
                  >
                    {" "}
                    Cancel
                  </Link>

                  {/*<button className="btn btn-outline-primary ms-3" title="Save as Draft"><b className="icon-save"></b>Save as Draft</button>*/}
                  <button type="submit" className="btn btn-primary ms-3" title="Publish" >
                    {" "}
                    Publish
                  </button>

                </div>
              </div>
            </div>
            <div className="sectionbody">
              <div className="contentBox">
                {/*
              f1.map((field, index) => (
                <div>
                <h2 className="contentBox-title">Banner</h2>
                <div className="pt-2 pb-2">
                  <div className="row align-items-center pb-4">

                    <div className="col">
                      <div className="form-group">
                        <label className="form-label">Banner Name</label>
                        <div>
                          <input
                            type="text"
                            className="form-control"
                            
                            {...register(`banners.${index}.bannername`, { required: false })}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="col">
                      <div className="form-group">
                        <label className="form-label">Banner Text</label>
                        <div>
                          <input
                            type="text"
                            className="form-control"
                            {...register(`banners.${index}.bannerdescription`, { required: false })}
                          />
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="form-group">
                        <label class="form-label">Banner Image</label>
                        <div>
                          <input type="file" class="form-control" {...register(`banners.${index}.bannerimage`, { required: false })} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              ))
            */}


                <div class="pt-3">
                  <div class="row align-items-center pb-4">
                    <div class="col-6">
                      <h2 class="contentBox-title p-0">Request Form</h2>
                    </div>
                    <div class="col-6 text-end"> </div>
                  </div>
                  <div class="pt-2 pb-2">
                    <div class="row align-items-center  ">
                      <div class="col-12 pb-2">
                        <div class="form-group mb-3">
                          <label class="form-label">Title</label>
                          <div>
                            <input type=" text" class="form-control"
                              {...register(`detail.title`, { required: false })} />
                          </div>
                        </div>
                      </div>
                      <div class="col-12 pb-2">
                        <div class="form-group mb-3">
                          <label class="form-label">Description</label>
                          <div>
                            <textarea {...register(`detail.description`, { required: false })}
                              class="form-control"></textarea>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      {
                        requestFormsField.map((field, index) => (
                          <div key={field.id} class="col-4">
                            <div class="p-3 innerBox mb-3">
                              <div class="row align-items-start">
                                <div class="col-12">
                                  <div class="form-group mb-3">
                                    <label class="form-label">Title</label>
                                    <div>
                                      <input type="text" class="form-control" {...register(`requestForms.${index}.title`, { required: false })} />
                                    </div>
                                  </div>
                                </div>
                                <div class="col-12">
                                  <div class="form-group mb-3">
                                    <label class="form-label">Description</label>
                                    <div>
                                      <input type="text" class="form-control" {...register(`requestForms.${index}.subtitle`, { required: false })} />
                                    </div>
                                  </div>
                                </div>
                                <div class="col-12">
                                  <div class="form-group mb-3">
                                    <label class="form-label">URL</label>
                                    <div>
                                      <input type="url" class="form-control" {...register(`requestForms.${index}.link`, { required: false })} />
                                    </div>
                                  </div>
                                </div>
                                <div class="col-12 text-end">
                                  <button class="btn btn-text ms-3"><b class="icon-trash-2" onClick={requestFormsRemove(index)}></b> Delete</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))
                      }


                      {
                        requestFormsField.length == 0 && (<div class="row">
                          <div class="col-4">
                            <div class="p-3 innerBox mb-3">
                              <div class="row align-items-start">
                                <div class="col-12">
                                  <div class="form-group mb-3">
                                    <label class="form-label">Title</label>
                                    <div>
                                      <input type="text" class="form-control" {...register(`requestForms.0.title`, { required: false })} />
                                    </div>
                                  </div>
                                </div>
                                <div class="col-12">
                                  <div class="form-group mb-3">
                                    <label class="form-label">Description</label>
                                    <div>
                                      <input type="text" class="form-control" {...register(`requestForms.0.subtitle`, { required: false })} />
                                    </div>
                                  </div>
                                </div>
                                <div class="col-12">
                                  <div class="form-group mb-3">
                                    <label class="form-label">URL</label>
                                    <div>
                                      <input type="url" class="form-control" {...register(`requestForms.0.link`, { required: false })} />
                                    </div>
                                  </div>
                                </div>
                                <div class="col-12 text-end">
                                  <button class="btn btn-text ms-3"><b class="icon-trash-2" ></b> Delete</button>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-4">
                            <div class="p-3 innerBox mb-3">
                              <div class="row align-items-start">
                                <div class="col-12">
                                  <div class="form-group mb-3">
                                    <label class="form-label">Title</label>
                                    <div>
                                      <input type="text" class="form-control" {...register(`requestForms.1.title`, { required: false })} />
                                    </div>
                                  </div>
                                </div>
                                <div class="col-12">
                                  <div class="form-group mb-3">
                                    <label class="form-label">Description</label>
                                    <div>
                                      <input type="text" class="form-control" {...register(`requestForms.1.subtitle`, { required: false })} />
                                    </div>
                                  </div>
                                </div>
                                <div class="col-12">
                                  <div class="form-group mb-3">
                                    <label class="form-label">URL</label>
                                    <div>
                                      <input type="url" class="form-control" {...register(`requestForms.1.link`, { required: false })} />
                                    </div>
                                  </div>
                                </div>
                                <div class="col-12 text-end">
                                  <button class="btn btn-text ms-3"><b class="icon-trash-2" ></b> Delete</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>)
                      }



                    </div>


                  </div>
                </div>
                <hr class="mb-3" />
                <div class="pt-3">
                  <div class="row align-items-center pb-4">
                    <div class="col-6">
                      <h2 class="contentBox-title p-0">Notes</h2>
                    </div>
                    <div class="col-6 text-end"> </div>
                  </div>
                  <div class="pt-2 pb-2">
                    <div class="row align-items-center">
                      <div class="col-12">
                        <div class="form-group mb-3">
                          <div>
                            <textarea class="form-control" {...register(`detail.notes`, { required: false })}> </textarea>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </section>
  );
};

export default Solutions_portfolio_edit;
