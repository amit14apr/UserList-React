import System_ from "./index_";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import useFetch from "../../hooks/useFetch";
import { Link, useParams } from "react-router-dom";
import { useLayoutEffect, useState } from "react";
const Systems = () => {


  const [slugId, setSlugId] = useState();

  const { data: navData } = useFetch(`${COCKPIT_BASE_URL}/navigation`);

  
  
  const url = window.location.pathname
  const urlData = url.split("/");
  const slugIdUrl = urlData[urlData.length - 1]
  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}/systemchild/${slugIdUrl}/0`
  );
  console.log("🚀 ~ Systems ~ data:", data)

  


  return (
    <section className="center-section miniNav">
      <div className="appNav">
        <a className="menuToggle">
          <b className="icon-menu"></b>
        </a>
        <ul>
          <li>
            <a title="GA&A Portals" href="index.html">
              <i className="icon-folder"></i>
              <span>GA&A Portals</span>
            </a>
          </li>
        </ul>
      </div>
      <div className="appArea">
        <div className="contentWrap">
          <div className="sectionHead">
            <div className="row align-items-center">
              <div className="col-6">
                <h1 className="pageTitle">
                  {data?.data?.detail.pagename}{" "}
                  <span className="text-uppercase badge badge-success">
                    Active{" "}
                  </span>
                </h1>
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                      <a href="/digital-innovation-analytics">Pages</a>
                    </li>
                    <li className="breadcrumb-item">
                      <a href="#">System</a>
                    </li>
                    <li className="breadcrumb-item active" aria-current="page">
                      {data?.data?.detail.pagename}
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
          </div>
          <System_
            slugId={slugId}
            navData={navData}
            setSlugId={setSlugId}
            data={data}
          />
        </div>
      </div>
    </section>
  );
};

export default Systems;
