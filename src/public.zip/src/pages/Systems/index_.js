import { Link } from "react-router-dom";

function System_({ slugId, navData, data, setSlugId }) {
  return (
    <section className="content-section">
      <div className="innerBanner">
        <div className="innerBanner-item">
          <div className="innerBanner-info">
            <div className="contentWrap">
              {data?.data?.banners[0]?.bannername}
              <p>{data?.data?.banners[0].bannerdescription}</p>
            </div>
          </div>
          <div className="innerBanner-bg">
            <img alt="#" src={data?.data?.banners[0].bannerimage} />
          </div>
        </div>
      </div>
      <div className="contentWrap">
        <div className="pageTemplate">
          <div className="pageTemplate-links">
            <ul>
              {navData?.data[3]?.children?.map((el, i) => (
                <li
                  onClick={() => {
                    setSlugId(el.slug);
                  }}
                  className={slugId == el.slug && "active"}
                >
                  <Link to={`/systems/${el.slug}`}>
                    {el.pagename} <b className="icon-chevron-right"></b>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div className="pageTemplate-content">
            <div className="systemTitle">
              <h3>{data?.data?.detail.title}</h3>
              <p>{data?.data?.detail?.description}</p>
            </div>

            <div className="systemLinkSection">
              <div className="systemLinkSection-wrap">
                <h3>System Links</h3>
                {data?.data?.SystemsLinks.map((el, i) => (
                  <div key={i} className="systemLinkSection-links">
                    <div className="systemTitle">{el.title}</div>
                    <img alt="#" src={el.uploadlogo} />
                  </div>
                ))}
              </div>
            </div>
            <div className="contactList">
              <h3>Business Contact</h3>
              <ul>
                {data?.data?.systemBusinessContact.map((el, i) => (
                  <div key={i} className="contactMember">
                    <div className="contactMember-img">
                      <img alt="#" src={el.profileimagepath} />
                    </div>
                    <div className="contactMember-info">
                      <h4>{el.name}</h4>
                      <p>{el.designation}</p>
                      <span>{el.department}</span>
                    </div>
                  </div>
                ))}
              </ul>
            </div>
            <div className="trainingList">
              <h3>Training Materials & Documentation</h3>
              <ul>
                {data?.data?.SystemsTrainingDocs?.map((el, i) => (
                  <li key={i}>
                    <div className="trainingItem">
                      <div className="trainingItem-img">
                        <img alt="#" src={el.uploadthumbnail} />
                      </div>
                      <div className="trainingItem-info">
                        <p>
                          <span>{data?.data?.title}</span> {el.description}
                        </p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default System_;
