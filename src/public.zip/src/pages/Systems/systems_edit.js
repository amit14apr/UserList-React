import useFetch from "../../hooks/useFetch";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import { useFieldArray, useForm } from "react-hook-form";
import { initialValues } from "./systems_data";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { updateContent } from "../../utils/helper";
const Systems_edit = () => {
  
  const url = window.location.pathname
  const urlData = url.split("/");
  const slugId = urlData[urlData.length - 3]

  console.log("Slug", slugId)
  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}/systemchild/${slugId}/0`
  );

  console.log("🚀 ~ data:", data);
  const { register, handleSubmit, control } = useForm({
    defaultValues: initialValues,
    values: data?.data,
  });
  let tempData = [];

  const onImageSelect = (event, field, requestFor) => {
    const token = JSON.parse(localStorage.getItem('token'))[0].idToken;
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    const source = axios.CancelToken.source();
    axios
      .post(
        "https://dev.cockpit.jnj.com/api/pages/upload",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            'Authorization': token,
            'url':'cms'
          },
        },
        { cancelToken: source.token }
      )
      .then((res) => {
        // if (requestFor == "banner") {
        //   data?.data?.banners.forEach((element) => {
        //     if (element.bannerid == field.bannerid) {
        //       tempData.push({
        //         requestFor: requestFor,
        //         bannerid: field.bannerid,
        //         url: res.data.url,
        //       });
        //     }
        //   });
        // } 
        if (requestFor == 'banner') {
          data?.data?.banners.forEach(element => {
            if (element.bannerid == field.bannerid) {
              tempData.push({ "requestFor": requestFor, "bannerid": field.bannerid, 'url': res.data.url })
            }
          })

        } 
        else if (requestFor == "SystemsLinks") {
          data?.data?.SystemsLinks.forEach((element) => {
            if (element.title == field.title) {
              tempData.push({ "requestFor": requestFor, "title": field.title, 'url': res.data.url })
            }
          });
        } 

        else if (requestFor == "systemBusinessContact") {
          data?.data?.systemBusinessContact.forEach((element) => {
            if (element.name == field.name) {
              tempData.push({
                "requestFor": requestFor,
                "name": field.name,
                "url": res.data.url,
              });
            }
          });
        } 
        else if (requestFor == "SystemsTrainingDocs") {
          data?.data?.SystemsTrainingDocs.forEach((element) => {
            if (element.title == field.title) {
              tempData.push({
                "requestFor": requestFor,
                "title": field.title,
                "url": res.data.url,
              });
            }
          });
        } 
        else {
          tempData.push({ "requestFor": requestFor, "url": res.data.url });
        }
      })

      .catch((err) => {
        console.log("🚀 ~ onImageSelect ~ err:", err);
      });
  };


  const SubmitData = async (data,element) => {
    
    const {detail, banners:banners, SystemsLinks:systemlinks,systemBusinessContact:businessContacts,SystemsTrainingDocs:trainings, ...rest } = data;
    const newData = { ...detail, banners,systemlinks,businessContacts, trainings, ...rest}
    console.log("Elemeny",element )
    tempData.forEach((element) => {
      console.log("Elementinside",element )
      if (element.requestFor === 'banner') {
        newData.banners.forEach((item) => {
          if (item.bannerid === element.bannerid) {
            item.bannerimage = element.url;
          }
        });
      }

      else if (element.requestFor === 'SystemsLinks') {
        // console.log("item",item)
        newData.systemlinks.forEach((item) => {
          console.log("item inside",item)
          if (item.title === element.title) {
            item.uploadlogo = element.url;
          }
        });
      }

      else if (element.requestFor === 'systemBusinessContact') {
        newData.businessContacts.forEach((item) => {
          if (item.name === element.name) {
            item.profileimagepath = element.url;
          }
        });
      }
      
      else if (element.requestFor === 'systemBusinessContact') {
        newData.systemBusinessContact.forEach((item) => {
          if (item.id === element.id) {
            item.profileimagepath = element.url;
          }
        });
      }
      else if (element.requestFor === 'SystemsTrainingDocs') {
        newData.trainings.forEach((item) => {
          if (item.title === element.title) {
            item.uploadthumbnail = element.url;
            item.uploadfile = element.url;
          }
        });
      }
      else {
        newData[element.requestFor] = element.url;
      }
    })
    
    console.log('data', newData)
    updateContent('systemchild/teammate/1', newData)
    .then(response => console.log(response))
    .catch(error => console.log(error));
    // https://dev.cockpit.jnj.com/api/pages/systemchild/teammate/1
  }
  const {
    fields: f1,
    append: a1,
    remove: r1,
  } = useFieldArray({
    control,
    name: "banners",
  });

  const {
    fields: f2,
    append: a2,
    remove: r2,
  } = useFieldArray({
    control,
    name: "SystemsLinks",
  });

  const { fields: f3, append: a3, remove: r3 } = useFieldArray({
    control,
    name: 'systemBusinessContact',
  });

  const { fields: f4, append: a4, remove: r4 } = useFieldArray({
    control,
    name: 'SystemsTrainingDocs',
  });

  return (
    <section className="center-section miniNav">
      <form onSubmit={handleSubmit(SubmitData)}>
        <div className="appArea">
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">Edit {data?.data?.detail?.pagename}</h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <a href={`/digital-innovation-analytics/systems/${data?.data?.detail?.slug}`}>Pages</a>
                      </li>
                      <li className="breadcrumb-item">
                        <a href="systems.html">Systems</a>
                      </li>
                      <li className="breadcrumb-item">
                        <a href="systems.html">{data?.data?.detail.pagename}</a>
                      </li>
                      <li className="breadcrumb-item active" aria-current="page">
                        Edit
                      </li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                <Link
                to={`/digital-innovation-analytics/systems/${slugId}`}
                className="btn btn-text"
                title="Cancel"
              >
                {" "}
                Cancel
              </Link>
              {/*<button className="btn btn-outline-primary ms-3" title="Save as Draft"><b className="icon-save"></b>Save as Draft</button>*/}
                  <button type ="submit"  className="btn btn-primary ms-3" title="Publish" >
                  {" "}
                  Publish
                </button>

                </div>
              </div>
            </div>
            <div className="sectionbody">
              <div className="contentBox">
                {f1.map((field, i) => (
                  <div key={field.id}>
                    <h2 className="contentBox-title">Banner</h2>
                    <div className="pt-2 pb-2">
                      <div className="row align-items-center pb-4">
                        <div className="col">
                          <div className="form-group">
                            <label className="form-label">Banner Image</label>
                            <div>
                              <input
                                type="file"
                                className="form-control"
                                {...register(`banners.${i}.bannerimage`, {
                                  required: false,
                                })}
                                onChange={(event) =>
                                  onImageSelect(event, field, "banner")
                                }
                              />
                            </div>
                          </div>
                        </div>
                        <div className="col">
                          <div className="form-group">
                            <label className="form-label">Banner Name</label>
                            <div>
                              <input
                                type="text"
                                className="form-control"
                                {...register(`banners.${i}.bannername`)}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="col">
                          <div className="form-group">
                            <label className="form-label">Banner Text</label>
                            <div>
                              <input
                                type="text"
                                className="form-control"
                                // value="Lorem ipsum dolor sit amet consectetur. Commodo sit eget egestas ipsum bibendum sapien."
                                {...register(`banners.${i}.bannerdescription`)}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                <hr className="mb-3" />
                <div className="pt-3">
                  <div className="row align-items-center pb-4">
                    <div className="col-6">
                      <h2 className="contentBox-title p-0">{data?.data?.detail.pagename}</h2>
                    </div>
                    <div className="col-6 text-end"> </div>
                  </div>
                  <div className="pt-2 pb-2">
                    <div className="row align-items-start">
                      <div className="col-12">
                        <div className="form-group mb-3">
                          <label className="form-label">Description</label>
                          <div>
                            <textarea className="form-control">
                              {data?.data?.detail.description}
                            </textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <hr className="mb-3" />

                <div className="pt-3">
                  <div className="row align-items-center pb-4">
                    <div className="col-6">

                      <h2 className="contentBox-title p-0">System Links </h2>

                    </div>
                    <div className="col-6 text-end"> </div>
                  </div>
                 
                    <div  className="pt-2 pb-2">
                      <div className="row">
                      {f2.map((field, i) => (
                        <div key={field.id} className="col-6">
                          <div className="p-3 innerBox mb-3">
                            <div className="row align-items-start">
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">Title</label>
                                  <div>

                                    <input
                                      type="text"
                                      className="form-control"
                                      {...register(`SystemsLinks.${i}.title`)}
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">Upload Logo </label>
                                  <div>
                                    <input
                                      type="file"
                                      className="form-control"
                                      {...register(`SystemsLinks.${i}.uploadlogo`)}
                                      onChange={(event) =>
                                        onImageSelect(event, field, "SystemsLinks")
                                      }
                                      
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">Description </label>
                                  <div>
                                    {/* <input
                                      type="text"
                                      className="form-control"
                                      value="Consectetur amet dolor sit comeneer ilremsilom dolce issilm acalrm"
                                    /> */}
                                    <input
                                      type="text"
                                      className="form-control"
                                      {...register(`SystemsLinks.${i}.description`)}
                                    />

                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">URL </label>
                                  <div>
                                    <input
                                      type="text"
                                      className="form-control"
                                      {...register(`SystemsLinks[${i}].url`)}
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12 text-end">
                                <button onClick={() => r2(i)} className="btn btn-text ms-3">
                                  <b className="icon-trash-2"></b> Delete
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                      </div>
                    </div>
                
                </div>

                <hr className="mb-3" />
                <div className="pt-3">
                  <div className="row align-items-center pb-4">
                    <div className="col-6">
                      <h2 className="contentBox-title p-0">Business Contact </h2>
                    </div>

                    <div className="col-6 text-end">
                      <a
                        title="Add New Member"
                        className="btn btn-outline-primary"
                        data-bs-toggle="modal"
                        data-bs-target="#addMemberModal"
                        onClick={() => a3({ name: '', designation: '', department: '', profileimagepath: '', groupname: '' })}
                      >
                        {" "}
                        Add New Member
                      </a>
                    </div>

                  </div>
                  {f3.map((field, i) => (
                    <div key={field.id} className="pt-2 pb-2">
                      <div className="p-3 innerBox mb-3">
                        <div className="row align-items-start">
                          <div className="col-4">
                            <div className="form-group mb-3">
                              <label className="form-label">Name</label>
                              <div>
                                {/* <input
                                type="text"
                                className="form-control"
                                value="Mastalski, Trish [DPYUS]"
                              /> */}
                                <input
                                  type="text"
                                  className="form-control"
                                  {...register(`systemBusinessContact.${i}.name`)}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-4">
                            <div className="form-group mb-3">
                              <label className="form-label">Designation</label>
                              <div>
                                {/* <input
                                type="text"
                                className="form-control"
                                value="LEAD ANALYST GLOBAL "
                              /> */}
                                <input
                                  type="text"
                                  className="form-control"
                                  {...register(`systemBusinessContact.${i}.designation`)}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-4">
                            <div className="form-group mb-3">
                              <label className="form-label">Department</label>
                              <div>
                                <input
                                  type="text"
                                  className="form-control"
                                  {...register(`systemBusinessContact.${i}.department`)}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-4">
                            <div className="form-group mb-3">
                              <label className="form-label">Profile Image</label>
                              <div>
                                {/* <input type="file" className="form-control" /> */}
                                <input
                                  type="file"
                                  className="form-control"
                                  {...register(`systemBusinessContact.${i}.profileimagepath`)}
                                  onChange={(event) =>
                                    onImageSelect(event, field, "systemBusinessContact")
                                  }
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-4">
                            <div className="form-group mb-3">
                              <label className="form-label">Group Name</label>
                              <div>
                                <input
                                  type="text"
                                  className="form-control"
                                  {...register(`systemBusinessContact.${i}.groupname`)}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-12 text-end">
                            <button onClick={() => r3(i)} className="btn btn-text ms-3">
                              <b className="icon-trash-2"></b> Delete
                            </button>
                          </div>
                        </div>
                      </div>

                    </div>
                  ))}
                </div>


                <hr className="mb-3" />
                <div className="pt-3">
                  <div className="row align-items-center pb-4">
                    <div className="col-6">
                      <h2 className="contentBox-title p-0">
                        Training Materials & Documentation
                      </h2>
                    </div>
                    <div className="col-6 text-end">
                      <a
                        title="Add New Member"
                        className="btn btn-outline-primary"
                        data-bs-toggle="modal"
                        data-bs-target="#addTrainingModal"
                        onClick={() => a4({
                          title: '',
                          link: '',
                          uploadthumbnail: '',
                          uploadfile: null,
                          description: '',
                          updatedatetime: null,
                          savedraft: false,
                          pageid: 5,
                          createdAt: new Date().toISOString(),
                          updatedAt: new Date().toISOString(),
                        })}
                      >
                        {" "}
                        Add More
                      </a>
                    </div>
                  </div>

                  <div className="pt-2 pb-2">

                    <div className="row">
                      {f4.map((field, i) => (
                        <div key={field.id} className="col-4">
                          <div className="p-3 innerBox mb-3">
                            <div className="row align-items-start">
                            <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">
                                 Title
                                  </label>
                                  <div>
                                    {/* <input type="file" className="form-control" /> */}

                                    <input
                                      type="text"
                                      className="form-control"
                                      {...register(`SystemsTrainingDocs.${i}.title`)}
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">
                                    Upload Thumbnail
                                  </label>
                                  <div>
                                    {/* <input type="file" className="form-control" /> */}

                                    <input
                                      type="file"
                                      className="form-control"
                                      {...register(`SystemsTrainingDocs.${i}.uploadthumbnail`)}
                                      onChange={(event) =>
                                        onImageSelect(event, field, "SystemsTrainingDocs")
                                      }
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">Upload File</label>
                                  <div>
                                    <input
                                      type="file"
                                      className="form-control"
                                      {...register(`SystemsTrainingDocs.${i}.uploadfile`)}
                                      onChange={(event) =>
                                        onImageSelect(event, field, "SystemsTrainingDocs")
                                      }
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">Description</label>
                                  <div>
                                    <textarea
                                      type="text"
                                      className="form-control"
                                      {...register(`SystemsTrainingDocs.${i}.description`)}
                                    />
                                    {/* <textarea className="form-control">
                                    TeamMate + is a Windows-based Audit Management
                                    System. designed to bring efficiency and
                                    consistency to the entire audit/evaluation
                                    process Of Globa
                                  </textarea> */}
                                  </div>
                                </div>
                              </div>
                              <div className="col-12 text-end">
                                <button onClick={() => r4(i)} className="btn btn-text ms-3">
                                  <b className="icon-trash-2"></b> Delete
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                  </div>

                </div>

              </div>
            </div>
          </div>
        </div>
      </form>
    </section>
  );
};

export default Systems_edit;
