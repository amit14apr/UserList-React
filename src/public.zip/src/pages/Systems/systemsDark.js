import { Link } from "react-router-dom";
import $ from "jquery";
import "jquery-ui-dist/jquery-ui";

const SystemsDark = () => {
  $(document).on("click", ".tagBox", function () {
    var $dataID = $(this).attr("data-id");
    $(".tagBox").removeClass("active");
    $(this).toggleClass("active");
    console.log($dataID);

    if ($dataID == "All") {
      $(".dashboardArea-content ul li").show();
    } else {
      console.log("data-type=" + $dataID);
      $(".dashboardArea-content ul li").hide();
      $(".dashboardArea-content ul li[data-type=" + $dataID + "]").show();
    }
  });
  return (
    <main className="darkMode">
      <section className="center-section miniNav">
        <div className="appNav">
          <a className="menuToggle">
            <b className="icon-menu"></b>
          </a>
          <ul>
            <li>
              <a title="GA&A Portals" href="index.html">
                <i className="icon-folder"></i>
                <span>GA&A Portals</span>
              </a>
            </li>
          </ul>
        </div>
        <div className="appArea">
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">
                    Teammate +{" "}
                    <span className="text-uppercase badge badge-success">
                      Active{" "}
                    </span>
                  </h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <a href="pages.html">Pages</a>
                      </li>
                      <li className="breadcrumb-item">
                        <a href="systems.html">System</a>
                      </li>
                      <li
                        className="breadcrumb-item active"
                        aria-current="page"
                      >
                        Teammate +
                      </li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                  <Link to="/digital-innovation-analytics" className="btn btn-text" title="Cancel">
                    {" "}
                    Cancel
                  </Link>

                  <Link
                    to="/systems_edit"
                    className="btn btn-primary ms-3"
                    title="Edit"
                  >
                    <b className="icon-edit-3"></b> Edit Page
                  </Link>
                </div>
              </div>
            </div>
            <div className="sectionbody">
              <div className="editContent">
                <div className="innerBanner">
                  <div className="innerBanner-item">
                    <div className="innerBanner-info">
                      <div className="contentWrap">
                        <h2>System</h2>
                        <p>
                          Lorem ipsum dolor sit amet consectetur. Commodo sit
                          eget egestas ipsum bibendum sapien.
                        </p>
                      </div>
                    </div>
                    <div className="innerBanner-bg">
                      <img
                        alt="#"
                        src={require("../../assets/img/page_banners/system.png")}
                      />
                    </div>
                  </div>
                </div>

                <div className="contentWrap">
                  <div className="pageTemplate">
                    <div className="pageTemplate-links">
                      <ul>
                        <li className="active">
                          <a href="#">
                            Teammate + <b className="icon-chevron-right"></b>
                          </a>
                        </li>
                        <li>
                          <a href="#">MBOX/SDX (Managed File Transfer)</a>
                        </li>
                        <li>
                          <a>i-sight</a>
                        </li>
                        <li>
                          <a>Tempus</a>
                        </li>
                      </ul>
                    </div>
                    <div className="pageTemplate-content">
                      <div className="systemTitle">
                        <h3>Teammate +</h3>
                        <p>
                          TeamMate + is a Windows-based Audit Management System.
                          designed to bring efficiency and consistency to the
                          entire audit/evaluation process Of Global Audit &
                          Assurance (GAA). At its core, TeamMate + is an
                          electronic project management system that facilitates
                          the audit process from risk assessment to reporting.
                        </p>
                      </div>

                      {/* <!--<div className="systemLinks">
                    <div className="systemLinks-wrap">
                      <div className="systemLinks-title">
                        <h3>System Links</h3>
                      </div>
                      <div className="systemLinks-list">
                        <div className="linkGroup">
                          <div className="linkGroup-img"><img alt="#" src="assets/img/external_links/link_01.png">
                          </div>
                          <div className="linkGroup-info">
                            <h4>TeamMate + SharePoint Site</h4>
                            <p>Consectetur amet dolor sit comeneer ilremsilom dolce issilm acalrm </p>
                            <a>Click Here</a>
                          </div>
                        </div>
                        <div className="linkGroup">
                          <div className="linkGroup-info">
                            <h4>TeamMate + System Pages</h4>
                            <p>Consectetur amet dolor sit comeneer ilremsilom dolce issilm acalrm </p>
                            <a>Click Here</a>
                          </div>
                          <div className="linkGroup-img"><img alt="#" src="assets/img/external_links/link_02.png">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>--> */}

                      <div className="systemLinkSection">
                        <div className="systemLinkSection-wrap">
                          <h3>System Links</h3>
                          <div className="systemLinkSection-links">
                            {/* <!--<div className="systemLinkGroup-list">
                          <div className="systemLinkGroup">
                            <img alt="#" src="assets/img/link_left.png">
                            <h4>TeamMate + SharePoint Site</h4>
                            <p>Consectetur amet dolor sit comeneer ilremsilom dolce issilm acalrm </p>
                            <a>Click Here <b className="icon-arrow-right-circle"></b></a>
                          </div>
        
                          <div className="systemLinkGroup">
                            <img alt="#" src="assets/img/link_right.png">
                            <h4>TeamMate</h4>
                            <p>Consectetur amet dolor sit comeneer ilremsilom dolce issilm acalrm </p>
                            <a>Click Here <b className="icon-arrow-right-circle"></b></a>
                          </div>
                        </div>--> */}

                            <img
                              alt="#"
                              src={require("../../assets/img/links.png")}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="contactList">
                        <h3>Business Contact</h3>
                        <ul>
                          <li>
                            <div className="contactMember">
                              <div className="contactMember-img">
                                <img
                                  alt="#"
                                  src={require("../../assets/img/members/person_02.jpg")}
                                />
                              </div>
                              <div className="contactMember-info">
                                <h4>Mastalski, Trish [DPYUS]</h4>
                                <p>LEAD ANALYST GLOBAL </p>
                                <span>TeamMate + Admin</span>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div className="contactMember">
                              <div className="contactMember-img">
                                <img
                                  alt="#"
                                  src={require("../../assets/img/members/person_05.jpg")}
                                />
                              </div>
                              <div className="contactMember-info">
                                <h4>Mastalski, Trish [DPYUS]</h4>
                                <p>LEAD ANALYST GLOBAL </p>
                                <span>TeamMate + Admin</span>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div className="contactMember">
                              <div className="contactMember-img">
                                <img
                                  alt="#"
                                  src={require("../../assets/img/members/person_06.png")}
                                />
                              </div>
                              <div className="contactMember-info">
                                <h4>Mastalski, Trish [DPYUS]</h4>
                                <p>LEAD ANALYST GLOBAL </p>
                                <span>TeamMate + Admin</span>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div className="contactMember">
                              <div className="contactMember-img">
                                <img
                                  alt="#"
                                  src={require("../../assets/img/members/person_07.png")}
                                />
                              </div>
                              <div className="contactMember-info">
                                <h4>Mastalski, Trish [DPYUS]</h4>
                                <p>LEAD ANALYST GLOBAL </p>
                                <span>TeamMate + Admin</span>
                              </div>
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="requestAccess">
                        <div className="requestAccess-left">
                          <h3>How To Request Access</h3>
                          <p>
                            <span>
                              To request access to TeamMate+ use the form!
                            </span>
                          </p>
                          <p>
                            TeamMate+ user Access form needs your permission to
                            use the following, Please allow the permissions to
                            proceed,
                          </p>
                          <a>
                            Click here{" "}
                            <b className="icon-arrow-right-circle"></b>
                          </a>
                        </div>
                        <div className="requestAccess-right">
                          <img
                            alt="#"
                            src={require("../../assets/img/place_holder.png")}
                          />
                        </div>
                      </div>

                      <div className="trainingList">
                        <h3>Training Materials & Documentation</h3>
                        <ul>
                          <li>
                            <div className="trainingItem">
                              <div className="trainingItem-img">
                                <img
                                  alt="#"
                                  src={require("../../assets/img/training_items/placeholder_01.png")}
                                />
                              </div>
                              <div className="trainingItem-info">
                                <p>
                                  <span>TeamMate +</span> is a Windows-based
                                  Audit Management System. designed to bring
                                  efficiency and consistency to the entire
                                  audit/evaluation process Of Globa
                                </p>
                              </div>
                            </div>
                          </li>

                          <li>
                            <div className="trainingItem">
                              <div className="trainingItem-img">
                                <img
                                  alt="#"
                                  src={require("../../assets/img/training_items/placeholder_02.png")}
                                />
                              </div>
                              <div className="trainingItem-info">
                                <p>
                                  <span>TeamMate +</span> is a Windows-based
                                  Audit Management System. designed to bring
                                  efficiency and consistency to the entire
                                  audit/evaluation process Of Globa
                                </p>
                              </div>
                            </div>
                          </li>

                          <li>
                            <div className="trainingItem">
                              <div className="trainingItem-img">
                                <img
                                  alt="#"
                                  src={require("../../assets/img/training_items/placeholder_03.png")}
                                />
                              </div>
                              <div className="trainingItem-info">
                                <p>
                                  <span>TeamMate +</span> is a Windows-based
                                  Audit Management System. designed to bring
                                  efficiency and consistency to the entire
                                  audit/evaluation process Of Globa
                                </p>
                              </div>
                            </div>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default SystemsDark;
