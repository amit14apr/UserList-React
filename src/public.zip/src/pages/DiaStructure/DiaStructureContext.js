import React, { createContext, useState } from "react";

export const DiaStructureContext = createContext();

export const DiaStructureProvider = ({ children }) => {
  const [responseData, setResponseData] = useState(null);
  return (
    <DiaStructureContext.Provider value={{ responseData, setResponseData }}>
      {children}
    </DiaStructureContext.Provider>
  );
};
