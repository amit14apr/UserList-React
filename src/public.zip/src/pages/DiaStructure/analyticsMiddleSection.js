import React, { useContext } from "react";

const AnalyticsMiddleSection = ({ data }) => {
  return (
    <div className="middleSection">
      <div className="contentWrap">
        <div className="row">
          <div className="col-5"></div>
          <div className="col-7">
            <div className="middleContent">
              <h3>{data?.title}</h3>
              <div className="linear-line"></div>
              <p>
                {data?.description}
              </p>
              <p>
                Build a hybrid team that is skilled in leading finance
                technologies and is enabled to dynamically solve problems and
                better target specific risks.
              </p>
              <div className="row">
                <div className="col-3">
                  <div className="blockContent">
                    <p>The Tech</p>
                    <img
                      className="m-auto"
                      src={require("../../assets/img/structure_images/tech_icons.png")}
                      alt="Tech Icons"
                    />
                  </div>
                </div>
                <div className="col-5">
                  <div className="blockContent">
                    <p>The People</p>
                    <img
                      width="215"
                      src={require("../../assets/img/structure_images/people_icons.png")}
                      alt="People Icons"
                    />
                  </div>
                </div>
                <div className="col-4">
                  <div className="blockContent border-none">
                    <p>The Results</p>
                    <ul className="ml-1">
                      <li>
                        Audit analytics - facilitating auditors by solutions
                        that identifying concerns, eliminating manual work, and
                        automated complete population review.
                      </li>
                      <li>
                        Risk coverage analytics – streamlined process providing
                        a greater scope with faster identification of new risks.
                      </li>
                      <li>
                        Time savings – the use of analytics increases efficiency
                        allowing individuals to focus on value added activities.
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default AnalyticsMiddleSection;
