import React, { useContext } from "react";
import { Link } from "react-router-dom";

const DiaTemplate = ({detail}) => {
  console.log('data !!', detail)
  return (
    <div className="diaTemplate">
      <div className="diaTemplate-content">
        <div className="row systemTitle">
        <div className="col-8">
          <div className="contentWrap">
            <h3>Digital Analytics & Automation Team Methodology</h3>
            <p>{detail?.organizationalcharttitle}</p>
          </div>
          </div>
          <div className="col-4 text-end">  
                <Link to="/digital-innovation-analytics" className="btn btn-text" title="Cancel">
                  {" "}
                  Cancel
                </Link>

                <Link
                  to={`/digital-innovation-analytics/dia-structure/edit/`}
                  className="btn btn-primary ms-3"
                  title="Edit"
                >
                  <b className="icon-edit-3"></b> Edit Page
                </Link>
              </div>
        </div>
        <div className="contentWrap">
          <img
            src={detail?.organizationalchartimage}
            alt="Org Chart"
          />
        </div>
      </div>
    </div>
  );
};

export default DiaTemplate;
