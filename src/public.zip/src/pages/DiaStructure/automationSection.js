import React, { useContext } from "react";

const AutomationSection = ({ data }) => {
  return (
    <div className="middleSection autoSection">
      <div className="contentWrap">
        <div className="row">
          <div className="col-7">
            <div className="middleContent">
              <h3>{data?.title}</h3>
              <div className="linear-line"></div>
              <p>
                {data?.description}
              </p>
              {/* <p>
                Efficiencies in the audit process will allow resources more time
                and focus to deliver on strategic initiatives.
              </p> */}
              <div className="row">
                <div className="col-4">
                  <div className="blockContent">
                    <p>The Tech</p>
                    <img
                      className="m-auto"
                      src="../../assets/img/structure_images/tech_icons.png"
                      alt="Tech Icons"
                    />
                  </div>
                </div>
                <div className="col-4">
                  <div className="blockContent">
                    <p>The BOTs</p>
                    <img
                      className="m-auto"
                      src="../../assets/img/structure_images/robot_icon.png"
                      alt="Robot"
                    />
                  </div>
                </div>
                <div className="col-4">
                  <div className="blockContent border-none">
                    <p>The Results</p>
                    <ul className="ml-2">
                      <li>
                        Developed RPA to support audit testing and documentation
                      </li>
                      <li>Enhanced employee experience</li>
                      <li>Saved thousands of hours</li>
                      <li>
                        Developed end to end process to support receipt policy
                        review.
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-5"></div>
        </div>
      </div>
    </div>
  );
};

export default AutomationSection;
