export const dataValues = {

        "detail": {
            "pageid": 2,
            "pagename": "DI&A Structure",
            "title": "Digital Analytics & Automation Team Methodology",
            "description": "",
            "notes": null,
            "supportcentraltitle": null,
            "businesscontacttitle": null,
            "businesscontactdescription": null,
            "powerappsembededlink": null,
            "organizationalchartimage": "",
            "organizationalcharttitle": "Digital Innovation & Analytics Organizational Chart",
            "slug": "dia-structure",
            "thumnail": "Dia-thumbnail",
            "parentpageid": 0,
            "type": "template",
            "ordernumber": 1,
            "updateddatetime": "2024-02-29T10:53:16.371Z",
            "updatedby": "SaravanaPrasath",
            "status": true,
            "savedraft": false,
            "homeleftimage": "HomePage-left-image.jpg",
            "homerightimage": "HomePage-right-image.jpg",
            "recomendationtitle": "HomePage-Recommendation Title",
            "recomendationsubtitle": "HomePage-Recommendation Subtitle",
            "createdAt": "2024-03-26T15:33:10.231Z",
            "updatedAt": "2024-03-26T15:33:10.231Z"
        },
        "banners": [
            {
                "bannerid": 7,
                "bannername": "DI&A Structure",
                "bannerimage": "https://dch-global-audit-and-assurance-dev.s3.amazonaws.com/images/page_banners/di_a_structure.png?AWSAccessKeyId=AKIAWS4MG4CJY7JHGL63&Expires=1711649063&Signature=5G6qtxT14qKMJ69SEiikLQl5FWw%3D",
                "bannerlink": "banner.com",
                "bannerdescription": "DI&A is comprised of a group of skilled individuals focused on providing data-driven advanced analytics, robotic process automation, and artificial intelligence.",
                "status": null,
                "updateddate": "2024-03-05T13:36:45.000Z",
                "pageid": 2,
                "updatedby": "22222",
                "createdAt": "2024-03-26T15:33:10.468Z",
                "updatedAt": "2024-04-05T13:05:05.951Z"
            }
        ],
        "sections": [
            {
                "id": 3,
                "title": "Audit Risk Assessment",
                "description": "Leverage enterprise data, conduct risk assessments and extract deeper and more valuable insights for more efficient and effective audit planning and continuous monitoring,",
                "uploadlogo": "hey2.logo",
                "content": "",
                "updateddatetime": "2024-03-05T13:36:45.000Z",
                "savedraft": null,
                "pageid": 2,
                "createdAt": "2024-03-26T15:33:10.716Z",
                "updatedAt": "2024-04-05T13:05:06.176Z",
                "subSections": [
                    {
                        "id": 7,
                        "title": "The Tech",
                        "description": "Continuous and integrated audit risk assessment process that enhanced risk coverage",
                        "uploadlogo": "",
                        "updateddatetime": "2024-03-05T13:36:45.000Z",
                        "savedraft": null,
                        "sectionid": 3,
                        "createdAt": "2024-03-26T15:33:10.741Z",
                        "updatedAt": "2024-04-05T13:05:06.200Z"
                    },
                    {
                        "id": 8,
                        "title": "The Awards",
                        "description": "Analyze Key enterprise data sources within Alteryx risk data engine",
                        "uploadlogo": "",
                        "updateddatetime": "2024-03-05T13:36:45.000Z",
                        "savedraft": null,
                        "sectionid": 3,
                        "createdAt": "2024-03-26T15:33:10.767Z",
                        "updatedAt": "2024-04-05T13:05:06.224Z"
                    },
                    {
                        "id": 9,
                        "title": "The Results",
                        "description": "Continuous and integrated audit risk assessment process that enhanced risk coverage",
                        "uploadlogo": "",
                        "updateddatetime": "2024-03-05T13:36:45.000Z",
                        "savedraft": null,
                        "sectionid": 3,
                        "createdAt": "2024-03-26T15:33:10.793Z",
                        "updatedAt": "2024-04-05T13:05:06.249Z"
                    }
                ]
            },
            {
                "id": 1,
                "title": "Analytics",
                "description": "Deploy agile and scalable analytical solutions that provide data-driven insights and identify real-time risks.Build a hybrid team that is skilled in leading ",
                "uploadlogo": "hey.logo",
                "content": "",
                "updateddatetime": "2024-03-05T13:36:45.000Z",
                "savedraft": null,
                "pageid": 2,
                "createdAt": "2024-03-26T15:33:10.499Z",
                "updatedAt": "2024-04-05T13:05:05.975Z",
                "subSections": [
                    {
                        "id": 1,
                        "title": "The Tech",
                        "description": "",
                        "uploadlogo": "",
                        "updateddatetime": "2024-03-05T13:36:45.000Z",
                        "savedraft": null,
                        "sectionid": 1,
                        "createdAt": "2024-03-26T15:33:10.527Z",
                        "updatedAt": "2024-04-05T13:05:05.999Z"
                    },
                    {
                        "id": 2,
                        "title": "The People",
                        "description": "",
                        "uploadlogo": "",
                        "updateddatetime": "2024-03-05T13:36:45.000Z",
                        "savedraft": null,
                        "sectionid": 1,
                        "createdAt": "2024-03-26T15:33:10.553Z",
                        "updatedAt": "2024-04-05T13:05:06.024Z"
                    },
                    {
                        "id": 3,
                        "title": "The Results",
                        "description": "ò Audit analytics - facilitating auditors by solutions that identifying concerns, eliminating manual work, and automated complete population review÷ ò ",
                        "uploadlogo": "",
                        "updateddatetime": "2024-03-05T13:36:45.000Z",
                        "savedraft": null,
                        "sectionid": 1,
                        "createdAt": "2024-03-26T15:33:10.579Z",
                        "updatedAt": "2024-04-05T13:05:06.047Z"
                    }
                ]
            },
            {
                "id": 2,
                "title": "Automation",
                "description": "Develop and implement RPA and automation solutions that target efficiencies, audit effectiveness, and better employee experience.Efficiencies in the audit process ",
                "uploadlogo": "hey2.logo",
                "content": "",
                "updateddatetime": "2024-03-05T13:36:45.000Z",
                "savedraft": null,
                "pageid": 2,
                "createdAt": "2024-03-26T15:33:10.608Z",
                "updatedAt": "2024-04-05T13:05:06.071Z",
                "subSections": [
                    {
                        "id": 5,
                        "title": "The BOTs",
                        "description": "",
                        "uploadlogo": "",
                        "updateddatetime": "2024-03-05T13:36:45.000Z",
                        "savedraft": null,
                        "sectionid": 2,
                        "createdAt": "2024-03-26T15:33:10.660Z",
                        "updatedAt": "2024-04-05T13:05:06.129Z"
                    },
                    {
                        "id": 6,
                        "title": "The Results",
                        "description": " Developed RPA to support audit testing and documentatioM W Enhanced employee experiencK W Saved thousands of hourR W Developed end to end process to support receipt policy review.",
                        "uploadlogo": "",
                        "updateddatetime": "2024-03-05T13:36:45.000Z",
                        "savedraft": null,
                        "sectionid": 2,
                        "createdAt": "2024-03-26T15:33:10.685Z",
                        "updatedAt": "2024-04-05T13:05:06.152Z"
                    },
                    {
                        "id": 4,
                        "title": "The Tech",
                        "description": "",
                        "uploadlogo": "",
                        "updateddatetime": "2024-03-05T13:36:45.000Z",
                        "savedraft": null,
                        "sectionid": 2,
                        "createdAt": "2024-03-26T15:33:10.634Z",
                        "updatedAt": "2024-04-05T13:05:06.098Z"
                    }
                ]
            }
        ],
    "message": "DIA Structure was fetched successfully!"
};