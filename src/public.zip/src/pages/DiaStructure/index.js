import React from "react";
import { Link } from "react-router-dom";
import DiaTemplate from "./diaTemplate";
import AnalyticsMiddleSection from "./analyticsMiddleSection";
// import BackgroundAnimation from "../../components/ui/Animations/BackgroundAnimation";
import AutomationSection from "./automationSection";
import AuditSection from "./auditSection";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import  useFetch from "../../hooks/useFetch";


const DiaStructure = () => {
  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}/dia/2`
  );
  console.log("data>>>",data)
  return (
    <>
     <section className="center-section miniNav">
      <div className="appArea">
        <div className="contentWrap">
          <div className="sectionHead">
            <div className="row align-items-center">
              <div className="col-6">
                <h1 className="pageTitle">
                 {data?.data?.detail?.title}{" "}
                 {data?.data?.detail?.status== true ?
                  <span className="text-uppercase badge badge-success">
                  Active{" "}
                  </span> 
                  :
                  <span className="text-uppercase badge badge-failure">
                  Incative {" "}
                  </span>  }
                </h1>
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                      <a href="/digital-innovation-analytics">Pages</a>
                    </li>
                    <li className="breadcrumb-item active" aria-current="page">
                    {/* {data?.data?.banners} */}
                    </li>
                  </ol>
                </nav>
              </div>
              <div className="col-6 text-end">
                <a className="btn btn-text" title="Cancel" href="/digital-innovation-analytics">
                  {" "}
                  Cancel
                </a>

                <Link
                  to="/digital-innovation-analytics/dia-structure/edit"
                  className="btn btn-primary ms-3"
                >
                  <b className="icon-edit-3"></b> Edit Page
                </Link>
              </div>
            </div>
          </div>
          <div className="sectionbody">
            <div className="editContent">
              <div className="innerBanner">
                <div className="innerBanner-item">
                  <div className="innerBanner-info">
                    <div className="contentWrap">
                 <h2>{data?.data?.banners[0]?.bannername}</h2> 
                      <p>
                    {data?.data?.banners[0]?.bannerdescription}
                      </p>
                    </div>
                  </div>
                  <div className="innerBanner-bg">
                    <img
                      alt="#"
                      src={data?.data?.banners[0]?.bannerimage}
                    />
                  </div>
                </div>
              </div>
          {/* <Slide delay={0.3}> */}
            {/* <> */}
              <DiaTemplate detail={data?.data?.detail}/>
            {/* </> */}
          {/* </Slide> */}
          {/* <Slide delay={0.5}> */}
            {/* <> */}
              <AnalyticsMiddleSection data={data?.data?.sections[0]}/>
            {/* </>
          </Slide> */}
          {/* <Slide delay={0.5}>
            <> */}
              <AutomationSection data={data?.data?.sections[1]}/>
            {/* </> */}
          {/* // </Slide> */}
          {/* <Slide delay={0.5}>
            <> */}
              <AuditSection data={data?.data?.sections[2]}/>
            {/* </>
          </Slide> */}
         </div>
          </div>
        </div>
      </div>
    </section>
    </>
        
    // </DiaStructureProvider>
  );
};

export default DiaStructure;
