import React, { useEffect } from "react";
import {useFieldArray, useForm, Controller } from 'react-hook-form';
import useFetch from "../../hooks/useFetch";
import { COCKPIT_BASE_URL } from "../../utils/helper";
import { updateContent } from "../../utils/helper";
import { initialValues } from './initialValues';
import axios from 'axios';
const Dia_structure_edit = () => {
  let tempData=[]
  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}/dia/dia-structure/0`
  );

  const { register, handleSubmit, control } = useForm({
    defaultValues:data,
    values:data?.data
  });

  
  const SubmitData = async (data) => {
    console.log("Data:", data);
    
    const { detail, banners:banners, sections:sections, ...rest } = data;
    const newData = { ...detail, banners, sections, ...rest };
    newData.sections = newData.sections.map(section => {
      // Rename the subsection property to your desired name
      const { subSections, ...restOfSection } = section;
      // Define your desired new name for subsection
      const newSubsectionName = 'subSection';
      return {
          ...restOfSection,
          // Add the renamed subsection property to the section
          [newSubsectionName]: subSections,
      };
  });
    tempData.forEach((element) => {
      if (element.requestFor === 'banner') {
        newData.banners.forEach((item) => {
          if (item.bannerid === element.bannerid) {
            item.bannerimage = element.url;
          }
        });
      }
      
      else if (element.requestFor === 'subsection') {
        newData.sections.forEach((section, i) => {
          console.log("Current Section:", section);
          if (i === element.i) {
            section.subSections.forEach((item, subSectionIndex) => {
              console.log("Current SubSection Item:", item); 
              if (subSectionIndex === element.subSectionIndex) {
                item.uploadlogo = element.url;
              }
            });
          }
        });
      } 
      
      else {
        newData[element.requestFor] = element.url;
      }
    });
  
    console.log("New Data:", newData);
    updateContent('dia/dia-structure/0', newData)
      .then(response => console.log(response))
      .catch(error => console.log(error));
    
  };
  
 
  useEffect(() => {
    console.log("Data:", data);
    console.log("Error:", error);
  }, [data, error]);

  const { fields: f1, append: a1, remove: r1 } = useFieldArray({
    control,
    name: "banners"
  });
  const { fields: f3, append: a3, remove: r3 } = useFieldArray({
    control,
    name: "sections"
  });

  const onImageSelect = (event, field, requestFor) => {
    const token = JSON.parse(localStorage.getItem('token'))[0].idToken;
    
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append("filepath", "images/banners/");
    const source = axios.CancelToken.source();
    axios.post("https://dev.cockpit.jnj.com/api/pages/upload", formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        'Authorization': token,
        'url':'cms'
      }
    }, { cancelToken: source.token })
      .then(res => {
        // console.log(data?.data?.banners);
        console.log("🚀 ~ onImageSelect ~ res:", res.data.url);
        if (requestFor == 'banner') {
          data?.data?.banners.forEach(element => {
            if (element.bannerid == field.bannerid) {
              tempData.push({ "requestFor": requestFor, "bannerid": field.bannerid, 'url': res.data.url })
            }
          })

        } 
      
      else if (requestFor === 'subsection') {
        // Logic for updating subsections using tempData.push
        data?.data?.sections.forEach((section, i) => {
          section.subSections.forEach((element, subSectionIndex) => {
            if (element.id === field.id) { // Replace `desiredSubSectionId` with the ID you want to check
              tempData.push({ "requestFor": requestFor, "i": i, "subSectionIndex": subSectionIndex, 'url': res.data.url });
            }
          });
        });
      }
        else {
          tempData.push({ requestFor: requestFor, 'url': res.data.url })
        }
      })

      .catch(err => {
        console.log("🚀 ~ onImageSelect ~ err:", err)
      })
  }


  return (

    <section className="center-section miniNav">
      <form onSubmit={handleSubmit(SubmitData)}>
        <div className="appArea">
          {data && data.data && data.data.detail ? (
            <div className="contentWrap">
              <div className="sectionHead">
                <div className="row align-items-center">

                  <div className="col-6">

                    <h1 className="pageTitle">Edit DI&A Structure</h1>
                    <nav aria-label="breadcrumb">
                      <ol className="breadcrumb">
                        <li className="breadcrumb-item">
                          <a href="pages.html">Pages</a>
                        </li>
                        <li className="breadcrumb-item">

                          <a href="di_a_structure.html">DI&A Structure</a>
                        </li>
                        <li className="breadcrumb-item active" aria-current="page">
                          Edit
                        </li>
                      </ol>
                    </nav>

                  </div>

                  <div className="col-6 text-end">
                <a
                  className="btn btn-text"
                  title="Cancel"
                  href="available_data_sources.html"
                >
                  {" "}
                  Cancel
                </a>
                {/*<button className="btn btn-outline-primary ms-3" title="Save as Draft"><b className="icon-save"></b>Save as Draft</button>*/}
                <button type ="submit"  className="btn btn-primary ms-3" title="Publish" >
                  {" "}
                  Publish
                </button>
              </div>
                </div>
              </div>

            
              <div className="sectionbody">
                <div className="contentBox">

                  
                {f1.map((field, i) => <div key={field.id}>
                    <h2 className="contentBox-title">Banner</h2>
                    <div className="pt-2 pb-2">
                    
                        <div  className="row align-items-center pb-4">
                          <div className="col">
                            <div className="form-group">
                              <label className="form-label">Banner Name</label>
                              <input
                            type="text"
                            className="form-control"
                            // value="Available Data Sources"
                            {...register(`banners.${i}.bannername`)}
                          />
                            </div>
                          </div>
                          <div className="col">
                            <div className="form-group">
                              <label className="form-label">Banner Text</label>
                            
                              <input
                            type="text"
                            className="form-control"
                            // value="Available Data Sources"
                            {...register(`banners.${i}.bannertext`)}
                          />
                            </div>
                          </div>
                          <div className="col">
                            <div className="form-group">
                              <label className="form-label">Banner Image</label>
                              <div>
                              
                              <input type="file" className="form-control" 
                          {...register(`banners.${i}.bannerimage`)}
                          onChange={event => onImageSelect(event, field, 'banner')}/>


                              </div>
                            </div>
                          </div>
                        </div>
                    
                    </div>

                 </div>)} 

                  <hr className="mb-3" />

                  <div>
                    <h2 className="contentBox-title">Title</h2>
                  
                    <div className="pt-2 pb-2">
                      <div className="row align-items-center pb-4">
                        <div className="col">
                          <input
                            {...register('detail.title')}
                            className="form-control"
                            type="text"
                            placeholder="Title"
                            defaultValue={data?.data?.detail?.title || ''}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <hr className="mb-3" />

                  <div>
                    <h2 className="contentBox-title">Organizational Chart</h2>
                    <div className="pt-2 pb-2">
                      <div className="row align-items-center pb-4">
                        <div className="col">
                          <label className="form-label">Title</label>
                          <div>
                            <input
                              {...register('detail.organizationalcharttitle')}
                              className="form-control"
                              type="text"
                              placeholder="Organizational Chart Title"
                              defaultValue={data?.data?.detail?.organizationalcharttitle || ''}
                            />
                          </div>
                        </div>
                        <div className="col">
                          <div className="form-group">
                            <label className="form-label">Left Side Banner</label>
                            <div>
                              <input
                                {...register('organizationalchartimage')}
                                onChange={event => onImageSelect(event, {}, 'organizationalchartimage')} 
                                className="form-control"
                                type="file"
                                placeholder="Choose Image"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>


                  <hr className="mb-3" />
                 <div>
                  
  <h2 className="contentBox-title">Section</h2>
  {f3.map((field, i) => <div key={field.id}>

    <div className="pt-2 pb-2">
      <div className="row align-items-center pb-2">
        <div className="col-12">
          <div className="form-group">
            <label className="form-label">Title</label>
            <div className="mb-3">
              <input
                {...register(`sections.${i}.title`)}
                className="form-control"
                type="text"
                placeholder="title"
                // defaultValue={section.title}
              />
            </div>
          </div>
        </div>
        <div className="col-12">
          <div className="form-group">
            <label className="form-label">Description</label>
            <div className="mb-3">
              <textarea
                {...register(`sections.${i}.description`)}
                className="form-control"
                type="text"
                placeholder="Description"
                // defaultValue={section.description}
              />
            </div>
          </div>
        </div>
      </div>
     
      <div  className="row align-items-top pb-4">
      {f3[i].subSections.map((subSection, subSectionIndex) => (
          <div  key={subSection.id}className="col-4">
            <div className="p-3 innerBox">
        
              <div   className="row">
             
                <div  className="col-12">
                  <div className="form-group">
                    <label className="form-label">Title</label>
                    <div className="mb-3">
                     
                    <input
                                {...register(`sections.${i}.subSections.${subSectionIndex}.title`)}
                                className="form-control"
                                type="text"
                                placeholder="The Tech"
                              />

                    </div>
                  </div>
                </div>

                {subSection.description === "" ? (
                  <div className="col-12">
                    <div className="form-group">
                      <label className="form-label">Upload Logo</label>
                      <div className="mb-3">
                     
                      <input
                                  {...register(`sections.${i}.subSections.${subSectionIndex}.uploadlogo`)}
                                  accept="image/*"
                                  className="form-control"
                                  type="file"
                                  placeholder="Choose logo"
                                  onChange={event => onImageSelect(event, subSection, 'subsection')}
                                />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="col-12">
                    <div className="form-group">
                      <label className="form-label">Description</label>
                      <div className="mb-3">
                      <textarea
                                  {...register(`sections.${i}.subSections.${subSectionIndex}.description`)}
                                  className="form-control"
                                  type="text"
                                  placeholder="Description"
                                />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            
            </div>
          </div>
      ))}
      </div>

    </div>
  </div>)}
</div>





                </div>
              </div>
            </div>
          ) : (
            <p>Loading...</p>
          )}



        </div>
      </form>
    </section>


  )
};
export default Dia_structure_edit;





// const Dia_structure_edit = () => {
//   return (
//     <section className="center-section miniNav">
//       <div className="appArea">
//         <div className="contentWrap">
//           <div className="sectionHead">
//             <div className="row align-items-center">
//               <div className="col-6">
//                 <h1 className="pageTitle">Edit DI&A Structure</h1>
//                 <nav aria-label="breadcrumb">
//                   <ol className="breadcrumb">
//                     <li className="breadcrumb-item">
//                       <a href="pages.html">Pages</a>
//                     </li>
//                     <li className="breadcrumb-item">
//                       <a href="di_a_structure.html">DI&A Structure</a>
//                     </li>
//                     <li className="breadcrumb-item active" aria-current="page">
//                       Edit
//                     </li>
//                   </ol>
//                 </nav>
//               </div>
//               <div className="col-6 text-end">
//                 <a
//                   className="btn btn-text"
//                   title="Cancel"
//                   href="di_a_structure.html"
//                 >
//                   {" "}
//                   Cancel
//                 </a>
//                 <button
//                   className="btn btn-outline-primary ms-3"
//                   title="Save as Draft"
//                 >
//                   <b className="icon-save"></b> Save as Draft
//                 </button>
//                 <a
//                   className="btn btn-primary ms-3"
//                   title="Publish"
//                   href="di_a_structure.html"
//                 >
//                   {" "}
//                   Publish
//                 </a>
//               </div>
//             </div>
//           </div>
//           <div className="sectionbody">
//             <div className="contentBox">
//               <div>
//                 <h2 className="contentBox-title">Banner</h2>
//                 <div className="pt-2 pb-2">
//                   <div className="row align-items-center pb-4">
//                     <div className="col">
//                       <div className="form-group">
//                         <label className="form-label">Banner Image</label>
//                         <div>
//                           <input type="file" className="form-control" />
//                         </div>
//                       </div>
//                     </div>
//                     <div className="col">
//                       <div className="form-group">
//                         <label className="form-label">Banner Name</label>
//                         <div>
//                           <input
//                             type="text"
//                             className="form-control"
//                             value="DI&A Structure"
//                           />
//                         </div>
//                       </div>
//                     </div>
//                     <div className="col">
//                       <div className="form-group">
//                         <label className="form-label">Banner Text</label>
//                         <div>
//                           <input
//                             type="text"
//                             className="form-control"
//                             value="Lorem ipsum dolor sit amet consectetur. Commodo sit eget egestas ipsum bibendum sapien."
//                           />
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>

//               <hr className="mb-3" />

//               <div>
//                 <h2 className="contentBox-title">Title</h2>
//                 <div className="pt-2 pb-2">
//                   <div className="row align-items-center pb-4">
//                     <div className="col">
//                       <input
//                         type="text"
//                         className="form-control"
//                         value="Digital Analytics & Automation Team Methodology"
//                       />
//                     </div>
//                   </div>
//                 </div>
//               </div>

//               <hr className="mb-3" />

//               <div>
//                 <h2 className="contentBox-title">Organizational Chart</h2>
//                 <div className="pt-2 pb-2">
//                   <div className="row align-items-center pb-4">
//                     <div className="col">
//                       <label className="form-label">Title</label>
//                       <div>
//                         <input
//                           type="text"
//                           className="form-control"
//                           value="Digital Innovation & Analytics Organizational Chart"
//                         />
//                       </div>
//                     </div>
//                     <div className="col">
//                       <div className="form-group">
//                         <label className="form-label">Left Side Banner</label>
//                         <div>
//                           <input type="file" className="form-control" />
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>

//               <hr className="mb-3" />

//               <div>
//                 <h2 className="contentBox-title">Section</h2>
//                 <div className="pt-2 pb-2">
//                   <div className="row align-items-center pb-2">
//                     <div className="col-12">
//                       <div className="form-group">
//                         <label className="form-label">Title</label>
//                         <div className="mb-3">
//                           <input
//                             type="text"
//                             className="form-control"
//                             value="Analytics"
//                           />
//                         </div>
//                       </div>
//                     </div>
//                     <div className="col-12">
//                       <div className="form-group">
//                         <label className="form-label">Description</label>
//                         <div className="mb-3">
//                           <textarea className="form-control">
//                             Deploy agile and scalable analytical solutions that
//                             provide data-driven insights and identify real-time
//                             risks Build a hybrid team that is skilled in leading
//                             finance technologies and is enabled to dynamically
//                             solve problems and better target specific risks.
//                           </textarea>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                   <div className="row align-items-top pb-4">
//                     <div className="col-4">
//                       <div className="p-3 innerBox">
//                         <div className="row">
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Title</label>
//                               <div className="mb-3">
//                                 <input
//                                   type="text"
//                                   className="form-control"
//                                   value="The Tech"
//                                 />
//                               </div>
//                             </div>
//                           </div>
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Upload Logo</label>
//                               <div className="mb-3">
//                                 <input type="file" className="form-control" />
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>

//                     <div className="col-4">
//                       <div className="p-3 innerBox">
//                         <div className="row">
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Title</label>
//                               <div className="mb-3">
//                                 <input
//                                   type="text"
//                                   className="form-control"
//                                   value="The Bots"
//                                 />
//                               </div>
//                             </div>
//                           </div>
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Upload Logo</label>
//                               <div className="mb-3">
//                                 <input type="file" className="form-control" />
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>

//                     <div className="col-4">
//                       <div className="p-3 innerBox">
//                         <div className="row">
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Title</label>
//                               <div className="mb-3">
//                                 <input
//                                   type="text"
//                                   className="form-control"
//                                   value="The Results "
//                                 />
//                               </div>
//                             </div>
//                           </div>
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Content</label>
//                               <div className="mb-3">
//                                 <textarea className="form-control">
//                                   Developed audit analytics for all key areas
//                                   Greater risk coverage identified new risks
//                                   faster, more efficiently, and time repurposed
//                                   for value adding activities
//                                 </textarea>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>

//               <hr className="mb-3" />

//               <div>
//                 <h2 className="contentBox-title">Section</h2>
//                 <div className="pt-2 pb-2">
//                   <div className="row align-items-start mb-2">
//                     <div className="col-12">
//                       <div className="form-group">
//                         <label className="form-label">Title</label>
//                         <div className="mb-3">
//                           <input
//                             type="text"
//                             className="form-control"
//                             value="Automation"
//                           />
//                         </div>
//                       </div>
//                     </div>
//                     <div className="col-12">
//                       <div className="form-group">
//                         <label className="form-label">Description</label>
//                         <div className="mb-3">
//                           <textarea className="form-control">
//                             Deploy and implement RPA and automation solutions
//                             that target efficiencies, audit effectiveness, and
//                             better employee experience. Efficiencies in the
//                             audit process will allow resources more time and
//                             focus to deliver on strategic initiatives.
//                           </textarea>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                   <div className="row align-items-start mb-4">
//                     <div className="col-4">
//                       <div className="p-3 innerBox">
//                         <div className="row">
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Title</label>
//                               <div className="mb-3">
//                                 <input
//                                   type="text"
//                                   className="form-control"
//                                   value="The Tech"
//                                 />
//                               </div>
//                             </div>
//                           </div>
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Upload Logo</label>
//                               <div className="mb-3">
//                                 <input type="file" className="form-control" />
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>

//                     <div className="col-4">
//                       <div className="p-3 innerBox">
//                         <div className="row">
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Title</label>
//                               <div className="mb-3">
//                                 <input
//                                   type="text"
//                                   className="form-control"
//                                   value="The Bots"
//                                 />
//                               </div>
//                             </div>
//                           </div>
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Upload Logo</label>
//                               <div className="mb-3">
//                                 <input type="file" className="form-control" />
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>

//                     <div className="col-4">
//                       <div className="p-3 innerBox">
//                         <div className="row">
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Title</label>
//                               <div className="mb-3">
//                                 <input
//                                   type="text"
//                                   className="form-control"
//                                   value="The Results "
//                                 />
//                               </div>
//                             </div>
//                           </div>
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Content</label>
//                               <div className="mb-3">
//                                 <textarea className="form-control">
//                                   Developed RPA to support audit testing and
//                                   documentation Enhanced employee experience
//                                   Saved thousands of hours
//                                 </textarea>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>

//               <hr className="mb-3" />
//               <div>
//                 <h2 className="contentBox-title">Section</h2>
//                 <div className="pt-2 pb-2">
//                   <div className="row align-items-start mb-2">
//                     <div className="col-12">
//                       <div className="form-group">
//                         <label className="form-label">Title</label>
//                         <div className="mb-3">
//                           <input
//                             type="text"
//                             className="form-control"
//                             value="Audit Risk Assessment"
//                           />
//                         </div>
//                       </div>
//                     </div>
//                     <div className="col-12">
//                       <div className="form-group">
//                         <label className="form-label">Description</label>
//                         <div className="mb-3">
//                           <textarea className="form-control">
//                             Leverage enterprise data conduct risk assessments
//                             and extract deeper and more valuable insights for
//                             more efficient and effective audit planning and
//                             continuous monitoring, all while helping the
//                             organization make better decisions by addressing and
//                             managing current risks and illuminating new risks
//                             and unforeseen consequences inherent in operations
//                             and growth strategies
//                           </textarea>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                   <div className="row align-items-start mb-4">
//                     <div className="col-4">
//                       <div className="p-3 innerBox">
//                         <div className="row">
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Title</label>
//                               <div className="mb-3">
//                                 <input
//                                   type="text"
//                                   className="form-control"
//                                   value="The Tech"
//                                 />
//                               </div>
//                             </div>
//                           </div>
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Description</label>
//                               <div className="mb-3">
//                                 <textarea className="form-control">
//                                   Lorem Ipsum is simply dummy text of the
//                                   printing and typesetting industry. Lorem Ipsum
//                                   has been the industry's
//                                 </textarea>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                     <div className="col-4">
//                       <div className="p-3 innerBox">
//                         <div className="row">
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Title</label>
//                               <div className="mb-3">
//                                 <input
//                                   type="text"
//                                   className="form-control"
//                                   value="The Awards"
//                                 />
//                               </div>
//                             </div>
//                           </div>
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Description</label>
//                               <div className="mb-3">
//                                 <textarea className="form-control">
//                                   Lorem Ipsum is simply dummy text of the
//                                   printing and typesetting industry. Lorem Ipsum
//                                   has been the industry's
//                                 </textarea>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                     <div className="col-4">
//                       <div className="p-3 innerBox">
//                         <div className="row">
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Title</label>
//                               <div className="mb-3">
//                                 <input
//                                   type="text"
//                                   className="form-control"
//                                   value="The Results"
//                                 />
//                               </div>
//                             </div>
//                           </div>
//                           <div className="col-12">
//                             <div className="form-group">
//                               <label className="form-label">Description</label>
//                               <div className="mb-3">
//                                 <textarea className="form-control">
//                                   Lorem Ipsum is simply dummy text of the
//                                   printing and typesetting industry. Lorem Ipsum
//                                   has been the industry's
//                                 </textarea>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>

//               <hr className="mb-3" />
//               <div>
//                 <h2 className="contentBox-title">Section</h2>
//                 <div className="pt-2 pb-2">
//                   <div className="row align-items-start mb-4">
//                     <div className="col-12">
//                       <div className="form-group">
//                         <label className="form-label">Title</label>
//                         <div className="mb-3">
//                           <input
//                             type="text"
//                             className="form-control"
//                             value="System we support"
//                           />
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                   <div className="row align-items-start mb-4">
//                     <div className="col-4">
//                       <div className="row">
//                         <div className="col-12">
//                           <div className="form-group">
//                             <label className="form-label">Title</label>
//                             <div className="mb-3">
//                               <input
//                                 type="text"
//                                 className="form-control"
//                                 value="Application Support"
//                               />
//                             </div>
//                           </div>
//                         </div>
//                         <div className="col-12">
//                           <div className="form-group">
//                             <label className="form-label">Upload Image</label>
//                             <div className="mb-3">
//                               <input type="file" className="form-control" />
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="form-group">
//                             <label className="form-label">Description</label>
//                             <div className="mb-3">
//                               <textarea className="form-control">
//                                 Centrally manage and account for all audit
//                                 applications to ensure strong data governance,
//                                 app support, and cost-effectiveness.
//                               </textarea>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Technology Assests / Software"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     TeamMate+ i-Sight
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Capabilities"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     Management of audit and investigation tools
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Matured Areas "
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     Management and reporting for audit and
//                                     investigation tools
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Growth Areas"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     Risk Assessment
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Technology Solutions"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     TM+ Production TM+QAI TM+ QA i-Sight Prod
//                                     i-SightQA
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>

//                     <div className="col-4">
//                       <div className="row">
//                         <div className="col-12">
//                           <div className="form-group">
//                             <label className="form-label">Title</label>
//                             <div className="mb-3">
//                               <input
//                                 type="text"
//                                 className="form-control"
//                                 value="User Access Management"
//                               />
//                             </div>
//                           </div>
//                         </div>
//                         <div className="col-12">
//                           <div className="form-group">
//                             <label className="form-label">Upload Image</label>
//                             <div className="mb-3">
//                               <input type="file" className="form-control" />
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="form-group">
//                             <label className="form-label">Description</label>
//                             <div className="mb-3">
//                               <textarea className="form-control">
//                                 Centrally manage and account for all audit
//                                 applications to ensure strong data governance,
//                                 app support, and cost-effectiveness.
//                               </textarea>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Technology Assests / Software"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     TeamMate+ i-Sight
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Capabilities"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     Management of audit and investigation tools
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Matured Areas "
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     Management and reporting for audit and
//                                     investigation tools
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Growth Areas"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     Risk Assessment
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Technology Solutions"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     TM+ Production TM+QAI TM+ QA i-Sight Prod
//                                     i-SightQA
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>

//                     <div className="col-4">
//                       <div className="row">
//                         <div className="col-12">
//                           <div className="form-group">
//                             <label className="form-label">Title</label>
//                             <div className="mb-3">
//                               <input
//                                 type="text"
//                                 className="form-control"
//                                 value="Share Point Management"
//                               />
//                             </div>
//                           </div>
//                         </div>
//                         <div className="col-12">
//                           <div className="form-group">
//                             <label className="form-label">Upload Image</label>
//                             <div className="mb-3">
//                               <input type="file" className="form-control" />
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="form-group">
//                             <label className="form-label">Description</label>
//                             <div className="mb-3">
//                               <textarea className="form-control">
//                                 Centrally manage and account for all audit
//                                 applications to ensure strong data governance,
//                                 app support, and cost-effectiveness.
//                               </textarea>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Technology Assests / Software"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     TeamMate+ i-Sight
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Capabilities"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     Management of audit and investigation tools
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Matured Areas "
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     Management and reporting for audit and
//                                     investigation tools
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Growth Areas"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     Risk Assessment
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="col-12">
//                           <div className="p-2 pt-3 pb-3 innerBox mb-3">
//                             <div className="mb-3">
//                               <div className="form-group">
//                                 <label className="form-label">Title</label>
//                                 <div>
//                                   <input
//                                     type="text"
//                                     className="form-control"
//                                     value="Technology Solutions"
//                                   />
//                                 </div>
//                               </div>
//                             </div>
//                             <div>
//                               <div className="form-group">
//                                 <label className="form-label">
//                                   Description
//                                 </label>
//                                 <div>
//                                   <textarea className="form-control">
//                                     TM+ Production TM+QAI TM+ QA i-Sight Prod
//                                     i-SightQA
//                                   </textarea>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </section>
//   );
// };

// export default Dia_structure_edit;
