import { Link } from "react-router-dom";
const DiaStructureDark = () => {
  return (
    <main className="darkMode">
      <section className="center-section miniNav">
        <div className="appArea">
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">
                    DI&A Structure{" "}
                    <span className="text-uppercase badge badge-success">
                      Active{" "}
                    </span>
                  </h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <a href="pages.html">Pages</a>
                      </li>
                      <li
                        className="breadcrumb-item active"
                        aria-current="page"
                      >
                        DI&A Structure
                      </li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                  <button className="btn btn-text" title="Cancel">
                    {" "}
                    Cancel
                  </button>
                  <Link
                    to="/dia_structure_edit"
                    className="btn btn-primary ms-3"
                  >
                    <b className="icon-edit-3"></b>
                    Edit Page
                  </Link>
                </div>
              </div>
            </div>
            <div className="sectionbody">
              <div className="editContent">
                <div className="innerBanner">
                  <div className="innerBanner-item">
                    <div className="innerBanner-info">
                      <div className="contentWrap">
                        <h2>DI&A Structure</h2>
                        <p>
                          Lorem ipsum dolor sit amet consectetur. Commodo sit
                          eget egestas ipsum bibendum sapien.
                        </p>
                      </div>
                    </div>
                    <div className="innerBanner-bg">
                      <img
                        alt="#"
                        src={require("../../assets/img/page_banners/di_a_structure.png")}
                      />
                    </div>
                  </div>
                </div>

                <div className="diaTemplate">
                  <div className="diaTemplate-content">
                    <div className="systemTitle">
                      <div className="contentWrap">
                        <h3>Digital Analytics & Automation Team Methodology</h3>
                      </div>
                    </div>
                    <div className="contentWrap">
                      <img
                        src={require("../../assets/img/members/di_a_org_chart.png")}
                        alt=""
                      />
                    </div>
                  </div>
                </div>
                <div className="middleSection">
                  <div className="contentWrap">
                    <div className="row">
                      <div className="col-6"></div>
                      <div className="col-6">
                        <div className="middleContent">
                          <h3>Analytics</h3>
                          <div className="linear-line"></div>
                          <p>
                            Deploy agile and scalable analytical solutions that
                            provide data-driven insights and identify real-time
                            risks
                          </p>
                          <p>
                            Build a hybrid team that is skilled in leading
                            finance technologies and is enabled to dynamically
                            solve problems and better target specific risks.
                          </p>
                          <div className="row">
                            <div className="col-3">
                              <div className="blockContent">
                                <p>The Tech</p>
                                <img
                                  className="m-auto"
                                  src={
                                    "../../assets/img/structure_images/tech_icons.png"
                                  }
                                  alt=""
                                />
                              </div>
                            </div>
                            <div className="col-5">
                              <div className="blockContent">
                                <p>The People</p>
                                <img
                                  width="215"
                                  src={require("../../assets/img/structure_images/people_icons.png")}
                                  alt=""
                                />
                              </div>
                            </div>
                            <div className="col-4">
                              <div className="blockContent border-none">
                                <p>The Results</p>
                                <ul className="ml-1">
                                  <li>
                                    Developed audit analytics for all key areas
                                  </li>
                                  <li>
                                    Greater risk coverage identified new risks
                                    faster, more efficiently, and time
                                    repurposed for value adding activities
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="middleSection autoSection">
                  <div className="contentWrap">
                    <div className="row">
                      <div className="col-6">
                        <div className="middleContent">
                          <h3>Automation</h3>
                          <div className="linear-line"></div>
                          <p>
                            Deploy and implement RPA and automation solutions
                            that target efficiencies, audit effectiveness, and
                            better employee experience.
                          </p>
                          <p>
                            Efficiencies in the audit process will allow
                            resources more time and focus to deliver on
                            strategic initiatives.
                          </p>
                          <div className="row">
                            <div className="col-4">
                              <div className="blockContent">
                                <p>The Tech</p>
                                <img
                                  className="m-auto"
                                  src={require("../../assets/img/structure_images/tech_icons.png")}
                                  alt=""
                                />
                              </div>
                            </div>
                            <div className="col-4">
                              <div className="blockContent">
                                <p>The BOTs</p>
                                <img
                                  className="m-auto"
                                  src={require("../../assets/img/structure_images/robot_icon.png")}
                                  alt=""
                                />
                              </div>
                            </div>
                            <div className="col-4">
                              <div className="blockContent border-none">
                                <p>The Results</p>
                                <ul className="ml-2">
                                  <li>
                                    Developed RPA to support audit testing and
                                    documentation
                                  </li>
                                  <li>Enhanced employee experience</li>
                                  <li>Saved thousands of hours</li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-6"></div>
                    </div>
                  </div>
                </div>
                <div className="auditSection">
                  <div className="contentWrap">
                    <div className="row">
                      <div className="col-5">
                        <div className="auditContent">
                          <div className="systemTitle">
                            <h3>Audit Risk Assessment</h3>
                          </div>
                          <div className="color-linear-line"></div>
                          <p>
                            Leverage enterprise data conduct risk assessments
                            and extract deeper and more valuable insights for
                            more efficient and effective audit planning and
                            continuous monitoring, all while helping the
                            organization make better decisions by addressing and
                            managing current risks and illuminating new risks
                            and unforeseen consequences inherent in operations
                            and growth strategies.
                          </p>
                        </div>
                      </div>
                      <div className="col-7">
                        <img
                          src={require("../../assets/img/structure_images/audit_risk_img.png")}
                          alt=""
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="supportSection">
                  <div className="contentWrap">
                    <div className="auditContent">
                      <div className="systemTitle">
                        <h3>System we support</h3>
                      </div>
                      <div className="color-linear-line"></div>
                    </div>
                    <div className="row">
                      <div className="col-4">
                        <div className="supportBlock">
                          <div className="supportImage">
                            <div className="roundImg">
                              <img
                                src={require("../../assets/img/structure_images/support_icon_1.png")}
                                alt=""
                              />
                            </div>
                          </div>
                          <div className="supportContent border-left-btm">
                            <div className="supportHeading">
                              Application Support
                            </div>
                            <p>
                              Centrally manage and account for all audit
                              applications to ensure strong data governance, app
                              support, and cost-effectiveness.
                            </p>
                            <div className="pointsBlock">
                              Technology Assests / Software
                            </div>
                            <ul>
                              <li>TeamMate+</li>
                              <li>i-Sight</li>
                            </ul>
                            <div className="pointsBlock">Capabilities</div>
                            <ul>
                              <li>
                                Management of audit and investigation tools
                              </li>
                            </ul>
                            <div className="pointsBlock">Matured Areas</div>
                            <ul>
                              <li>
                                Management and reporting for audit and
                                investigation tools
                              </li>
                            </ul>
                            <div className="pointsBlock">Growth Areas</div>
                            <ul>
                              <li>Risk Assessment</li>
                            </ul>
                            <div className="pointsBlock">
                              Technology Solutions
                            </div>
                            <ul>
                              <li>TM+ Production</li>
                              <li>TM+QAI</li>
                              <li>TM+ QA)</li>
                              <li>i-Sight Prod</li>
                              <li>i-SightQA</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div className="col-4">
                        <div className="supportBlock">
                          <div className="supportImage">
                            <div className="roundImg">
                              <img
                                src={require("../../assets/img/structure_images/support_icon_2.png")}
                                alt=""
                              />
                            </div>
                          </div>
                          <div className="supportContent">
                            <div className="supportHeading">
                              User Access Management
                            </div>
                            <p>
                              Centrally manage and account for all audit
                              applications to ensure strong data governance, app
                              support, and cost-effectiveness.
                            </p>
                            <div className="pointsBlock">
                              Technology Assests / Software
                            </div>
                            <ul>
                              <li>Power Automate</li>
                              <li>Power Apps</li>
                              <li>SharePoint</li>
                            </ul>
                            <div className="pointsBlock">Capabilities</div>
                            <ul>
                              <li>Automation of user access process</li>
                            </ul>
                            <div className="pointsBlock">Matured Areas</div>
                            <ul>
                              <li>Mgt of forms for user access management</li>
                            </ul>
                            <div className="pointsBlock">Growth Areas</div>
                            <ul>
                              <li>Integration with Teammate & i-Sight</li>
                            </ul>
                            <div className="pointsBlock">
                              Technology Solutions
                            </div>
                            <ul>
                              <li>TeamMate user access form</li>
                              <li>GAA Analytical tools user access</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div className="col-4">
                        <div className="supportBlock">
                          <div className="supportImage">
                            <div className="roundImg">
                              <img
                                src={require("../../assets/img/structure_images/support_icon_1.png")}
                                alt=""
                              />
                            </div>
                          </div>
                          <div className="supportContent border-right-btm">
                            <div className="supportHeading">
                              Share Point Management
                            </div>
                            <p>
                              Centrally manage and account for all audit
                              applications to ensure strong data governance, app
                              support, and cost-effectiveness.
                            </p>
                            <div className="pointsBlock">
                              Technology Assests / Software
                            </div>
                            <ul>
                              <li>SharePoint</li>
                            </ul>
                            <div className="pointsBlock">Capabilities</div>
                            <ul>
                              <li>Design and build SharePoint sites</li>
                            </ul>
                            <div className="pointsBlock">Matured Areas</div>
                            <ul>
                              <li>GA&A</li>
                              <li>SOX</li>
                              <li>CBC</li>
                            </ul>
                            <div className="pointsBlock">Growth Areas</div>
                            <ul>
                              <li></li>
                            </ul>
                            <div className="pointsBlock">
                              Technology Solutions
                            </div>
                            <ul>
                              <li>Share Points:</li>
                              <li>GA&A</li>
                              <li>SOX</li>
                              <li>CBC</li>
                              <li>Finance GA&A</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default DiaStructureDark;
