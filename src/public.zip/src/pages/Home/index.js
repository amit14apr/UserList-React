import { Link } from "react-router-dom";
function CmsMain() {
  return (
    <>
      <section className="center-section miniNav">
        <div className="appArea">
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">GA&A Portals</h1>
                </div>
                <div className="col-6 text-end">
                  {/* <!-- <button className="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal"
                title="Add a new portal"><b className="icon-plus"></b> Add New</button> --> */}
                </div>
              </div>
            </div>
            <div className="sectionbody">
              <div className="portalList">
                <ul>
                  <li>
                    <div className="portalBox">
                      <div className="portalBox-title">
                        <div className="portalBox-icon">
                          <b className="icon-bar-chart-2"></b>{" "}
                        </div>

                        <div className="portalBox-text">
                          <h3>
                            <Link to="/digital-innovation-analytics">
                              Digital Innovation & Analytics
                            </Link>
                          </h3>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="portalBox">
                      <div className="portalBox-title">
                        <div className="portalBox-icon">
                          <b className="icon-box"></b>{" "}
                        </div>
                        <div className="portalBox-text">
                          <h3>
                            <a>Compliance Audit & Investigation (CA&I)</a>
                          </h3>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="portalBox">
                      <div className="portalBox-title">
                        <div className="portalBox-icon">
                          <b className="icon-pie-chart"></b>{" "}
                        </div>
                        <div className="portalBox-text">
                          <h3>
                            <a>Office of Strategy & Operations (OSO)</a>
                          </h3>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="portalBox">
                      <div className="portalBox-title">
                        <div className="portalBox-icon">
                          <b className="icon-trello"></b>{" "}
                        </div>
                        <div className="portalBox-text">
                          <h3>
                            <a>Information Technology (IT)</a>
                          </h3>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="portalBox">
                      <div className="portalBox-title">
                        <div className="portalBox-icon">
                          <b className="icon-pie-chart"></b>{" "}
                        </div>
                        <div className="portalBox-text">
                          <h3>
                            <a>SOX PMO</a>
                          </h3>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="portalBox">
                      <div className="portalBox-title">
                        <div className="portalBox-icon">
                          <b className="icon-dollar-sign"></b>{" "}
                        </div>
                        <div className="portalBox-text">
                          <h3>
                            <a>Finance</a>
                          </h3>
                        </div>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* <!-- DELETE MODAL --> */}
      <div
        className="modal fade"
        id="deleteModal"
        tabindex="-1"
        role="dialog"
        aria-hidden="true"
      >
        <div
          role="document"
          className="modal-dialog modal-dialog-centered modal-sm"
        >
          <div className="modal-content msgContent">
            <div className="modal-body">
              <button
                className="close btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
                type="button"
              ></button>
              <h2 className="msgContent-title">Confirmation</h2>
              <p className="msgContent-text">
                Are you sure you want to delete?
              </p>
            </div>
            <div className="modal-footer justify-content-end ">
              <button
                type="button"
                data-bs-dismiss="modal"
                className="btn btn-text"
              >
                {" "}
                Cancel{" "}
              </button>
              <button type="button" className="btn btn-primary">
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- ADD NEW MODAL --> */}
      <div
        className="modal fade"
        id="addModal"
        tabindex="-1"
        role="dialog"
        aria-hidden="true"
      >
        <div role="document" className="modal-dialog modal-dialog-centered  ">
          <div className="modal-content">
            <div className="modal-header">
              <h2 className="modal-title">Add New Portal</h2>
              <button
                className="close btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
                type="button"
              ></button>
            </div>
            <div className="modal-body">
              <ul className="modalForm">
                <li>
                  <div className="form-group">
                    <label className="form-label">Name</label>
                    <div>
                      <input type="text" className="form-control" />
                    </div>
                    <small className="form-valid error">This is required</small>
                  </div>
                </li>
                <li>
                  <div className="form-group">
                    <label className="form-label">Description</label>
                    <div>
                      <textarea className="form-control"></textarea>
                    </div>
                  </div>
                </li>
                <li>
                  <div className="form-group">
                    <label className="form-label">Status</label>
                    <div className="pt-1">
                      <label className="d-inline-flex align-items-center customRadio active">
                        <input type="radio" name="radio" checked />
                        <span>Active</span>
                      </label>

                      <label className="d-inline-flex align-items-center customRadio inactive ms-3">
                        <input type="radio" name="radio" />
                        <span>Inactive</span>
                      </label>
                    </div>
                  </div>
                </li>
                <li>
                  <div className="form-group">
                    <label className="form-label">Icon</label>
                    <div>
                      <input type="file" className="form-control" />
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div className="modal-footer justify-content-end ">
              <button
                type="button"
                data-bs-dismiss="modal"
                className="btn btn-text"
              >
                {" "}
                Cancel{" "}
              </button>
              <button type="button" className="btn btn-primary">
                Add
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default CmsMain;
