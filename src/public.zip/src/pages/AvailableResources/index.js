import { Link } from "react-router-dom";

const Available_data_source = () => {
  return (
    <section className="center-section miniNav">
      <div className="appArea">
        <div className="contentWrap">
          <div className="sectionHead">
            <div className="row align-items-center">
              <div className="col-6">
                <h1 className="pageTitle">
                  Available Data Sources{" "}
                  <span className="text-uppercase badge badge-success">
                    Active{" "}
                  </span>
                </h1>
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                      <a href="/digital-innovation-analytics">Pages</a>
                    </li>
                    <li className="breadcrumb-item active" aria-current="page">
                      Available Data Sources
                    </li>
                  </ol>
                </nav>
              </div>
              <div className="col-6 text-end">
                <a className="btn btn-text" title="Cancel" href="/digital-innovation-analytics">
                  {" "}
                  Cancel
                </a>

                <Link
                  to="/digital-innovation-analytics/available-data-sources/edit"
                  className="btn btn-primary ms-3"
                >
                  <b className="icon-edit-3"></b> Edit Page
                </Link>
              </div>
            </div>
          </div>
          <div className="sectionbody">
            <div className="editContent">
              <div className="innerBanner">
                <div className="innerBanner-item">
                  <div className="innerBanner-info">
                    <div className="contentWrap">
                      <h2>Available Data Sources</h2>
                      <p>
                        Lorem ipsum dolor sit amet consectetur. Commodo sit eget
                        egestas ipsum bibendum sapien.
                      </p>
                    </div>
                  </div>
                  <div className="innerBanner-bg">
                    <img
                      alt="#"
                      src={require("../../assets/img/page_banners/available_data_sources.png")}
                    />
                  </div>
                </div>
              </div>
              <div className="solutionsOfferedSection">
                <div className="contentWrap">
                  <div className="offeredWrap">
                    <h3>Digital Solutions Offered</h3>
                    <ul className="offeredList">
                      <li>
                        <div className="solutionsItem">
                          <div className="solutionsItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/solution_apps/icon_01.png")}
                            />
                          </div>
                          <div className="solutionsItem-title">
                            <h4>Alteryx Solutions</h4>
                            <p>Lorem ipsum dolor sit amet consectetur. </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="solutionsItem">
                          <div className="solutionsItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/solution_apps/icon_04.png")}
                            />
                          </div>
                          <div className="solutionsItem-title">
                            <h4>Tableau Visualizations</h4>
                            <p>Lorem ipsum dolor sit amet consectetur. </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="solutionsItem">
                          <div className="solutionsItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/solution_apps/icon_02.png")}
                            />
                          </div>
                          <div className="solutionsItem-title">
                            <h4>Power Automate Automation</h4>
                            <p>Lorem ipsum dolor sit amet consectetur. </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="solutionsItem">
                          <div className="solutionsItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/solution_apps/icon_03.png")}
                            />
                          </div>
                          <div className="solutionsItem-title">
                            <h4>Language Translating Tools </h4>
                            <p>Lorem ipsum dolor sit amet consectetur. </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="solutionsItem">
                          <div className="solutionsItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/solution_apps/icon_05.png")}
                            />
                          </div>
                          <div className="solutionsItem-title">
                            <h4>Extraction Tools (PDFs and more!)</h4>
                            <p>Lorem ipsum dolor sit amet consectetur. </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="solutionsItem">
                          <div className="solutionsItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/solution_apps/icon_06.png")}
                            />
                          </div>
                          <div className="solutionsItem-title">
                            <h4>Automation Bots</h4>
                            <p>Lorem ipsum dolor sit amet consectetur. </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="solutionsItem">
                          <div className="solutionsItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/solution_apps/icon_07.png")}
                            />
                          </div>
                          <div className="solutionsItem-title">
                            <h4>REST APIs (Data Collection Tool)</h4>
                            <p>Lorem ipsum dolor sit amet consectetur. </p>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="accountAccessSection">
                <div className="contentWrap">
                  <div className="accountAccessWrap">
                    <h3>Systems We Use</h3>
                    <div className="accountAccessList">
                      <div className="accountAccessGroup">
                        <h4>ERPs</h4>
                        <h5>Service Account Access</h5>
                        <ul>
                          <li>Galaxy RPM 050</li>
                          <li>Galaxy RPM 232</li>
                          <li>Europe2 RPE</li>
                          <li>MARS EJI PRD</li>
                          <li>FP3 LYNX ECC</li>
                          <li>SAP Surgical Vision</li>
                          <li>Beacon RPI</li>
                          <li>Project One LATAM PLA 120</li>
                          <li>Atlas Prod RPV</li>
                          <li>FP5 Production</li>
                          <li>GP5 Lynx ECC</li>
                          <li>Synthes POI Production</li>
                          <li>Consumer Production POO</li>
                          <li>Panda Prod EPI</li>
                          <li>2 PRI Production ERP</li>
                          <li>B2B Production</li>
                          <li>B2B Production RPG</li>
                          <li>B2B Production RP3</li>
                          <li>BTB P53</li>
                          <li>Synthes GRC ACP Production</li>
                          <li>Mercury RPN 120</li>
                          <li>USROTC PRD MP2 ECC</li>
                          <li>BTB P60 DVW</li>
                          <li>STF OPC</li>
                          <li>STF RPC</li>
                          <li>Sustain RPB</li>
                          <li>BPM 172</li>
                          <li>Europe2 QPJ</li>
                          <li>Europe2 BPI</li>
                          <li>SNC QPE</li>
                          <li>DI&A Access</li>
                        </ul>
                      </div>
                      <div className="accountAccessGroup">
                        <h4>JDE</h4>
                        <h5>Service Account Access</h5>
                        <ul>
                          <li>EMEA MD</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="dataSystemSection">
                <div className="contentWrap">
                  <div className="dataSystemWrap">
                    <h3>Data Lakes</h3>

                    <ul className="dataSystemList">
                      <li>
                        <div className="dataSystemItem">
                          <div className="dataSystemItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/data_lakes_systems/teradata.png")}
                            />
                          </div>
                          <div className="dataSystemItem-text">
                            <p>
                              Enterprise data lake containing information such
                              as Workday information, currency conversion rates,
                              Ariba Purchase Orders, etc
                            </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="dataSystemItem">
                          <div className="dataSystemItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/data_lakes_systems/cloudera.png")}
                            />
                          </div>
                          <div className="dataSystemItem-text">
                            <p>
                              Enterprise data lake containing information such
                              as Workday information, currency conversion rates,
                              Ariba Purchase Orders, etc
                            </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="dataSystemItem">
                          <div className="dataSystemItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/data_lakes_systems/intella.png")}
                            />
                          </div>
                          <div className="dataSystemItem-text">
                            <p>
                              Enterprise data lake containing information such
                              as Workday information, currency conversion rates,
                              Ariba Purchase Orders, etc
                            </p>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="dataSystemSection">
                <div className="contentWrap">
                  <div className="dataSystemWrap">
                    <h3>GA&A Systems</h3>

                    <ul className="dataSystemList">
                      <li>
                        <div className="dataSystemItem">
                          <div className="dataSystemItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/data_lakes_systems/teammate.png")}
                            />
                          </div>
                          <div className="dataSystemItem-text">
                            <p>
                              Enterprise data lake containing information such
                              as Workday information, currency conversion rates,
                              Ariba Purchase Orders, etc
                            </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="dataSystemItem">
                          <div className="dataSystemItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/data_lakes_systems/isight.png")}
                            />
                          </div>
                          <div className="dataSystemItem-text">
                            <p>
                              Application used to manage SI logs and Case
                              Management for GA&A Audits, Audit Log internal
                              financial and HCC investigations
                            </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="dataSystemItem">
                          <div className="dataSystemItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/data_lakes_systems/tableau.png")}
                            />
                          </div>
                          <div className="dataSystemItem-text">
                            <p>
                              Tableau server giving live browser access to view
                              dashboards
                            </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="dataSystemItem">
                          <div className="dataSystemItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/data_lakes_systems/alteryx.png")}
                            />
                          </div>
                          <div className="dataSystemItem-text">
                            <p>
                              Scheduled workflows to run regularly and allows
                              users to run workflows without an alteryx license
                            </p>
                          </div>
                        </div>
                      </li>

                      <li>
                        <div className="dataSystemItem">
                          <div className="dataSystemItem-icon">
                            <img
                              alt="#"
                              src={require("../../assets/img/data_lakes_systems/sharepoint.png")}
                            />
                          </div>
                          <div className="dataSystemItem-text">
                            <p>
                              ​​​​​​​Custom lists that can be pulled into
                              workflows via Alteryx
                            </p>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Available_data_source;
