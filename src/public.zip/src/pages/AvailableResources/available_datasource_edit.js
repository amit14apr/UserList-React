import { useFieldArray, useForm } from "react-hook-form";
import { initialValues } from "./data_ads";
import { COCKPIT_BASE_URL, updateContent } from "../../utils/helper";
import useFetch from "../../hooks/useFetch";
import { useEffect, useState } from "react";
import axios from "axios";

const Available_datasource_edit = () => {
  const [initialData, setInitialData] = useState({});
  
  

  const { error, data } = useFetch(
    `${COCKPIT_BASE_URL}/availabledatasources/11`
  );

  useEffect(() => {
    setInitialData(data);
  }, [data?.data]);

  const { register, handleSubmit, control } = useForm({
    defaultValues: initialValues,
    values: data?.data,
  });

  const {
    fields: f1,
    append: a1,
    remove: r1,
  } = useFieldArray({
    control,
    name: "banners",
  });

  const {
    fields: f2,
    append: appendSystems,
    remove: removeSystems,
  } = useFieldArray({
    control,
    name: "systems",
  });

  const {
    fields: f3,
    append: appendSolutions,
    remove: removeSolutions,
  } = useFieldArray({
    control,
    name: "solutions",
  });

  const {
    fields: f4,
    append: appendSoftwares,
    remove: removeSoftwares,
  } = useFieldArray({
    control,
    name: "softwares",
  });

  let tempData = [];
  const onImageSelect = (event, field, requestFor) => {
    console.log("🚀 ~ onImageSelect ~ field:", field)
    console.log("🚀 ~ onImageSelect ~ requestFor:", requestFor)
    const token = JSON.parse(localStorage.getItem('token'))[0]?.idToken;
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    const source = axios.CancelToken.source();
    axios
      .post(
        "https://dev.cockpit.jnj.com/api/pages/upload",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            'Authorization': token,
            'url': 'cms'
          },
        },
        { cancelToken: source.token }
      )
      .then((res) => {
        if (requestFor == "banner") {
          data?.data?.banners.forEach((element) => {
            if (element.bannerid == field.bannerid) {
              tempData.push({
                requestFor: requestFor,
                bannerid: field.bannerid,
                url: res.data.url,
              });
            }
          });
        } else if (requestFor == "solutions") {
          data?.data?.solutions.forEach((element) => {
            console.log("🚀 ~ data?.data?.solutions.forEach ~ element:", element)
            if (element.title == field) {
              console.log("🚀 ~ success:")
              tempData.push({
                requestFor: requestFor,
                id: field,
                url: res.data.url,
              });
            }
            else{
              tempData.push({
                requestFor: requestFor,
                id: field,
                url: res.data.url
              })
            }
            
          });
        } else if (requestFor == "softwares") {
          debugger;
          data?.data?.solutions.forEach((element) => {
            if (element.id == field) {
              tempData.push({
                requestFor: requestFor,
                id: field,
                url: res.data.url,
              });
            }
          });
        } else {
          tempData.push({ requestFor: requestFor, url: res.data.url });
        }
      })

      .catch((err) => {
        console.log("🚀 ~ onImageSelect ~ err:", err);
      });
  };

  const onSubmit = (data) => {
    const { detail, ...rest } = data;
    const newData = { ...detail, ...rest };
    console.log("🚀 ~ onSubmit ~ newData:", newData)
    console.log("🚀 ~ tempData.forEach ~ tempData:", tempData)
    tempData.forEach((element, index) => {
      if (element.requestFor === "banner") {
        console.log("banner")

        newData.banners.forEach((item) => {
          if (item.bannerid === element.bannerid) {
            item.bannerimage = element.url;
          }
        });
      } else if (element.requestFor == "solutions") {
        console.log("solutions")
        newData.solutions.forEach((item) => {
          console.log("🚀 ~ newData.solutions.forEach ~ item:", item)
          if (item.title === element.id) {
            item.imagepath = element.url;
          }
        });
      } else if (element.requestFor === "softwares") {
        console.log("software")

        debugger;
        newData.softwares.forEach((item) => {
          if (item.id === element.id) {
            item.uploadthumbnail = element.url;
          }
        });
      } else {
        newData[element.requestFor] = element.url;
      }
    });
    newData.gaData = newData.softwares;
    delete newData["softwares"];
    var currentDate = new Date();

    newData.systems.forEach((element, index) => {
      if (!element.savedraft) {
        element.savedraft = false
      }
      if (!element.updateddatetime) {
        var formattedDate = currentDate.toISOString();
        element.updateddatetime = formattedDate
      }
    })
    updateContent("/availabledatasources/available-data-sources/0", newData);
    console.log("🚀 ~ onSubmit ~ newData:", newData);
  };

  return (
    <section className="center-section miniNav">
      <div className="appArea">
        <div className="contentWrap">
          <div className="sectionHead">
            <div className="row align-items-center">
              <div className="col-6">
                <h1 className="pageTitle">Edit Available Data Sources</h1>
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                      <a href="/digital-innovation-analytics">Pages</a>
                    </li>
                    <li className="breadcrumb-item">
                      <a href="available_data_sources.html">
                        Available Data Sources
                      </a>
                    </li>
                    <li className="breadcrumb-item active" aria-current="page">
                      Edit
                    </li>
                  </ol>
                </nav>
              </div>
              <div className="col-6 text-end">
                <a
                  className="btn btn-text"
                  title="Cancel"
                  href="/digital-innovation-analytics"
                >
                  {" "}
                  Cancel
                </a>
                {/*<button className="btn btn-outline-primary ms-3" title="Save as Draft"><b className="icon-save"></b>Save as Draft</button>*/}
                <button
                  className="btn btn-primary ms-3"
                  title="Publish"
                  form="ads-form"
                >
                  {" "}
                  Publish
                </button>
              </div>
            </div>
          </div>
          <form onSubmit={handleSubmit(onSubmit)} id="ads-form">
            <div className="sectionbody">
              <div className="contentBox">
                {f1.map((field, i) => (
                  <div key={field.id}>
                    <h2 className="contentBox-title">Banner</h2>
                    <div className="pt-2 pb-2">
                      <div className="row align-items-center pb-4">
                        <div className="col">
                          <div className="form-group">
                            <label className="form-label">Banner Image</label>
                            <div>
                              <input
                                type="file"
                                className="form-control"
                                {...register(`banners.${i}.bannerimage`, {
                                  required: false,
                                })}
                                onChange={(event) =>
                                  onImageSelect(event, field, "banner")
                                }
                              />
                            </div>
                          </div>
                        </div>
                        <div className="col">
                          <div className="form-group">
                            <label className="form-label">Banner Name</label>
                            <div>
                              <input
                                type="text"
                                className="form-control"
                                // value="Available Data Sources"
                                {...register(`banners.${i}.bannername`)}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="col">
                          <div className="form-group">
                            <label className="form-label">Banner Text</label>
                            <div>
                              <input
                                type="text"
                                className="form-control"
                                // value="Lorem ipsum dolor sit amet consectetur. Commodo sit eget egestas ipsum bibendum sapien."
                                {...register(`banners.${i}.bannerdescription`)}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                <hr className="mb-3" />

                <div className="pt-3">
                  <div className="row align-items-center pb-4">
                    <div className="col-6">
                      <h2 className="contentBox-title p-0">
                        Digital Solutions Offered
                      </h2>
                    </div>
                    <div className="col-6 text-end">
                      <a
                        title="Add New Member"
                        className="btn btn-outline-primary"
                        data-bs-toggle="modal"
                        data-bs-target="#addSolutionsModal"
                        onClick={() => appendSolutions()}
                      >
                        {" "}
                        Add More
                      </a>
                    </div>
                  </div>
                  {f3.map((field, i) => (
                    <div key={field.id} className="pt-2 pb-2">
                      <div className="p-3 innerBox mb-3">
                        <div className="row align-items-start">
                          <div className="col-4">
                            <div className="form-group mb-3">
                              <label className="form-label">Title</label>
                              <div>
                                <input
                                  type="text"
                                  className="form-control"
                                  {...register(`solutions.${i}.title`)}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-4">
                            <div className="form-group mb-3">
                              <label className="form-label">Upload Logo</label>
                              <div>
                                <input
                                  type="file"
                                  className="form-control"
                                  {...register(`solutions.${i}.imagepath`, {
                                   
                                      onChange: (e) => {
                                        console.log("🚀 ~ e:", e)
                                      }
                                    
                                  })}

                                  onChange={(event) => {

                                    onImageSelect(event, data?.data?.solutions[i]?.title, "solutions")
                                  }
                                  }
                                // {...register(`solutions.${i}.imagepath`)}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-4">
                            <div className="form-group mb-3">
                              <label className="form-label">Description</label>
                              <div>
                                <input
                                  type="text"
                                  className="form-control"
                                  {...register(`solutions.${i}.description`)}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-12 text-end">
                            <button
                              className="btn btn-text ms-3"
                              onClick={() => removeSolutions(i)}
                            >
                              <b className="icon-trash-2"></b> Delete
                            </button>
                          </div>
                        </div>
                      </div>

                    </div>

                  ))}
                </div>

                <hr className="mb-3" />
                <div className="pt-3">
                  <div className="row align-items-center pb-4">
                    <div className="col-6">
                      <h2 className="contentBox-title p-0">Systems We Use</h2>
                    </div>
                    <div className="col-6 text-end">
                      <a
                        title="Add New Member"
                        className="btn btn-outline-primary"
                        data-bs-toggle="modal"
                        data-bs-target="#addSystemsModal"
                        onClick={() => { appendSystems() }}
                      >
                        {" "}
                        Add More
                      </a>
                    </div>
                  </div>
                  {f2.map((field, i) => (
                    <div key={field.id} className="pt-2 pb-2">
                      <div className="row">
                        <div className="col-6">
                          <div className="p-3 innerBox mb-3">
                            <div className="row align-items-start">
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">Title</label>
                                  <div>
                                    <input
                                      type="text"
                                      className="form-control"
                                      {...register(`systems.${i}.title`)}
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">
                                    Service Account Access{" "}
                                  </label>
                                  <div>
                                    <input
                                      type="text"
                                      className="form-control"
                                      {...register(
                                        `systems.${i}.serviceaccountaccess`
                                      )}
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12 text-end">
                                <button className="btn btn-text ms-3" onClick={() => { removeSystems(i) }}>
                                  <b className="icon-trash-2"></b> Delete
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                        {/* <div className="col-6">
                      <div className="p-3 innerBox mb-3">
                        <div className="row align-items-start">
                          <div className="col-12">
                            <div className="form-group mb-3">
                              <label className="form-label">Title</label>
                              <div>
                                <input
                                  type="text"
                                  className="form-control"
                                  value="JDE" />
                              </div>
                            </div>
                          </div>
                          <div className="col-12">
                            <div className="form-group mb-3">
                              <label className="form-label">
                                Service Account Access{" "}
                              </label>
                              <div>
                                <input
                                  type="text"
                                  className="form-control"
                                  value="EMEA MD" />
                              </div>
                            </div>
                          </div>
                          <div className="col-12 text-end">
                            <button className="btn btn-text ms-3">
                              <b className="icon-trash-2"></b> Delete
                            </button>
                          </div>
                        </div>
                      </div>
                    </div> */}
                      </div>
                    </div>
                  ))}
                </div>

                <hr className="mb-3" />
                <div className="pt-3">
                  <div className="row align-items-center pb-4">
                    <div className="col-6">
                      <h2 className="contentBox-title p-0">GA&A Systems </h2>
                    </div>
                    <div className="col-6 text-end">
                      <a
                        title="Add More"
                        className="btn btn-outline-primary"
                        data-bs-toggle="modal"
                        data-bs-target="#addDataLakesModal"
                        onClick={()=> {appendSoftwares()}}
                      >
                        {" "}
                        Add More
                      </a>
                    </div>
                  </div>

                  <div className="pt-2 pb-2">
                    <div className="row">
                      {f4.map((field, i) => (
                        <div key={field.id} className="col-4">
                          <div className="p-3 innerBox mb-3">
                            <div className="row align-items-start">
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">
                                    Upload Thumbnail
                                  </label>
                                  <div>
                                    <input
                                      type="file"
                                      className="form-control"
                                      {...register(
                                        `softwares.${i}.uploadthumbnail`,
                                        { required: false }
                                      )}
                                      onChange={(event) =>
                                        onImageSelect(event, data?.data?.softwares[i].id, "softwares")
                                      }
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="form-group mb-3">
                                  <label className="form-label">
                                    Description
                                  </label>
                                  <div>
                                    <textarea
                                      className="form-control"
                                      {...register(
                                        `softwares.${i}.description`
                                      )}
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12 text-end">
                                <button className="btn btn-text ms-3" onClick={() => {removeSoftwares(i)}}>
                                  <b className="icon-trash-2"></b> Delete
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Available_datasource_edit;
