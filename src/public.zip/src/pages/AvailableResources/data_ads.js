export const initialValues = {
    "pagename": "Available Data sources",
    "title": "Available Data sources",
    "slug": "available-data-sources",
    "type": "template",
    "ordernumber": 1,
    "updateddatetime": "2024-02-29T10:53:16.371Z",
    "updatedby": "SaravanaPrasath",
    "createdAt": null,
    "updatedAt": null,
    "banners": [
      {
        "bannername": "Available Solutions, Systems and Data Sources",
        "bannerimage": "banner1.jpg",
        "bannerlink": "banner.com",
        "bannerdescription": " The DI&A team has secured direct data access to many systems.  This has streamlined the process for providing meaningful digital solutions",
        "updateddate": "2024-03-05T13:36:45Z",
        "pageid": 3,
        "updatedby": "22222"
      }
    ],
    "solutions": [
      {
        "title": "Alteryx Solutions",
        "imagepath": "Homepage",
        "description": "Alteryx is a data analytics tool that allows users to prepare, blend, and analyze data from various sources without requiring ",
        "updateddatetime": "2024-03-05T13:36:45Z",
        "pageid": 3
      },
      {
        "title": "Tableau Visualizations",
        "imagepath": "Homepage",
        "description": "Tableau is a visual analytics platform transforming the way we use data to solve problems empowering people and organizations.",
        "uploadlogo": "logo2",
        "updateddatetime": "2024-03-05T13:36:45Z",
        "pageid": 3
      },
      {
        "title": "Power Automate Automation",
        "imagepath": "Homepage",
        "description": "A comprehensive, end to end cloud automation platform powered by low code and AI.",
        "uploadlogo": "logo2",
        "updateddatetime": "2024-03-05T13:36:45Z",
        "pageid": 3
      },
      {
        "title": "Language Translating Tools ",
        "imagepath": "Homepage",
        "description": "Translation technology is the use of software tools to facilitate the conversion of text from one language to another. ",
        "uploadlogo": "logo2",
        "updateddatetime": "2024-03-05T13:36:45Z",
        "pageid": 3
      },
      {
        "title": "Extraction Tools (PDFs and more!)",
        "imagepath": "Homepage",
        "description": "Text extraction refers to the extraction of text from documents, images or scanned PDFs.",
        "uploadlogo": "logo2",
        "updateddatetime": "2024-03-05T13:36:45Z",
        "pageid": 3
      },
      {
        "title": "Automation Bots",
        "imagepath": "Homepage",
        "description": "Robotic process automation (RPA) is a software technology that ma³es it easy to build, deploy, and manage software robÉ",
        "uploadlogo": "logo2",
        "updateddatetime": "2024-03-05T13:36:45Z",
        "pageid": 3
      },
      {
        "title": "REST APIs (Data Collection Tool)",
        "imagepath": "Homepage",
        "description": "A RESTful API is an architectural style for an application program interface (API) that uses HTTP requests to access and",
        "uploadlogo": "logo2",
        "updateddatetime": "2024-03-05T13:36:45Z",
        "pageid": 3
      }
    ],
    "systems": [
      {
        "title": "ERPs",
        "serviceaccountaccess": "Galaxy RPM 050, Galaxy RPM 232, Europe2 RPE, MARS EJI PRD, FP3 LYNX ECC, SAP Surgical Vision, Beacon Rpi, Project One LATAM PLA 120, Atlas Prod RPV, FP5 Production, GP5 Lynx ECC, Sunthes POI Production, Consumer Production POO, Panda Prod EPI, 2 PRI Production ERP, B2B Production, B2B Production RPG, B2B Production RP3, BTB P53, Synthes GRC ACP Production, Mercury RPN 120, USROTC PRD MP2 ECC, BTB P60 DVW, STF OPC, STF RPC, Sustain RPB, Bpm 172, Europe2QPJ, Europe2 BPI, SNC QPE, DI&A Access",
        "updateddatetime": "2024-03-05T13:36:45Z",
        "savedraft":0,
        "pageid": 3
      },
      {
        "title": "JDE",
        "serviceaccountaccess": "EMEA MD",
        "updateddatetime": "2024-03-05T13:36:45Z",
        "savedraft":0,
        "pageid": 3
      }
    ],
    "gaData": [
      {
        "uploadthumbnail": "test",
        "description": "Enterprise data lake containing information such as Workday information, currency conversation rates, Ariba Purchase Orders, etc.",
        "updatedatatime": "2024-03-05T13:36:45Z",
        "pageid": 3
      },
      {
        "uploadthumbnail": "test",
        "description": "Application used to manage SI logs and Case Management for GA&A Audits, Audit Log internal financial and HCC investigations",
        "updatedatatime": "2024-03-05T13:36:45Z",
        "pageid": 3
      },
      {
        "uploadthumbnail": "test",
        "description": "Enterprise data lake containing information such as Workday information, currency conversation rates, Ariba Purchase Orders, etc.",
        "updatedatatime": "2024-03-05T13:36:45Z",
        "pageid": 3
      },
      {
        "uploadthumbnail": "test",
        "description": "Tempus by ProSymmetry is a sophisticated resource management and scheduling tool tailored to optimize the allocation of workforce and resources.",
        "updatedatatime": "2024-03-05T13:36:45Z",
        "pageid": 3
      }
    ]
  }