import { Link } from "react-router-dom";

const AnalyticsRequest_ = () => {
  return (
    <section class="center-section miniNav">
    <div class="appNav">
      <a class="menuToggle"><b class="icon-menu"></b></a>
      <ul>
        <li><a title="GA&A Portals" href="index.html"><i class="icon-folder"></i><span>GA&A Portals</span></a></li>
      </ul>
    </div>

    <div class="appArea">
      <div class="contentWrap">
        <div class="sectionHead">
          <div class="row align-items-center">
            <div class="col-6">
              <h1 class="pageTitle">Analytics Request <span class="text-uppercase badge badge-success">Active </span></h1>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="/digital-innovation-analytics">Pages</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Analytics Request</li>
                </ol>
              </nav>
            </div>
            <div class="col-6 text-end">
              <a class="btn btn-text" title="Cancel" href="/digital-innovation-analytics"> Cancel</a>
 
              <Link
                    to="/digital-innovation-analytics/analytics-request/edit"
                    className="btn btn-primary ms-3"
                  >
                    <b className="icon-edit-3"></b>
                    Edit Page
                  </Link>
            </div>
          </div>

        </div>
        <div class="sectionbody">
          <div class="editContent">
            <div class="innerBanner bg-transparent">
              <div class="innerBanner-item">
                <div class="innerBanner-info">
                  <div class="contentWrap">
                    <h2>Analytics Request</h2>
                    <p>Lorem ipsum dolor sit amet consectetur. Commodo sit eget egestas ipsum bibendum sapien.</p>
                  </div>
                </div>
                <div class="innerBanner-bg">
                  <img alt="#" src={require("../../assets/img/page_banners/analytics_bg.png")}  />
                </div>
              </div>
            </div>
        
            <div class="analyticsSection">
              <div class="analyticsIntro">
                <div class="contentWrap">
                  <h3>Digital Innovation & Analytics</h3>
                  <p>Welcome to the <span class="red-color">Digital Innovation & Analytics</span> Request Site. Please use the
                    form below to
                    submit a request for a New Asset, Enhancement, Refresh, or Break Fix!</p>
                  <div class="analyticsIntro-iFrame">
                    <img src="assets/img/analytic_images/analytic_01.png" alt="" />
                  </div>
                </div>
              </div>

              <div class="supportSection">
                <div class="contentWrap">
                  <div class="auditContent">
                    <div class="systemTitle">
                      <h3>Support Central</h3>
                    </div>
                    <div class="color-linear-line"></div>
                  </div>
                  <div class="row justify-content-center">
                    <div class="col-4">
                      <div class="supportBlock">
                        <div class="supportImage">
                          <div class="roundImg">
                            <img src={require("../../assets/img/structure_images/support_icon_1.png")} />
                          </div>
                        </div>
                        <div class="supportContent border-left-btm">
                          <div class="supportHeading">
                            Application Support
                          </div>
                          <p>Centrally manage and account for all audit
                            applications to ensure strong data governance,
                            app support, and cost-effectiveness.</p>
                          <div class="pointsBlock">
                            Technology Assests / Software
                          </div>
                          <ul>
                            <li>TeamMate+</li>
                            <li>i-Sight</li>
                          </ul>
                          <div class="pointsBlock">
                            Capabilities
                          </div>
                          <ul>
                            <li>Management of audit and investigation tools</li>
                          </ul>
                          <div class="pointsBlock">
                            Matured Areas
                          </div>
                          <ul>
                            <li>Management and reporting for audit and investigation tools</li>
                          </ul>
                          <div class="pointsBlock">
                            Growth Areas
                          </div>
                          <ul>
                            <li>Risk Assessment</li>
                          </ul>
                          <div class="pointsBlock">
                            Technology Solutions
                          </div>
                          <ul>
                            <li>TM+ Production</li>
                            <li>TM+QAI</li>
                            <li>TM+ QA</li>
                            <li>i-Sight Prod</li>
                            <li>i-SightQA</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-4">
                      <div class="supportBlock">
                        <div class="supportImage">
                          <div class="roundImg">
                            <img src={require("../../assets/img/structure_images/support_icon_2.png")} alt="" />
                          </div>
                        </div>
                        <div class="supportContent">
                          <div class="supportHeading">
                            User Access Management
                          </div>
                          <p>Centrally manage and account for all audit
                            applications to ensure strong data governance,
                            app support, and cost-effectiveness.</p>
                          <div class="pointsBlock">
                            Technology Assests / Software
                          </div>
                          <ul>
                            <li>Power Automate</li>
                            <li>Power Apps</li>
                            <li>SharePoint</li>
                          </ul>
                          <div class="pointsBlock">
                            Capabilities
                          </div>
                          <ul>
                            <li>Automation of user access process</li>
                          </ul>
                          <div class="pointsBlock">
                            Matured Areas
                          </div>
                          <ul>
                            <li>Mgt of forms for user access management</li>
                          </ul>
                          <div class="pointsBlock">
                            Growth Areas
                          </div>
                          <ul>
                            <li>Integration with Teammate & i-Sight</li>
                          </ul>
                          <div class="pointsBlock">
                            Technology Solutions
                          </div>
                          <ul>
                            <li>TeamMate user access form</li>
                            <li>GAA Analytical tools user access</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                 
                  </div>
                </div>
          
              </div>
        
              <div class="contactList">
                <div class="contentWrap">
                  <h3>Contact Details</h3>
                  <p>If you have any questions, <span class="red-color">please reach out to the below pillar</span> leads for
                    more information!</p>
                  <ul>
                    <li>
                      <div class="contactMember">
                        <span class="contactMember-group">Hubstor</span>
                        <div class="contactMember-img"><img alt="#" src={require("../../assets/img/members/person_02.jpg")} /></div>
                        <div class="contactMember-info">
                          <h4>O'Dennis, Karen [JJCUS]</h4>
                          <p>LEAD ANALYST GLOBAL AUDIT & ASSURANCE</p>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="contactMember">
                        <span class="contactMember-group">MBOX-SDX</span>
                        <div class="contactMember-img"><img alt="#" src={require("../../assets/img/members/person_05.jpg")} /></div>
                        <div class="contactMember-info">
                          <h4>O'Dennis, Karen [JJCUS]</h4>
                          <p>LEAD ANALYST GLOBAL AUDIT & ASSURANCE</p>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="contactMember">
                        <span class="contactMember-group">TeamMate+</span>
                        <div class="contactMember-img"><img alt="#" src={require("../../assets/img/members/person_07.png")} /></div>
                        <div class="contactMember-info">
                          <h4>Mastalski, Trish [DPYUS]</h4>
                          <p>LEAD DIGITAL ANALYST</p>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="contactMember">
                        <span class="contactMember-group">DI&A Assets</span>
                        <div class="contactMember-img"><img alt="#" src={require("../../assets/img/members/person_04.png")} /></div>
                        <div class="contactMember-info">
                          <h4>Craig,Cameron [JJCUS]</h4>
                          <p>SENIOR ANALYST GLOBAL AUDIT & ASSURANCE </p>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  );
};

export default AnalyticsRequest_;
