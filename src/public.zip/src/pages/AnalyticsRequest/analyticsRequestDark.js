import { Link } from "react-router-dom";

const AnalyticsRequestDark = () => {
  return (
    <main className="darkMode">
      <section className="center-section miniNav">
        <div className="appArea">
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">
                    Analytics Request{" "}
                    <span className="text-uppercase badge badge-success">
                      Active{" "}
                    </span>
                  </h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <Link to="/cms_pages">Pages</Link>
                      </li>
                      <li
                        className="breadcrumb-item active"
                        aria-current="page"
                      >
                        Analytics Request
                      </li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                  <Link to="/cms_pages" className="btn btn-text" title="Cancel">
                    {" "}
                    Cancel
                  </Link>
                  <Link
                    to="/analytic_request_edit"
                    className="btn btn-primary ms-3"
                    title="Edit"
                  >
                    <b className="icon-edit-3"></b> Edit Page
                  </Link>
                </div>
              </div>
            </div>
            <div className="sectionbody">
              <div className="editContent">
                <div className="innerBanner bg-transparent">
                  <div className="innerBanner-item">
                    <div className="innerBanner-info">
                      <div className="contentWrap">
                        <h2>Analytics Request</h2>
                        <p>
                          Lorem ipsum dolor sit amet consectetur. Commodo sit
                          eget egestas ipsum bibendum sapien.
                        </p>
                      </div>
                    </div>
                    <div className="innerBanner-bg">
                      <img
                        alt="#"
                        src={require("../../assets/img/page_banners/analytics_bg.png")}
                      />
                      )
                    </div>
                  </div>
                </div>

                <div className="analyticsSection">
                  <div className="contentWrap">
                    <div className="systemTitle">
                      <h3>Digital Innovation & Analytics</h3>
                    </div>
                    <div className="analyticsContent">
                      <p>
                        Welcome to the{" "}
                        <span className="red-color">
                          Digital Innovation & Analytics
                        </span>{" "}
                        Request Site. Please use the form below to submit a
                        request for a New Asset, Enhancement, Refresh, or Break
                        Fix!
                      </p>
                      <img
                        src={require("../../assets/img/analytic_images/analytic_01.png")}
                        alt=""
                      />
                    </div>
                  </div>
                </div>
                <hr />
                <div className="analyticsSection">
                  <div className="contentWrap">
                    <div className="systemTitle">
                      <h3>Contact Details</h3>
                    </div>
                    <div className="analyticsContent">
                      <p>
                        If you have any questions,{" "}
                        <span className="red-color">
                          please reach out to the below pillar
                        </span>{" "}
                        leads for more information!
                      </p>
                      <div className="mt-5">
                        <div className="row">
                          <div className="col">
                            <div className="contactBlock">
                              <div className="contactHeading">OSO</div>
                              <img
                                src={require("../../assets/img/analytic_images/user_icon.png")}
                                alt=""
                              />
                              <div className="contactText">
                                Craig, Cameron [JJCUS]
                                <span>
                                  SENIOR ANALYSTGLOBAL AUDIT & ASSURANCE
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="col">
                            <div className="contactBlock">
                              <div className="contactHeading">SOX PMO</div>
                              <img
                                src={require("../../assets/img/analytic_images/user_icon.png")}
                                alt=""
                              />
                              <div className="contactText">
                                Kimbler-muehl, Deana [JJCUS]
                                <span>
                                  LEAD ANALYST GLOBAL AUDIT & ASSURANCE{" "}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="col">
                            <div className="contactBlock">
                              <div className="contactHeading">Digital</div>
                              <img
                                src={require("../../assets/img/analytic_images/user_icon.png")}
                                alt=""
                              />
                              <div className="contactText">
                                Mashami, Paul [JJCUS]
                                <span>Lead Digital Analyst</span>
                              </div>
                            </div>
                          </div>
                          <div className="col">
                            <div className="contactBlock">
                              <div className="contactHeading">Finance</div>
                              <img
                                src={require("../../assets/img/analytic_images/user_icon.png")}
                                alt=""
                              />
                              <div className="contactText">
                                Madimsetty, Sohan [JJCUS]
                                <span>
                                  SENIOR ANALYSTGLOBAL AUDIT & ASSURANCE
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="col">
                            <div className="contactBlock">
                              <div className="contactHeading">Legal</div>
                              <img
                                src={require("../../assets/img/analytic_images/user_icon.png")}
                                alt=""
                              />
                              <div className="contactText">
                                Gu, Wen [JANUS]
                                <span>Digital Investigations Lead</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="row cstom-col">
                          <div className="col-auto">
                            <div className="contactBlock">
                              <div className="contactHeading">IT</div>
                              <img
                                src={require("../../assets/img/analytic_images/user_icon.png")}
                                alt=""
                              />
                              <div className="contactText">
                                Lukose, Lavania
                                <span>[JJCUS NON-J&J]</span>
                              </div>
                            </div>
                          </div>
                          <div className="col-auto">
                            <div className="contactBlock">
                              <div className="contactHeading">CA&I</div>
                              <img
                                src={require("../../assets/img/analytic_images/user_icon.png")}
                                alt=""
                              />
                              <div className="contactText">
                                Mastalski, Trish [DPYUS]
                                <span>LEAD ANALYST GLOBAL</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default AnalyticsRequestDark;
