import React from 'react'
import { Link } from 'react-router-dom'
import useFetch from '../../hooks/useFetch';
import { COCKPIT_BASE_URL, updateContent } from "../../utils/helper";
import { useFieldArray, useForm } from 'react-hook-form';
import { initialData } from './initialData';
import axios from 'axios';

const Analytics_request_edit = () => {
  const { data, loading, error } = useFetch(`${COCKPIT_BASE_URL}/analyticsrequest/3`);
  console.log("🚀 ~ data:", data)
  

  let tempData = [];

  const { register, handleSubmit, control } = useForm({
    defaultValues: initialData,
    values: data?.data
  })

  const { fields: f1, append: a1, remove: r1 } = useFieldArray({
    control,
    name: "banners"
  });

  const { fields: f2, append: a2, remove: r2 } = useFieldArray({
    control,
    name: "contacts"
  });
  
  const { fields: f3, append: a3, remove: r3 } = useFieldArray({
    control,
    name: "details"
  });
  
  const { fields: f4, append: a4, remove: r4 } = useFieldArray({
    control,
    name: "sections"
  });

  console.log("🚀 ~ f2:", f2)

  const onImageSelect = (event, field, requestFor) => {
    const token = JSON.parse(localStorage.getItem('token'))[0].idToken;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    const source = axios.CancelToken.source();
    axios.post("https://dev.cockpit.jnj.com/api/pages/upload", formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        'Authorization': token,
        'url':'cms'
      }
    }, { cancelToken: source.token })
      .then(res => {

        console.log("🚀 ~ onImageSelect ~ data?.data?.banners:", data?.data?.banners)

        if (requestFor == 'banner') {
          data?.data?.banners.forEach(element => {
            console.log("🚀 ~ onImageSelect ~ element:", element)
            if (element.bannerid == field.bannerid) {
              tempData.push({ "requestFor": requestFor, "bannerid": field.bannerid, 'url': res.data.url })
            }
          })

        } else if (requestFor == 'profileimagepath') {

          console.log("🚀 ~ onImageSelect ~ data?.data?.contacts:", data?.data?.contacts)
          console.log("🚀 ~ onImageSelect ~ field:", field)
          data?.data?.contacts.forEach(element => {
            if (element.department == field.department && element.pageid == field.pageid && element.designation == field.designation) {
              tempData.push({ "requestFor": requestFor, "id": element.id, 'url': res.data.url })
            }
          })
        } else if (requestFor == 'uploadlogo') {
          data?.data?.sections.forEach(element => {
            if (element.pageid == field.pageid && element.title == field.title && element.description) {
              tempData.push({ "requestFor": requestFor, "id": element.id, 'url': res.data.url })
            }
          })
        }
      })

      .catch(err => {
        console.log("🚀 ~ onImageSelect ~ err:", err)
      })
  }

  const onSubmit = (data) => {

    console.log("🚀 ~ data:", data)
    console.log("🚀 ~ tempData:", tempData)
    const { detail, contacts:businessContacts, pages, ...rest } = data;
    console.log("🚀 ~ onSubmit ~ detail:", detail)
    console.log("🚀 ~ onSubmit ~ businessContacts:", businessContacts)
    
    const newData = { ...detail, businessContacts, ...rest}
    
    tempData.forEach((element, index) => {
      if (element.requestFor === 'banner') {
        newData.banners.forEach((item, vaue) => {
          if (item.bannerid === element.bannerid) {
            console.log("🚀 ~ newData.banners.forEach ~ item.bannerid:", item.bannerid)
            item.bannerimage = element.url;
          }
        })
      } else if(element.requestFor == 'profileimagepath') {
        newData.businessContacts.forEach((item, vaue) => {
          if (item.id === element.id) {
            
            item.profileimagepath = element.url;
          }
        })
        
        
      } else if(element.requestFor == 'uploadlogo'){
        newData.sections.forEach((item, vaue) => {
          console.log("🚀 ~ newData.sections.forEach ~ item:", item)
          if (item.id === element.id) {
            item.uploadlogo = element.url;
          }
        })
      }
    })
    console.log("🚀 ~ onSubmit ~ newData:", newData);
    console.log("🚀 ~ onSubmit ~ newData:", newData)
   updateContent('/analyticsrequest/analytics-request/0', newData).then(response => console.log(response)).catch(error => console.log(error));


  }

  return (
    <section className="center-section miniNav">
      <div className="appNav">
        <a className="menuToggle"><b className="icon-menu"></b></a>
        <ul>
          <li><a title="GA&A Portals" href="index.html"><i className="icon-folder"></i><span>GA&A Portals</span></a></li>
        </ul>
      </div>


      <div className="appArea">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">Edit Analytics Request</h1>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item"><a href="/digital-innovation-analytics">Pages</a></li>
                      <li className="breadcrumb-item"><a href="analytics_request.html">Analytics Request</a></li>
                      <li className="breadcrumb-item active" aria-current="page">Edit</li>
                    </ol>
                  </nav>
                </div>
                <div className="col-6 text-end">
                  <a className="btn btn-text" title="Cancel" href="cms/digital-innovation-analytics">Cancel</a>
                  {/*<button className="btn btn-outline-primary ms-3" title="Save as Draft"><b className="icon-save"></b>Save as Draft</button>*/}

                  <button type="submit" className="btn btn-primary ms-3" title="Publish" >
                    {" "}
                    Publish
                  </button>
                </div>
              </div>

            </div>
            <div className="sectionbody">
              <div className="contentBox">
                <div>
                  <h2 className="contentBox-title">Banner</h2>
                  <div className="pt-2 pb-2">
                    {
                      f1.map((field, index) => (
                        <div key={field.id} className="row align-items-center pb-4">

                          <div className="col">
                            <div className="form-group">
                              <label className="form-label">Banner Name</label>
                              <div>
                                <input {...register(`banners.${index}.bannername`, { required: false })} type="text" className="form-control" value="Analytics Request" />
                              </div>
                            </div>
                          </div>
                          <div className="col">
                            <div className="form-group">
                              <label className="form-label">Banner Text</label>
                              <div>
                                <input type="text" {...register(`banners.${index}.bannerdescription`, { required: false })} className="form-control" />
                              </div>
                            </div>
                          </div>
                          <div className="col">
                            <div className="form-group">
                              <label className="form-label">Banner Image</label>
                              <div>
                                <input type="file" {...register(`banners.${index}.bannerimage`, { required: false })} onChange={event => onImageSelect(event, field, 'banner')} className="form-control" />
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    }

                  </div>
                </div>
                <hr className="mb-3" />
                <div className="pt-3">

                  <div className="row align-items-center pb-4">
                    <div className="col-6">
                      <h2 className="contentBox-title p-0">Section</h2>
                    </div>
                    <div className="col-6 text-end"> </div>
                  </div>
                  <div className="pt-2 pb-2">
                    {
                      f4.map((field, index) => (
                        <div className="row align-items-start">
                          <div className="col-12">
                            <div className="form-group mb-3">
                              <label className="form-label">Title</label>
                              <div>
                                <input type="text" className="form-control" {...register(`sections.${index}.title`, { required: false })} />
                              </div>
                            </div>
                          </div>
                          <div className="col-12">
                            <div className="form-group mb-3">
                              <label className="form-label">Description</label>
                              <div>
                                <textarea
                                  className="form-control" {...register(`sections.${index}.description`, { required: false })} ></textarea>
                              </div>
                            </div>
                          </div>
                          <div className="col-12">
                            <div className="form-group mb-3">
                              <label className="form-label">Embed Code</label>
                              <div>
                                <textarea className="form-control"><iframe src="https://example.com/embedded-page" title="Embedded Page Title" ></iframe>
                                </textarea>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    }

                  </div>
                </div>

                <hr className="mb-3" />
                <div>
                  <h2 className="contentBox-title">Section</h2>
                  <div className="pt-2 pb-2">

                    <div className="row align-items-start mb-4">
                      <div className="col-12">
                        <div className="form-group">
                          <label className="form-label">Title</label>
                          <div className="mb-3">
                            <input type="text" className="form-control" value="Support Central
                        " />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="row align-items-start mb-4">

                      {
                        f4.map((field, index) => (

                          <div id={field.id} className="col-4">
                            <div className="row">

                              <div className="col-12">
                                <div className="form-group">
                                  <label className="form-label">Title</label>
                                  <div className="mb-3">
                                    <input type="text" className="form-control" {...register(`sections.${index}.title`, { required: false })} />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="form-group">
                                  <label className="form-label">Upload Image</label>
                                  <div className="mb-3">
                                    <input {...register(`sections.${index}.uploadlogo`, { required: false })} onChange={event => { onImageSelect(event, field, 'uploadlogo')}} type="file" className="form-control" />
                                  </div>
                                </div>
                              </div>

                              <div className="col-12">
                                <div className="form-group">
                                  <label className="form-label">Description</label>
                                  <div className="mb-3">
                                    <textarea
                                      className="form-control" {...register(`sections.${index}.description`, { required: false })} ></textarea>
                                  </div>
                                </div>
                              </div>

                              {
                                f4[index].subSections.map((subSection, subSectionIndex) => (
                                  <div className="col-12" id={subSection.id}>
                                    <div className="p-2 pt-3 pb-3 innerBox mb-3">
                                      <div className="mb-3">
                                        <div className="form-group">
                                          <label className="form-label">Title</label>
                                          <div>
                                            <input {...register(`sections.${index}.subSections.${subSectionIndex}.title`)} type="text" className="form-control" />
                                          </div>
                                        </div>
                                      </div>
                                      <div>
                                        <div>
                                          <div className="form-group">
                                            <label className="form-label">Description</label>
                                            <div>
                                              <textarea className="form-control" {...register(`sections.${index}.subSections.${subSectionIndex}.description`)}></textarea>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                ))
                              }
                            </div>
                          </div>
                        ))
                      }

                    </div>

                  </div>
                </div>


                <hr className="mb-3" />
                <div className="pt-3">
                  <div className="row align-items-center pb-4">
                    <div className="col-6">
                      <h2 className="contentBox-title p-0">Contact Details</h2>
                    </div>
                    <div className="col-6 text-end"><a title="Add New Member" className="btn btn-outline-primary"
                      data-bs-toggle="modal" data-bs-target="#addMemberModal"> Add New Member</a></div>
                  </div>
                  <div className="pt-2 pb-2">
                    <div className="form-group mb-3">
                      <label className="form-label">Sub Title</label>
                      <div>
                        <textarea
                          className="form-control" {...register(`detail.businesscontactdescription`, { required: false })} ></textarea>
                      </div>

                    </div>
                  </div>
                  <div className="pt-2 pb-2">
                    {
                      f2.map((field, index) => {
                        return (
                          <div key={field.id} className="p-3 innerBox mb-3">
                            <div className="row align-items-start">
                              <div className="col-4">
                                <div className="form-group mb-3">
                                  <label className="form-label">Name</label>
                                  <div>
                                    <input type="text" className="form-control" {...register(`contacts.${index}.name`, { required: false })} />
                                  </div>
                                </div>
                              </div>
                              <div className="col-4">
                                <div className="form-group mb-3">
                                  <label className="form-label">Designation</label>
                                  <div>
                                    <input type="text" className="form-control" {...register(`contacts.${index}.designation`, { required: false })} />
                                  </div>
                                </div>
                              </div>
                              <div className="col-4">
                                <div className="form-group mb-3">
                                  <label className="form-label">Department</label>
                                  <div>
                                    <input type="text" className="form-control" {...register(`contacts.${index}.department`, { required: false })} />
                                  </div>
                                </div>
                              </div>
                              <div className="col-4">
                                <div className="form-group mb-3">
                                  <label className="form-label">Profile Image</label>
                                  <div>
                                    <input type="file" className="form-control" {...register(`contacts.${index}.profileimagepath`, { required: false })} onChange={event => onImageSelect(event, field, 'profileimagepath')} />
                                  </div>
                                </div>
                              </div>
                              <div className="col-4">
                                <div className="form-group mb-3">
                                  <label className="form-label">Group Name</label>
                                  <div>
                                    <input type="text" className="form-control" {...register(`contacts.${index}.groupname`, { required: false })} />
                                  </div>
                                </div>
                              </div>
                              <div className="col-12 text-end">
                                <button className="btn btn-text ms-3"><b className="icon-trash-2"></b> Delete</button>
                              </div>
                            </div>
                          </div>
                        )
                      })
                    }

                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </section>
  )
}

export default Analytics_request_edit