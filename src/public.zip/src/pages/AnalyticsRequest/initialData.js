export const initialData = {
    
        "data": {
            "detail": {
                "pageid": 3,
                "pagename": "Analytics Request",
                "title": "Analytics Request",
                "description": null,
                "notes": null,
                "supportcentraltitle": "Support Central",
                "businesscontacttitle": "Business Contact",
                "businesscontactdescription": "if you have any questions, please reach out to the below pillar leads for more information!",
                "powerappsembededlink": "powerappslink",
                "organizationalchartimage": null,
                "organizationalcharttitle": null,
                "slug": "analytics-request",
                "thumnail": null,
                "parentpageid": 0,
                "type": "template",
                "ordernumber": 1,
                "updateddatetime": "2024-02-29T10:53:16.371Z",
                "updatedby": "SaravanaPrasath",
                "status": null,
                "savedraft": false,
                "homeleftimage": null,
                "homerightimage": null,
                "recomendationtitle": null,
                "recomendationsubtitle": null,
                "createdAt": "2024-03-26T15:33:39.250Z",
                "updatedAt": "2024-03-26T15:33:39.250Z"
            },
            "banners": [
                {
                    "bannerid": 8,
                    "bannername": "Analytic / Access Request Submission",
                    "bannerimage": "https://dch-global-audit-and-assurance-dev.s3.amazonaws.com/images/page_banners/di_a_structure.png?AWSAccessKeyId=AKIAWS4MG4CJY7JHGL63&Expires=1711649063&Signature=5G6qtxT14qKMJ69SEiikLQl5FWw%3D",
                    "bannerlink": "Analytic / Access Request Submission.com",
                    "bannerdescription": "The DI&A team is dedicated to providing Analytics, Automation, Artificial Intelligence and System Support for GA&A.  The Intake process is a streamline way to request support from the DI&A team.",
                    "status": null,
                    "updateddate": "2024-03-05T13:36:45.000Z",
                    "pageid": 3,
                    "updatedby": "22222",
                    "createdAt": "2024-03-26T15:33:39.487Z",
                    "updatedAt": "2024-03-26T15:33:39.487Z"
                }
            ],
            "sections": [
                {
                    "id": 4,
                    "title": "Application Support",
                    "description": "Centrally manage and account for all audit applications to ensure strong data governance, app support, and cost effectiveness",
                    "uploadlogo": null,
                    "content": "sections",
                    "updateddatetime": "2024-03-05T13:36:45.000Z",
                    "savedraft": null,
                    "pageid": 3,
                    "createdAt": "2024-03-26T15:33:39.750Z",
                    "updatedAt": "2024-03-26T15:33:39.750Z",
                    "subSections": [
                        {
                            "id": 10,
                            "title": "Technology Assets/ Software",
                            "description": "TeamMate+, i-Sight",
                            "uploadlogo": "logo1",
                            "updateddatetime": "2024-03-05T13:36:45.000Z",
                            "savedraft": null,
                            "sectionid": 4,
                            "createdAt": "2024-03-26T15:33:39.786Z",
                            "updatedAt": "2024-03-26T15:33:39.786Z"
                        },
                        {
                            "id": 11,
                            "title": "Capabilities",
                            "description": "Management of audit and investigation tools",
                            "uploadlogo": "logo1",
                            "updateddatetime": "2024-03-05T13:36:45.000Z",
                            "savedraft": null,
                            "sectionid": 4,
                            "createdAt": "2024-03-26T15:33:39.816Z",
                            "updatedAt": "2024-03-26T15:33:39.816Z"
                        },
                        {
                            "id": 12,
                            "title": "Matured Areas",
                            "description": "Management and reporting for audit and investigation tools",
                            "uploadlogo": "logo1",
                            "updateddatetime": "2024-03-05T13:36:45.000Z",
                            "savedraft": null,
                            "sectionid": 4,
                            "createdAt": "2024-03-26T15:33:39.845Z",
                            "updatedAt": "2024-03-26T15:33:39.845Z"
                        },
                        {
                            "id": 13,
                            "title": "Growth Areas",
                            "description": "Risk Assessment",
                            "uploadlogo": "logo1",
                            "updateddatetime": "2024-03-05T13:36:45.000Z",
                            "savedraft": null,
                            "sectionid": 4,
                            "createdAt": "2024-03-26T15:33:39.874Z",
                            "updatedAt": "2024-03-26T15:33:39.874Z"
                        },
                        {
                            "id": 14,
                            "title": "Technology Solutions",
                            "description": "TM+ Production, TM+ QAI, TM+ QA, i-Sight Prod, i-SightQA ",
                            "uploadlogo": "logo1",
                            "updateddatetime": "2024-03-05T13:36:45.000Z",
                            "savedraft": null,
                            "sectionid": 4,
                            "createdAt": "2024-03-26T15:33:39.903Z",
                            "updatedAt": "2024-03-26T15:33:39.903Z"
                        }
                    ]
                },
                {
                    "id": 5,
                    "title": "User Access Management",
                    "description": "Centrally manage and account for all audit applications to ensure strong data governance, app support, and cost effectiveness.",
                    "uploadlogo": "logo2",
                    "content": null,
                    "updateddatetime": "2024-03-05T13:36:45.000Z",
                    "savedraft": null,
                    "pageid": 3,
                    "createdAt": "2024-03-26T15:33:39.937Z",
                    "updatedAt": "2024-03-26T15:33:39.937Z",
                    "subSections": [
                        {
                            "id": 15,
                            "title": "Technology Assets/ Software",
                            "description": "Power Automate, Power Apps, SharePoint",
                            "uploadlogo": "logo1",
                            "updateddatetime": "2024-03-05T13:36:45.000Z",
                            "savedraft": null,
                            "sectionid": 5,
                            "createdAt": "2024-03-26T15:33:39.972Z",
                            "updatedAt": "2024-03-26T15:33:39.972Z"
                        },
                        {
                            "id": 16,
                            "title": "Capabilities",
                            "description": "Automation of user access processs",
                            "uploadlogo": "logo1",
                            "updateddatetime": "2024-03-05T13:36:45.000Z",
                            "savedraft": null,
                            "sectionid": 5,
                            "createdAt": "2024-03-26T15:33:40.007Z",
                            "updatedAt": "2024-03-26T15:33:40.007Z"
                        },
                        {
                            "id": 17,
                            "title": "Matured Areas",
                            "description": "Mgt of forms for user access management",
                            "uploadlogo": "logo1",
                            "updateddatetime": "2024-03-05T13:36:45.000Z",
                            "savedraft": null,
                            "sectionid": 5,
                            "createdAt": "2024-03-26T15:33:40.037Z",
                            "updatedAt": "2024-03-26T15:33:40.037Z"
                        },
                        {
                            "id": 18,
                            "title": "Growth Areas",
                            "description": "Integration with TeamMate & i-Sight",
                            "uploadlogo": "logo1",
                            "updateddatetime": "2024-03-05T13:36:45.000Z",
                            "savedraft": null,
                            "sectionid": 5,
                            "createdAt": "2024-03-26T15:33:40.066Z",
                            "updatedAt": "2024-03-26T15:33:40.066Z"
                        },
                        {
                            "id": 19,
                            "title": "Technology Solutions",
                            "description": "TeamMate user access form GAA Analytical tools user access",
                            "uploadlogo": "logo1",
                            "updateddatetime": "2024-03-05T13:36:45.000Z",
                            "savedraft": null,
                            "sectionid": 5,
                            "createdAt": "2024-03-26T15:33:40.096Z",
                            "updatedAt": "2024-03-26T15:33:40.096Z"
                        }
                    ]
                }
            ],
            "contacts": [
                {
                    "id": 1,
                    "name": "Craig, Cameron (JJCUS)",
                    "designation": "SENIOR ANALYST GLOBAL AUDIT & ASSURANCE",
                    "department": "OSO",
                    "profileimagepath": "https://dch-global-audit-and-assurance-dev.s3.amazonaws.com/images/analytic_images/user_icon.png?AWSAccessKeyId=AKIAWS4MG4CJY7JHGL63&Expires=1711650419&Signature=FN3vo8TToDXcSE%2BrLNv2m6LLNMg%3D",
                    "groupname": "test",
                    "updateddatetime": "2024-03-05T13:36:45.000Z",
                    "savedraft": null,
                    "pageid": 3,
                    "createdAt": "2024-03-26T15:33:39.516Z",
                    "updatedAt": "2024-03-26T15:33:39.516Z"
                },
                {
                    "id": 2,
                    "name": "kimbler-muehl, deana (JJCUS)",
                    "designation": "LEAD ANALYST GLOBAL AUDIT & ASSURANCE",
                    "department": "SOX PMO",
                    "profileimagepath": "https://dch-global-audit-and-assurance-dev.s3.amazonaws.com/images/analytic_images/user_icon.png?AWSAccessKeyId=AKIAWS4MG4CJY7JHGL63&Expires=1711650419&Signature=FN3vo8TToDXcSE%2BrLNv2m6LLNMg%3D",
                    "groupname": "test",
                    "updateddatetime": "2024-03-05T13:36:45.000Z",
                    "savedraft": null,
                    "pageid": 3,
                    "createdAt": "2024-03-26T15:33:39.544Z",
                    "updatedAt": "2024-03-26T15:33:39.544Z"
                },
                {
                    "id": 3,
                    "name": "mashami, Paul (JJCUS)",
                    "designation": "LEAD DIGITAL ANALYST",
                    "department": "Digital",
                    "profileimagepath": "https://dch-global-audit-and-assurance-dev.s3.amazonaws.com/images/analytic_images/user_icon.png?AWSAccessKeyId=AKIAWS4MG4CJY7JHGL63&Expires=1711650419&Signature=FN3vo8TToDXcSE%2BrLNv2m6LLNMg%3D",
                    "groupname": "test",
                    "updateddatetime": "2024-03-05T13:36:45.000Z",
                    "savedraft": null,
                    "pageid": 3,
                    "createdAt": "2024-03-26T15:33:39.573Z",
                    "updatedAt": "2024-03-26T15:33:39.573Z"
                },
                {
                    "id": 4,
                    "name": "kimbler-muehl, deana (JJCUS)",
                    "designation": "LEAD ANALYST GLOBAL AUDIT & ASSURANCE",
                    "department": "Digital",
                    "profileimagepath": "https://dch-global-audit-and-assurance-dev.s3.amazonaws.com/images/analytic_images/user_icon.png?AWSAccessKeyId=AKIAWS4MG4CJY7JHGL63&Expires=1711650419&Signature=FN3vo8TToDXcSE%2BrLNv2m6LLNMg%3D",
                    "groupname": "test",
                    "updateddatetime": "2024-03-05T13:36:45.000Z",
                    "savedraft": null,
                    "pageid": 3,
                    "createdAt": "2024-03-26T15:33:39.602Z",
                    "updatedAt": "2024-03-26T15:33:39.602Z"
                },
                {
                    "id": 5,
                    "name": "Madimasetty, Sohan (JJCUS)",
                    "designation": "SENIOR ANALYST GLOBAL AUDIT & ASSURANCE",
                    "department": "Finance",
                    "profileimagepath": "https://dch-global-audit-and-assurance-dev.s3.amazonaws.com/images/analytic_images/user_icon.png?AWSAccessKeyId=AKIAWS4MG4CJY7JHGL63&Expires=1711650419&Signature=FN3vo8TToDXcSE%2BrLNv2m6LLNMg%3D",
                    "groupname": "test",
                    "updateddatetime": "2024-03-05T13:36:45.000Z",
                    "savedraft": null,
                    "pageid": 3,
                    "createdAt": "2024-03-26T15:33:39.630Z",
                    "updatedAt": "2024-03-26T15:33:39.630Z"
                },
                {
                    "id": 6,
                    "name": "Gu, Wen (JANUS)",
                    "designation": "Digital Investigation Lead",
                    "department": "Legal",
                    "profileimagepath": "https://dch-global-audit-and-assurance-dev.s3.amazonaws.com/images/analytic_images/user_icon.png?AWSAccessKeyId=AKIAWS4MG4CJY7JHGL63&Expires=1711650419&Signature=FN3vo8TToDXcSE%2BrLNv2m6LLNMg%3D",
                    "groupname": "test",
                    "updateddatetime": "2024-03-05T13:36:45.000Z",
                    "savedraft": null,
                    "pageid": 3,
                    "createdAt": "2024-03-26T15:33:39.658Z",
                    "updatedAt": "2024-03-26T15:33:39.658Z"
                },
                {
                    "id": 7,
                    "name": "Lukose, Lavania (JJCUS NON-J&J)",
                    "designation": "",
                    "department": "IT",
                    "profileimagepath": "https://dch-global-audit-and-assurance-dev.s3.amazonaws.com/images/analytic_images/user_icon.png?AWSAccessKeyId=AKIAWS4MG4CJY7JHGL63&Expires=1711650419&Signature=FN3vo8TToDXcSE%2BrLNv2m6LLNMg%3D",
                    "groupname": "test",
                    "updateddatetime": "2024-03-05T13:36:45.000Z",
                    "savedraft": null,
                    "pageid": 3,
                    "createdAt": "2024-03-26T15:33:39.689Z",
                    "updatedAt": "2024-03-26T15:33:39.689Z"
                },
                {
                    "id": 8,
                    "name": "O'Dennis, Karen (JJCUS)",
                    "designation": "LEAD ANALYST GLOBAL AUDIT & ASSURANCE",
                    "department": "CA&I",
                    "profileimagepath": "https://dch-global-audit-and-assurance-dev.s3.amazonaws.com/images/analytic_images/user_icon.png?AWSAccessKeyId=AKIAWS4MG4CJY7JHGL63&Expires=1711650419&Signature=FN3vo8TToDXcSE%2BrLNv2m6LLNMg%3D",
                    "groupname": "test",
                    "updateddatetime": "2024-03-05T13:36:45.000Z",
                    "savedraft": null,
                    "pageid": 3,
                    "createdAt": "2024-03-26T15:33:39.716Z",
                    "updatedAt": "2024-03-26T15:33:39.716Z"
                }
            ]
        },
        "message": "Analytics Request was fetched successfully!"
    
};