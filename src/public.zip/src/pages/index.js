import { useState } from "react";
import { Link } from "react-router-dom";
import CustomModal from "./../components/ui/CustomModal";
import useFetch from "../hooks/useFetch"; // Import the useFetch hook
import { COCKPIT_BASE_URL } from "../utils/helper";
// import { dataObj } from './data';



const Pages = () => {
  const [systemsDropDownActive, setSystemsDropDownActive] = useState(false);
  const [solutionPortfolioDropDownActive, setSolutionPortfolioDropDownActive] = useState(false);
  const [editAddModalActive, setEditAddModalActive] = useState(false);
  const [activeDropDown, setActiveDropDown] = useState({
    levelOne: '',
    levelTwo: '',
    levelThree: '',
    levelFour: '',
  });
  const [modalData, setModalData] = useState();

  const [activeModalType, setActiveModalType] = useState('Add');

  const { error, data, reFetch } = useFetch(`${COCKPIT_BASE_URL}/navigation?type=cms`); // Fetch navigation data

  const [pageLevel, setPageLevel] = useState('');

  const pages = Array.isArray(data) ? data : [];

  const handleSolutionsPortfolioExpand = (id) => {
    solutionPortfolioDropDownActive ? setActiveDropDown([]) : setActiveDropDown(id)
    setSolutionPortfolioDropDownActive(!solutionPortfolioDropDownActive);
    setSystemsDropDownActive(!systemsDropDownActive);
  }

  const handleActiveDropDowns = (id, type) => {

    if (activeDropDown[type] == id) {
      const temp = { ...activeDropDown }
      temp[type] = null;
      setActiveDropDown(temp)
      return;
    }
    if ('levelOne' === type) {
      const temp = { ...activeDropDown }
      temp['levelOne'] = id;
      setActiveDropDown(temp)
    } else if ('levelTwo' === type) {
      const temp = { ...activeDropDown }
      temp['levelTwo'] = id;
      setActiveDropDown(temp)
    } else if ('levelThree' === type) {
      const temp = { ...activeDropDown }
      temp['levelThree'] = id;
      setActiveDropDown(temp)
    } else if ('levelFour' === type) {
      const temp = { ...activeDropDown }
      temp['levelFour'] = id;
      setActiveDropDown(temp)
    }
    // systemsDropDownActive ? setActiveDropDown([]) : setActiveDropDown(id)
    // setSystemsDropDownActive(!systemsDropDownActive);
    // setSolutionPortfolioDropDownActive(!solutionPortfolioDropDownActive);

  }

  const customModalTrigger = (type, data, pageLevelRecived) => {

    setPageLevel(pageLevelRecived);
    setModalData(data);
    setActiveModalType(type);
    setEditAddModalActive(!editAddModalActive);
  }
  const closeModal = () => {
    reFetch();
    setEditAddModalActive(!editAddModalActive);
  }

  const root = 'digital-innovation-analytics';


  return (
    <>
      {editAddModalActive && <CustomModal dataProp={modalData} onClose={closeModal} isOpen={editAddModalActive} type={activeModalType} pageLevel={pageLevel} />}
      <section className="center-section miniNav">

        <div className="appArea">
          <div className="contentWrap">
            <div className="sectionHead">
              <div className="row align-items-center">
                <div className="col-6">
                  <h1 className="pageTitle">All Pages</h1>
                </div>
                <div className="col-6 text-end"></div>
              </div>
            </div>
            <div className="sectionbody">
              <div className="listHead">
                <div className="listItem">
                  <div className="listItem-drag"></div>
                  <div className="listItem-title">Page Name</div>
                  <div className="listItem-content">URL/Link</div>
                  <div className="listItem-status">Status</div>
                  <div className="listItem-action">Action</div>
                </div>
              </div>
              <ul className="listWrap">
                {data?.data?.map((page, index) => (
                  <li key={page.pageid}>
                    <div className="listRow">
                      {page.children.length > 0 ?
                        <>
                          <div className={page.pageid == activeDropDown.levelOne ? 'listItem active' : 'listItem'}>
                            <div className="listItem-drag">
                              <span onClick={() => handleActiveDropDowns(page.pageid, 'levelOne')} className="haveSubLink" title="Expand/Collapse">
                                <b className="icon-chevron-down"></b>
                              </span>
                              {/* <b className="icon-more-vertical"></b> */}
                            </div>
                            <div className="listItem-title">
                              {/* <Link to={page.slug}>
                               <span className="iconMark">
                                 <b className="icon-file"></b>
                               </span>
                               {page.pagename}
                     </Link> */}

                              {page.pagename === "Systems" || page.pagename === "Solution Portfolio" ? (
                                <a href={`${root}/${page.slug}/${page.children[0].slug}`}><span className="iconMark"><b
                                  className="icon-file"></b></span>{page.pagename}</a>
                              ) : (
                                <a href={`/${page.slug}`}><span className="iconMark"><b
                                  className="icon-file"></b></span>{page.pagename}</a>
                              )}

                            </div>
                            <div className="listItem-content">
                              <span className="urlText">
                                <b className="icon-link" title="Open in same tab"></b>
                                {"/" + page.slug}
                              </span>
                            </div>
                            <div className="listItem-status">
                              {
                                page?.status ? (
                                  <span className="text-uppercase badge badge-success">Active </span>
                                )
                                  : (
                                    <span className="text-uppercase badge badge-disable">InActive </span>
                                  )
                              }
                            </div>
                            <div className="listItem-action">
                              <div className="actionBox">
                                {/* <a
                               data-bs-toggle="popover"
                               data-bs-html="true"
                               data-bs-trigger="hover"
                               title="More Info."
                               data-bs-content="<div className='tipContent'><ul><li><small>Created By & Date</small><p>alexander@jnj.com | 12/01/2024 18:00Hrs<li><small>Last Modified By & Date</small><p>nelson@jnj.com | 12/01/2024 18:00Hrs</li></ul></div>"
                             >
                               <b className="icon-info"></b>
                             </a> */}
                                <a title="Edit page info." onClick={() => customModalTrigger('Edit', page, 'l1')}>
                                  <b className="icon-edit-3"></b>
                                </a>
                                {page.children.length > 0 && <a title="Add a new page" onClick={() => customModalTrigger('Add', page, 'l1')}>
                                  <b className="icon-plus"></b>
                                </a>}
                              </div>
                            </div>
                          </div>

                          <ul style={{ display: page.pageid == activeDropDown.levelOne ? "block" : "none" }}>
                            {
                              page?.children && (page.children.map((item, count) => (

                                <li key={item.pageid} >
                                  <div className="listRow">
                                    <div className={item.pageid == activeDropDown.levelOne ? 'listItem active' : 'listItem'}>
                                      <div className="listItem-drag">
                                        {item.children.length > 0 &&
                                          <span className="haveSubLink" title="Expand/Collapse" onClick={() => handleActiveDropDowns(item.pageid, 'levelTwo')}>
                                            <b className="icon-chevron-down"></b>
                                          </span>}
                                        {/* <b className="icon-more-vertical"></b> */}
                                      </div>
                                      <div className="listItem-title">
                                        <a href={`/${root}/${page.slug}/${item.slug}`}><span className="iconMark"><b
                                          className="icon-file"></b></span>{item.pagename}</a>
                                      </div>
                                      <div className="listItem-content"><span className="urlText"><b className="icon-link"
                                        title="Open in same tab"></b>/{`${page.slug}/${item.slug}`}</span></div>
                                      <div className="listItem-status">
                                        {
                                          item?.status ? (
                                            <span className="text-uppercase badge badge-success">Active </span>
                                          )
                                            : (
                                              <span className="text-uppercase badge badge-disable">InActive </span>
                                            )


                                        }
                                      </div>
                                      <div className="listItem-action">
                                        <div className="actionBox">
                                          {/* <a data-bs-toggle="popover" data-bs-html="true" data-bs-trigger="hover" title="More Info."
                                         data-bs-content="<div className='tipContent'><ul><li><small>Created By & Date</small><p>alexander@jnj.com | 12/01/2024 18:00Hrs<li><small>Last Modified By & Date</small><p>nelson@jnj.com | 12/01/2024 18:00Hrs</li></ul></div>
                             "><b className="icon-info"></b></a> */}
                                          <a title="Edit" onClick={() => customModalTrigger('Edit', item, 'l2')}><b className="icon-edit-3" data-bs-toggle="modal"
                                            data-bs-target="#editModal"></b></a>
                                          {/*<a title="Add New Page"><b className="icon-plus" data-bs-toggle="modal" data-bs-target="#addModal"></b></a>*/}
                                          {item.children.length > 0 && <a title="Add" onClick={() => customModalTrigger('Add', item, 'l2')}>
                                            <b className="icon-plus"></b>
                                          </a>}

                                        </div>
                                      </div>
                                    </div>
                                    <ul style={{ display: item.pageid == activeDropDown.levelTwo ? "block" : "none" }}>
                                      {
                                        item?.children && (item.children.map((value, count) => (
                                          <li key={value.pageid} >
                                            <div className="listRow">
                                              <div className={value.pageid == activeDropDown.levelTwo ? 'listItem active' : 'listItem'}>
                                                <div className="listItem-drag">
                                                  {value?.children?.length > 0 &&
                                                    <span className="haveSubLink" title="Expand/Collapse" onClick={() => handleActiveDropDowns(value.pageid, 'levelThree')}>
                                                      <b className="icon-chevron-down"></b>
                                                    </span>}
                                                  {/* <b className="icon-more-vertical"></b> */}
                                                </div>
                                                <div className="listItem-title">
                                                  <a href={`/${root}/${page.slug}/${item.slug}/${value.slug}`}><span className="iconMark"><b
                                                    className="icon-file"></b></span>{value.pagename}</a>
                                                </div>
                                                <div className="listItem-content"><span className="urlText"><b className="icon-link"
                                                  title="Open in same tab"></b>/{value.slug}</span></div>
                                                <div className="listItem-status">
                                                  {
                                                    value?.status ? (
                                                      <span className="text-uppercase badge badge-success">Active </span>
                                                    )
                                                      : (
                                                        <span className="text-uppercase badge badge-disable">InActive </span>
                                                      )


                                                  }
                                                </div>
                                                <div className="listItem-action">
                                                  <div className="actionBox">
                                                    {/* <a data-bs-toggle="popover" data-bs-html="true" data-bs-trigger="hover" title="More Info."
                                                   data-bs-content="<div className='tipContent'><ul><li><small>Created By & Date</small><p>alexander@jnj.com | 12/01/2024 18:00Hrs<li><small>Last Modified By & Date</small><p>nelson@jnj.com | 12/01/2024 18:00Hrs</li></ul></div>
                                       "><b className="icon-info"></b></a> */}
                                                    <a title="Edit" onClick={() => customModalTrigger('Edit', value, 'l3')}><b className="icon-edit-3" data-bs-toggle="modal"
                                                      data-bs-target="#editModal"></b></a>
                                                    {/*<a title="Add New Page"><b className="icon-plus" data-bs-toggle="modal" data-bs-target="#addModal"></b></a>*/}
                                                    {value?.children?.length > 0 && <a title="Add" onClick={() => customModalTrigger('Add', value, 'l3')}>
                                                      <b className="icon-plus"></b>
                                                    </a>}

                                                  </div>
                                                </div>
                                              </div>
                                              {
                                                value?.children && (value.children.map((levelFourElement, count) => (
                                                  <ul key={levelFourElement.pageid} style={{ display: value.pageid == activeDropDown.levelThree ? "block" : "none" }}>
                                                    <li>
                                                      <div className="listRow">
                                                        <div className={value.pageid == activeDropDown.levelThree ? 'listItem active' : 'listItem'}>
                                                          <div className="listItem-drag">
                                                            {levelFourElement?.children?.length > 0 &&
                                                              <span className="haveSubLink" title="Expand/Collapse" onClick={() => handleActiveDropDowns(levelFourElement.pageid, 'levelFour')}>
                                                                <b className="icon-chevron-down"></b>
                                                              </span>}
                                                            {/* <b className="icon-more-vertical"></b> */}
                                                          </div>
                                                          <div className="listItem-title">
                                                            <a href={`/${root}/${page.slug}/${item.slug}/${value.slug}/${levelFourElement.slug}`}><span className="iconMark"><b
                                                              className="icon-file"></b></span>{levelFourElement.pagename}</a>
                                                          </div>
                                                          <div className="listItem-content"><span className="urlText"><b className="icon-link"
                                                            title="Open in same tab"></b>/{levelFourElement.slug}</span></div>
                                                          <div className="listItem-status">
                                                            {
                                                              levelFourElement?.status ? (
                                                                <span className="text-uppercase badge badge-success">Active </span>
                                                              )
                                                                : (
                                                                  <span className="text-uppercase badge badge-disable">InActive </span>
                                                                )


                                                            }
                                                          </div>
                                                          <div className="listItem-action">
                                                            <div className="actionBox">
                                                              {/* <a data-bs-toggle="popover" data-bs-html="true" data-bs-trigger="hover" title="More Info."
                                                             data-bs-content="<div className='tipContent'><ul><li><small>Created By & Date</small><p>alexander@jnj.com | 12/01/2024 18:00Hrs<li><small>Last Modified By & Date</small><p>nelson@jnj.com | 12/01/2024 18:00Hrs</li></ul></div>
                                                 "><b className="icon-info"></b></a> */}
                                                              <a title="Edit" onClick={() => customModalTrigger('Edit', levelFourElement, 'l4')}><b className="icon-edit-3" data-bs-toggle="modal"
                                                                data-bs-target="#editModal"></b></a>



                                                            </div>
                                                          </div>
                                                        </div>
                                                        {
                                                          levelFourElement?.children && (levelFourElement.children.map((levelFourSubElement, count) => (
                                                            <ul key={levelFourSubElement.pageid} style={{ display: levelFourSubElement.pageid == activeDropDown.levelFour ? "block" : "none" }}>
                                                              <li>
                                                                <div className="listRow">
                                                                  <div className={levelFourElement.pageid == activeDropDown.levelFour ? 'listItem active' : 'listItem'}>
                                                                    <div className="listItem-drag">
                                                                      {levelFourSubElement?.children?.length > 0 &&
                                                                        <span className="haveSubLink" title="Expand/Collapse" onClick={() => handleActiveDropDowns(levelFourElement.pageid, 'levelFour')}>
                                                                          <b className="icon-chevron-down"></b>
                                                                        </span>}
                                                                      {/* <b className="icon-more-vertical"></b> */}
                                                                    </div>
                                                                    <div className="listItem-title">
                                                                      <a href={`/${root}/${page.slug}/${item.slug}/${value.slug}/${levelFourElement.slug}/${levelFourSubElement.slug}`}><span className="iconMark"><b
                                                                        className="icon-file"></b></span>{levelFourElement.pagename}</a>
                                                                    </div>
                                                                    <div className="listItem-content"><span className="urlText"><b className="icon-link"
                                                                      title="Open in same tab"></b>/{levelFourSubElement.slug}</span></div>
                                                                    <div className="listItem-status">
                                                                      {
                                                                        levelFourSubElement?.status ? (
                                                                          <span className="text-uppercase badge badge-success">Active </span>
                                                                        )
                                                                          : (
                                                                            <span className="text-uppercase badge badge-disable">InActive</span>
                                                                          )


                                                                      }
                                                                    </div>
                                                                    <div className="listItem-action">
                                                                      <div className="actionBox">
                                                                        {/* <a data-bs-toggle="popover" data-bs-html="true" data-bs-trigger="hover" title="More Info."
                                                                       data-bs-content="<div className='tipContent'><ul><li><small>Created By & Date</small><p>alexander@jnj.com | 12/01/2024 18:00Hrs<li><small>Last Modified By & Date</small><p>nelson@jnj.com | 12/01/2024 18:00Hrs</li></ul></div>
                                                           "><b className="icon-info"></b></a> */}
                                                                        <a title="Edit"><b className="icon-edit-3" data-bs-toggle="modal"
                                                                          data-bs-target="#editModal"></b></a>
                                                                        <a title="Add New Page"><b className="icon-plus" data-bs-toggle="modal" data-bs-target="#addModal"></b></a>


                                                                      </div>
                                                                    </div>
                                                                  </div>

                                                                </div>
                                                              </li>
                                                            </ul>
                                                          )))
                                                        }
                                                      </div>
                                                    </li>
                                                  </ul>
                                                )))
                                              }
                                            </div>
                                          </li>

                                        )))
                                      }
                                    </ul>
                                  </div>
                                </li>

                              )))
                            }  </ul>
                        </>
                        :
                        <div className="listItem">
                          <div className="listItem-drag">
                            {/* <b className="icon-more-vertical"></b> */}
                          </div>
                          <div className="listItem-title">
                            <Link to={page.slug}>
                              <span className="iconMark">
                                <b className="icon-file"></b>
                              </span>
                              {page.pagename}
                            </Link>
                          </div>
                          <div className="listItem-content">
                            <span className="urlText">
                              <b className="icon-link" title="Open in same tab"></b>
                              {"/" + page.slug}
                            </span>
                          </div>
                          <div className="listItem-status">
                            {page?.status ? <span className="text-uppercase badge badge-success">
                              {`Active `}
                            </span>
                              :
                              <span className="text-uppercase badge badge-failure">
                                {`Inactive `}
                              </span>
                            }
                          </div>
                          <div className="listItem-action">
                            <div className="actionBox">
                              {/* <a
                             data-bs-toggle="popover"
                             data-bs-html="true"
                             data-bs-trigger="hover"
                             title="More Info."
                             data-bs-content="<div className='tipContent'><ul><li><small>Created By & Date</small><p>alexander@jnj.com | 12/01/2024 18:00Hrs<li><small>Last Modified By & Date</small><p>nelson@jnj.com | 12/01/2024 18:00Hrs</li></ul></div>
                       "
                           >
                             <b className="icon-info"></b>
                           </a>{" "} */}
                              <a onClick={() => customModalTrigger('Edit', page, 'l1')} title="Edit">
                                <b className="icon-edit-3"></b>
                              </a>
                            </div>
                          </div>
                        </div>
                      }
                    </div>
                  </li>
                ))}

              </ul>
            </div>
          </div>
        </div>
      </section>
    </>

  );
};

export default Pages;
