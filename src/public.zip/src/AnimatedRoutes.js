import React from "react";
import Pages from "./pages";
import CmsMain from "./pages/Home";
import CmsTemplate from "./Route/cmsTemplate";
// import Home_ from "./pages/cms_main";
// import { AnimatePresence } from "framer-motion";
import { Routes, Route, useLocation, Switch, useRoutes } from "react-router-dom";
import Home from "./pages/cms_main";
import Home_edit from "./pages/cms_main/home_edit";
import DiaStructure from "./pages/DiaStructure";
//import DiaTeam from "./pages/DiaTeam";
import AvailableResource from "./pages/availableResources";
import System from "./pages/Systems";

import Solutions_portfolio_ from "./pages/Solutions_portfolio";
import AnalyticsRequest from "./pages/AnalyticsRequest";
import SolutionPortfoliol4 from "./pages/Solutions_portfolio/l4";
// import MissionContent from "./pages/MissionContent/MissionContent";
import Solutions_portfolio_edit from "./pages/Solutions_portfolio/solutions_portfolio_edit";
import Systems_edit from "./pages/Systems/systems_edit";
import Dia_structure_edit from "./pages/DiaStructure/dia_structure_edit";

import Available_datasource_edit from "./pages/availableResources/available_datasource_edit";
import Analytics_request_edit from "./pages/AnalyticsRequest/analytic_request_edit"
function AnimatedRoutes() {
  const location = useLocation();

  const element = useRoutes([
    {
      path: "/dia_structure_edit",
      element: <Dia_structure_edit />
    },
    { path: "/available_data_source_edit", element: <Available_datasource_edit /> },
    { path: "", element: <CmsTemplate /> },
    { path: "/cms_main", element: <CmsMain /> },
    { path: "/cms_pages", element: <Pages /> },
    { path: "/systems_edit", element: <Systems_edit /> },
    // {path:"Home_edit", element:<Home_edit/>},
    {
      path: "/solutions-portfolio_edit",
      element: <Solutions_portfolio_edit />,
    },
    {
      path: "/analytic_request_edit",
      element: <Analytics_request_edit />
    },


    { path: "/digital-innovation-analytics/homepage", element: <Home /> },
    {
      path: "/digital-innovation-analytics/:slug",
      element: <Solutions_portfolio_ />,
    },
    {
      path: "/digital-innovation-analytics/:slug/:slug",
      element: <SolutionPortfoliol4 />,
      children: [
        { path: ":slug", element: <SolutionPortfoliol4 /> }
      ],
    },
    // {path:"/solution-portfolio", element:<SolutionPortfolio/>}
    { path: "/dia-structure", element: <DiaStructure /> },
    { path: "/available_data_source", element: <AvailableResource /> },
    { path: "/systems", element: <System /> },
    { path: "/analytic_request", element: <AnalyticsRequest /> },
    // { path: "/know-more", element: <MissionContent />},
    { path: "*", element: <Home /> }
  ]);
  return element;
  // return (
  //   <AnimatePresence initial={false}>
  //     <Routes location={location} key={location.pathname}>
  //       <Route path="/" element={<Home />} />
  //       <Route path="/digital-innovation-analytics/dia-structure" element={<DiaStructure />} />
  //       <Route path="/digital-innovation-analytics/available-data-sources" element={<AvailableResource />} />
  //       <Route path="/digital-innovation-analytics/systems/:slug" element={<System />} />
  //       <Route path="/digital-innovation-analytics/:slug" element={<SolutionPortfolio />} />
  //       <Route path="/digital-innovation-analytics/solutions-portfolio/l4/:id" element={<SolutionPortfoliol4 />} />
  //       <Route path="/digital-innovation-analytics/analytics-request" element={<AnalyticsRequest />} />
  //       <Route path="*" element={<Home />} />
  //     </Routes>
  //   </AnimatePresence>
  // );
}

export default AnimatedRoutes;