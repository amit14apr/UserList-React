import Header from "./components/Header";
import { Routes, Route } from "react-router-dom";
import CmsMain from "./pages/Home";
import Pages from "./pages";
import Home_ from "./pages/cms_main/index";
import CmsTemplate from "./Route/cmsTemplate";
import HomeDark from "./pages/cms_main/homeDark";
import Home_edit from "./pages/cms_main/home_edit";
import Dia_structure_ from "./pages/DiaStructure";
import DiaStructureDark from "./pages/DiaStructure/diaStructureDark";
import Dia_structure_edit from "./pages/DiaStructure/dia_structure_edit";
import Available_data_source from "./pages/AvailableResources";
import AvailableDataSourcesDark from "./pages/AvailableResources/availableDataSourcesDark";
import Available_datasource_edit from "./pages/AvailableResources/available_datasource_edit";
import Systems_ from "./pages/Systems";
import SystemsDark from "./pages/Systems/systemsDark";
import Systems_edit from "./pages/Systems/systems_edit";
import Solutions_portfolio_ from "./pages/Solutions_portfolio";
import SolutionsPortfolioDark from "./pages/Solutions_portfolio/solutionPortfolioDark";
import SAPCreditMemos from "./pages/Solutions_portfolio/sapCreditMemos";
import Solutions_portfolio_edit from "./pages/Solutions_portfolio/solutions_portfolio_edit";
import AnalyticsRequest_ from "./pages/AnalyticsRequest";
import AnalyticsRequestDark from "./pages/AnalyticsRequest/analyticsRequestDark";
import Analytics_request_edit from "./pages/AnalyticsRequest/analytic_request_edit";
import SolutionPortfolio from "./pages/Solutions_portfolio";
import SolutionPortfolioEdit from "./pages/Solutions_portfolio/solutions_portfolio_edit";
import AppNav from "./components/cms/AppNav";
import { AuthenticatedTemplate, MsalContext, UnauthenticatedTemplate, useIsAuthenticated, useMsal, useMsalAuthentication } from "@azure/msal-react";
import { InteractionType, InteractionRequiredAuthError } from '@azure/msal-browser';
import ProtectedRoute from "./Route/ProtectedRoute";
import { useEffect, useLayoutEffect } from "react";
const App = () => {

 
  const isAuthenticated = useIsAuthenticated();
  const contextType = MsalContext;
  console.log("🚀 ~ App ~ contextType:", contextType)
  const request = {

    scopes: ["User.Read"]
  }
  const { login, result, error } = useMsalAuthentication(InteractionType.Silent, request);
  useEffect(() => {
    if (error instanceof InteractionRequiredAuthError) {
      login(InteractionType.Popup, request);
    }
  }, [error]);

  const { accounts } = useMsal();
  console.log("🚀 ~ App ~ accounts:", accounts)
  localStorage.setItem('token', JSON.stringify(accounts));
  return (
    <>
      {isAuthenticated && (
        <ProtectedRoute>
        <>
          <Header />
          <AppNav />
          <Routes>
            <Route path="/" element={<CmsTemplate />} />
            <Route path="/cms_main" element={<CmsMain />} />
            <Route path="/digital-innovation-analytics" element={<Pages />} />
            <Route path="/digital-innovation-analytics/homepage" element={<Home_ />} />
            <Route path="/digital-innovation-analytics/homepage/edit" element={<Home_edit />} />
            <Route path="/digital-innovation-analytics/dia-structure" element={<Dia_structure_ />} />
            <Route path="/digital-innovation-analytics/dia-structure/edit" element={<Dia_structure_edit />} />
            <Route path="/digital-innovation-analytics/available-data-sources" element={<Available_data_source />} />
            <Route path="/digital-innovation-analytics/available-data-sources/edit" element={<Available_datasource_edit />} />
            <Route path="/digital-innovation-analytics/systems/:slug" element={<Systems_ />} />
            <Route path="/digital-innovation-analytics/systems/:slug/edit" element={<Systems_edit />} />
            <Route path="/digital-innovation-analytics/solution-portfolio/:slug" element={<SolutionPortfolio />} />
            <Route path="/digital-innovation-analytics/solution-portfolio/:slug/:slug/" element={<SolutionPortfolio />} />
            <Route path="/digital-innovation-analytics/solution-portfolio/:slug/:slug/:slug" element={<SolutionPortfolio />} />
            <Route path="/digital-innovation-analytics/solution-portfolio/:slug/edit" element={<SolutionPortfolioEdit />} />
            <Route path="/digital-innovation-analytics/analytics-request" element={<AnalyticsRequest_ />} />
            <Route path="/digital-innovation-analytics/analytics-request/edit" element={<Analytics_request_edit />} />


            <Route path="Home_dark/" element={<HomeDark />} />


            <Route
              path="/dia_structure_dark"
              element={<DiaStructureDark />}
            />

            <Route
              path="/available_data_source"
              element={<Available_data_source />}
            />
            <Route
              path="/available_data_source_dark"
              element={<AvailableDataSourcesDark />}
            />


            <Route path="/systems_dark" element={<SystemsDark />} />

            <Route
              path="/solutions_portfolio"
              element={<Solutions_portfolio_ />}
            />
            <Route
              path="/solutions_portfolio_dark"
              element={<SolutionsPortfolioDark />}
            />
            <Route
              path="/solutions_portfolio_sapCreditMemos"
              element={<SAPCreditMemos />}
            />
            <Route
              path="/solutions_portfolio_edit"
              element={<Solutions_portfolio_edit />}
            />

            <Route
              path="/analytic_request_dark"
              element={<AnalyticsRequestDark />}
            />


          </Routes>
          </>
        </ProtectedRoute>
      )}

    </>
  );
};
export default App;

// import { useLayoutEffect } from "react";

// import Header from "./components/Header";
// import Footer from "./components/Footer";
// import AnimatedRoutes from "./AnimatedRoutes";
// // import "./components/ui/Animations/animation.scss";

// const App = () => {
// //

//   return (
//     <>
//       <Header />
//       <AnimatedRoutes />
//       <Footer />
//     </>
//   );
// };
// export default App;