import Spinner from "react-bootstrap/Spinner";

const Loader = () => {
    return (
        <div className="spinner-container">
          <Spinner
            animation="border"
            size="sm"
            style={{ width: 100, height: 100, color: "red" }}
          />
        </div>
    )
}

export default Loader;