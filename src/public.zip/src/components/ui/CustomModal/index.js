import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

import { COCKPIT_BASE_URL, updateContent } from "../../../utils/helper";
import useFetch from '../../../hooks/useFetch';

const CustomModal = ({ isOpen, type, onClose, dataProp, pageLevel }) => {
     const { error, data, reFetch } = useFetch(`${COCKPIT_BASE_URL}/page/detail/${dataProp?.slug}`);
    const [formData, setFormData] = useState({
        title: data?.data?.pagename || "",
        thumnail: data?.data?.thumnail || null, // You can set default thumnail here if needed
        description: data?.data?.description || "",
        status: data?.data?.status,
        updatedby: "ayush@hmail.com",
        type: data?.data?.type || "",
        ordernumber: data?.data?.ordernumber,
        parentpageid: data?.data?.parentpageid
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        console.log("🚀 ~ handleChange ~ value:", value)
        console.log("🚀 ~ handleChange ~ name:", name)
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    useEffect(()=>{
        setFormData(prevState => ({
            ...prevState,
            ['title']: data?.data?.pagename,
            ['parentpageid']: data?.data?.parentpageid,
            ['status']: data?.data?.status
        }));
    },[data])

    const handleThumbnailChange = (event) => {
        const file = event.target.files[0];
        const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg'];

        if (!allowedTypes.includes(file.type)) {
            alert("Only PNG, JPEG, and JPG files are allowed.");
            return;
        }

        const formData = new FormData();
        formData.append('file', file);
        formData.append("filepath", "images/banners/");

        const token = JSON.parse(localStorage.getItem('token'))[0].idToken;
        axios.post("https://dev.cockpit.jnj.com/api/pages/upload", formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
                'Authorization': token
            }
        })
        .then(response => {
            const thumbnailUrl = response.data.url;
            setFormData(prevState => ({
                ...prevState,
                thumnail: thumbnailUrl
            }));
        })
        .catch(error => {
            console.error('Error uploading image:', error);
            // Handle error if needed
        });
    }

    const handleSubmit = async (e) => {
        e.preventDefault();

        const payload = formData;
        payload.type = data?.data?.type;
        payload.ordernumber = data?.data?.ordernumber;
        payload.parentpageid = data?.data?.type === 'l1' ? data?.data?.pageid : data?.data?.pageid;
        payload['pagename'] = payload.title;

        try {
            const url = type === 'Edit' ? `https://dev.cockpit.jnj.com/api/pages/page/detail/${dataProp.slug}` : `https://dev.cockpit.jnj.com/api/pages/page/add`;
            const response = await axios[type === 'Edit' ? 'put' : 'post'](url, payload);
            onClose();
        } catch (error) {
            console.error('Error:', error);
            // Handle error if needed
        }
    };

    useEffect(() => {
        if (isOpen) {
            document.body.classList.add('modal-open');
        } else {
            document.body.classList.remove('modal-open');
        }
    }, [isOpen]);

    return (
        <Modal show={isOpen} onHide={onClose}>
            <div>

<div className={isOpen ? `modal fade show` : `modal fade`} id={type === "Add" ? "addModal" : "editModal"} style={{ display: isOpen ? "block" : "none" }} tabIndex="-1" role="dialog" aria-modal={isOpen ? `true` : null} aria-hidden={!isOpen ? `true` : null}>
    <div role="document" className="modal-dialog modal-dialog-centered modal-md">
        <div className="modal-content">
            <div className="modal-header">
                <h2 className="modal-title">{type} Page</h2>
                <button className="close btn-close" onClick={onClose} dataProp-bs-dismiss="modal" aria-label="Close" type="button"></button>
            </div>
            <form onSubmit={handleSubmit}> {/* Added form element */}
                <div className="modal-body">
                    <div className="row">
                        <div className="col-12">
                            <ul className="modalForm">
                                <li>
                                    <div className="form-group">
                                        <label className="form-label">Name</label>
                                        <div>
                                            <input type="text" name="title" value={type === "Edit" ? formData.title : null } onChange={handleChange} className="form-control" />
                                        </div>
                                        {/*<small className="form-valid error">This is required</small>*/}
                                    </div>
                                </li>
                               {data?.data?.parentpageid != 4 && (data?.data?.type == 'l2' || data?.data?.type == 'l3' || data?.data?.type == 'l4') && <li>
                                    <div className="form-group">
                                        <label className="form-label">Page Icon Image</label>
                                        <div>
                                            <input type="file" name="thumnail" onChange={handleThumbnailChange} className="form-control" />
                                        </div>
                                    </div>
                                </li> }
                                {/* // <li>
                                //     <div className="form-group">
                                //         <label className="form-label">Description</label>
                                //         <div>
                                //             <textarea name="description" value={data?.data?.description} onChange={handleChange} className="form-control"></textarea>
                                //         </div>
                                //     </div>
                                // </li> */}
                                {/* } */}
                                <li>
                                    <div className="form-group">
                                        <label className="form-label">Status</label>
                                        <div className="pt-1">
                                            <label className="d-inline-flex align-items-center customRadio active">
                                                <input type="radio" name="status" value={true} checked={type === "Edit" && formData.status == true} onChange={handleChange} />
                                                <span className="text-uppercase badge badge-success">Active</span>
                                            </label>

                                            <label className="d-inline-flex align-items-center customRadio inactive ms-3">
                                                <input type="radio" name="status" value={false} checked={type === "Edit" && formData.status == false} onChange={handleChange} />
                                                <span className="text-uppercase badge badge-failure">Inactive</span>
                                            </label>
                                        </div>
                                    </div>
                                </li>

                            </ul>
                        </div>


                    </div>
                </div>
                <div className="modal-footer justify-content-end ">
                    <button type="button" data-bs-dismiss="modal" className="btn btn-text" onClick={onClose}> Cancel </button>
                    <button type="submit" className="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
        </Modal>
    );
}

export default CustomModal;
