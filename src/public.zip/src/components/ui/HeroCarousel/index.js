import React, { useRef } from "react";
// import { loadLinksPreset } from "@tsparticles/preset-links";
import { useCallback, useEffect, useMemo, useState } from "react";
// import Particles, { initParticlesEngine } from "@tsparticles/react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/free-mode";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/thumbs";
import "swiper/css/autoplay";

import { Autoplay, FreeMode, Thumbs } from "swiper/modules";
import { elementType } from "prop-types";
import { Link, useNavigate, useParams } from "react-router-dom";
import { sort_by_id } from "../../../utils/helper";
// import BackgroundAnimation from "../Animations/BackgroundAnimation";

const HeroCarousel = ({ items = [] }) => {

  const navigate = useNavigate()
  console.log("🚀 ~ HeroCarousel ~ items:", items)
  const particlesInitCb = useCallback(async (engine) => {
    console.log("callback");

    // await loadLinksPreset(engine);
  }, []);

  const particlesLoaded = useCallback((container) => {
    console.log("loaded", container);
  }, []);

  const [init, setInit] = useState(false);

  // useEffect(() => {
  //   initParticlesEngine(particlesInitCb).then(() => {
  //     setInit(true);
  //   });
  // }, []);

  const options = useMemo(
    () => ({
      preset: "links",
      fullScreen: {
        enable: false,
        zIndex: -1,
      },
      particles: {
        number: {
          value: 20,
        },
        color: {
          value: "#ffffff",
        },
        links: {
          enable: true,
          // distance: 200,
        },
        shape: {
          type: "circle",
        },
        opacity: {
          value: 1,
        },
        size: {
          value: 3,
          random: true,
          anim: {
            enable: false,
            speed: 40,
            size_min: 0.1,
            sync: false,
          },
        },
        line_linked: {
          enable: true,
          distance: 150,
          color: "#f0c394",
          opacity: 0.4,
          width: 1,
        },
        move: {
          enable: true,
          speed: 0.5,
          direction: "none",
          random: false,
          straight: false,
          out_mode: "out",
          bounce: false,
          attract: {
            enable: false,
            rotateX: 600,
            rotateY: 1200,
          },
        },
      },
      background: {
        color: "transparent",
      },
      poisson: {
        enable: true,
      },
    }),
    []
  );
  const slideTimeout = 4800;

  const mainSwiper = useRef();
  const innerSwiper = useRef();

  const [thumbsSwiper, setThumbsSwiper] = useState(null);
  const [thumbsInnerSwiper, setThumbsInnerSwiper] = useState(null);
  return (
    <div className="slider-container">
      <div className="particleMask">
        {/*init && (
          <Particles
            options={options}
            particlesLoaded={particlesLoaded}
            className="particleItem"
          />
        )*/}
      </div>
        <div className="heroBanner">
          <Swiper
            ref={mainSwiper}
            autoplay={{
              delay: slideTimeout,
              disableOnInteraction: false,
            }}
            // thumbs={{ swiper: thumbsSwiper }}
            // modules={[Autoplay, Thumbs]}
            slidesPerView={1}
            //  onInit ={() => {
            //     mainSwiper.current?.swiper.autoplay.stop();
            //     innerSwiper.current?.swiper.autoplay.start();
            //   }}
            onReachEnd={() => {
              console.log("MAIN END");
              setTimeout(() => {
                mainSwiper?.current?.swiper.autoplay.stop();
                innerSwiper?.current?.swiper.autoplay.start();
                mainSwiper?.current?.swiper.slideTo(0);
              }, slideTimeout);
            }}
            className="mainSwiper"
          >
            <SwiperSlide>
              <Swiper
                ref={innerSwiper}
                autoplay={{
                  delay: slideTimeout,
                  disableOnInteraction: false,
                }}
                // thumbs={{ swiper: thumbsInnerSwiper }}
                // modules={[Autoplay, Thumbs]}
                slidesPerView={1}
                onReachEnd={() => {
                  console.log("INNER END");
                  setTimeout(() => {
                    innerSwiper.current.swiper.autoplay.stop();
                    innerSwiper.current.swiper.slideTo(0);
                    mainSwiper.current.swiper.autoplay.start();
                    mainSwiper.current.swiper.slideTo(1);
                  }, slideTimeout);
                }}
                className="innerSwiper"
              >
                {items
                  .sort((a, b) => a.bannerid - b.bannerid)
                  ?.slice(0, 3)
                  .map((el, i) => (
                    <SwiperSlide>
                      <div>
                        <div className="heroBanner-item">
                          <div className="contentWrap">
                            <div className="heroBanner-info">
                              <h2 data-aos="fade-up" data-aos-delay="100">
                                {el.bannername}
                              </h2>
                              <p data-aos="fade-up" data-aos-delay="200">
                                {el.bannerdescription}
                              </p>
                              <Link
                                to={el.bannerlink}
                                data-aos="fade-up"
                                data-aos-delay="300"
                              >
                                Know More <b></b>
                              </Link>
                            </div>
                          </div>
                          <div className="heroBanner-bg">
                            <img alt="#" src={el.bannerimage} />
                          </div>
                        </div>
                      </div>
                    </SwiperSlide>
                  ))}
              </Swiper>
            </SwiperSlide>
            {items
              .sort((a, b) => a.bannerid - b.bannerid)
              ?.slice(3)
              ?.map((el) => (
                <SwiperSlide>
                  <div>
                    <div className="heroBanner-item">
                      <div className="contentWrap">
                        <div className="heroBanner-info">
                          <h2 data-aos="fade-up" data-aos-delay="100">
                            {el.bannername}
                          </h2>
                          <p data-aos="fade-up" data-aos-delay="200">
                            {el.bannerdescription}
                          </p>
                          <Link
                            to={el.bannerlink}
                            data-aos="fade-up"
                            data-aos-delay="300"
                          >
                            Know More <b></b>
                          </Link>
                        </div>
                      </div>
                      <div className="heroBanner-bg">
                        <img alt="#" src={el.bannerimage} />

                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              ))}
          </Swiper>

          <Swiper
            onSwiper={setThumbsSwiper}
            // modules={[FreeMode, Thumbs]}
            freeMode={true}
            watchSlidesProgress={true}
            slidesPerView={4}
            className="mainSwiperControl"
          >
            <SwiperSlide>
              <span>
                <b>Announcements</b>
              </span>
              <Swiper
                onSwiper={setThumbsInnerSwiper}
                // modules={[FreeMode, Thumbs]}
                freeMode={true}
                watchSlidesProgress={true}
                //slidesPerView={slideInnerCount}
                className="innerSwiperControl"
              >
                <SwiperSlide>
                  <span />
                </SwiperSlide>
                <SwiperSlide>
                  <span />
                </SwiperSlide>
                <SwiperSlide>
                  <span />
                </SwiperSlide>
              </Swiper>
            </SwiperSlide>
            <SwiperSlide>
              <span>
                <b onClick={() => {navigate('/digital-innovation-analytics/newsletters/know-more')}}>Newsletters</b>
              </span>
            </SwiperSlide>
            <SwiperSlide>
              <span>
                <b onClick={() => {navigate('/digital-innovation-analytics/toolkit/know-more')}}>ToolKit</b>
              </span>
            </SwiperSlide>
            <SwiperSlide>
              <span>
              
                <b onClick={() => {navigate('/digital-innovation-analytics/mission/know-more')}}>Our Mission</b>
              
                
              </span>
            </SwiperSlide>
          </Swiper>
        </div>
    </div>
  );
};

export default HeroCarousel;
