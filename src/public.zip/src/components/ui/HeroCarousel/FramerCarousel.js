import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import "./FramerCarousel.scss"; // Import CSS for styling

const images = [
  "https://via.placeholder.com/1200x500",
  "https://via.placeholder.com/1200x500",
  "https://via.placeholder.com/1200x500",
];

const FramerCarousel = () => {
  const [currentImage, setCurrentImage] = useState(0);

  const nextSlide = () => {
    setCurrentImage(currentImage === images.length - 1 ? 0 : currentImage + 1);
  };

  const prevSlide = () => {
    setCurrentImage(currentImage === 0 ? images.length - 1 : currentImage - 1);
  };

  return (
    <div className="hero-carousel">
      <AnimatePresence initial={false}>
        <motion.img
          key={currentImage}
          src={images[currentImage]}
          alt={`Slide ${currentImage + 1}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="carousel-image"
        />
      </AnimatePresence>
      <button className="prev-button" onClick={prevSlide}>
        Previous
      </button>
      <button className="next-button" onClick={nextSlide}>
        Next
      </button>
    </div>
  );
};

export default FramerCarousel;
