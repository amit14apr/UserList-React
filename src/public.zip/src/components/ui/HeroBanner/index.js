import "./banner.css";

const HeroBanner = ({ title, subTitle, imgSrc }) => {
  return (
    <div className="innerBanner">
      <div className="innerBanner-item">
        <div className="innerBanner-info">
          <div className="contentWrap">
            <h2>{title}</h2>
            <p>{subTitle}</p>
          </div>
        </div>
        <div className="innerBanner-bg">
          <img alt="#" src={imgSrc} />
        </div>
      </div>
    </div>
  );
};
export default HeroBanner;
