import "./header.scss";
import { ThemeProvider } from "../../context/ThemeContext";
import { useLocation, useNavigate, useNavigation } from "react-router-dom";

const Header = () => {
  const location = useLocation();
  console.log("🚀 ~ Header ~ location:", location.pathname)
  var initials = '';
  var userName = JSON.parse(localStorage.getItem('token'))[0].name;
  userName.split(',').forEach(element => {
    initials = initials + element.trim()[0]
  })
  return (
    <ThemeProvider>
      <header>
        <div class="row align-items-center">
          <div class="col-6">
            <a class="navbar-brand">
              <img
                alt="#"
                src={require("../../assets/img/logo/JNJ_Logo_SingleLine_Red_RGB.png")}
              />
            </a>
          </div>
          <div class="col-6 text-end">
            <div class="d-inline-flex portalName">
              {location.pathname.includes('/digital-innovation-analytics') ? 'Digital Innovation Analytics' : 'Global Audit & Assurance (GA&A)'}

            </div>
            <div class="btn-group">
              <span
                aria-expanded="false"
                class="dropdown-toggle noIcon userWrap"
                data-bs-toggle="dropdown"
              >
                {initials}
              </span>
              <ul class="dropdown-menu dropdown-menu-end">
                <li>
                  <a class="dropdown-item">Profile</a>
                </li>
                <li>
                  <a class="dropdown-item" href="login.html">
                    Logout
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </header>
    </ThemeProvider>
  );
};
export default Header;
