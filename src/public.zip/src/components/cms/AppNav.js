import { Link } from "react-router-dom";
function AppNav() {
    return (
        <div className="appNav">
          <a className="menuToggle">
            <b className="icon-menu"></b>
          </a>
          <ul>
            <li>
              <Link to='/cms_main'>
                <i className="icon-folder"></i>
                <span>GA&A Portals</span>
              </Link>
            </li>
          </ul>
        </div>
    )
}


export default AppNav