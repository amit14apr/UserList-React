import React from 'react'
import { useMsal, useIsAuthenticated, AuthenticatedTemplate, UnauthenticatedTemplate } from '@azure/msal-react';
import { Navigate, Outlet, Route, Routes } from 'react-router-dom';

const ProtectedRoute = ({children}) => {
    const isAuthenticated = useIsAuthenticated();
    console.log("🚀 ~ ProtectedRoute ~ isAuthenticated:", isAuthenticated)

    // if (!isAuthenticated) {
    //     console.log("🚀 ~ ProtectedRoute ~ isAuthenticated: inside if ~:~", isAuthenticated)

    //     return <Navigate to="/" replace />
    // }
    // return children

    if (!isAuthenticated) {
        // user is not authenticated
        return <Outlet />;
      }
      return children;

   
}

export default ProtectedRoute