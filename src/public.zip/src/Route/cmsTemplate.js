import { Outlet, useNavigate } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";
import AppNav from "../components/cms/AppNav";
import { useEffect } from "react";

function CmsTemplate() {
  const navigate = useNavigate();
  useEffect(() => {
    navigate('/cms_main')
  })
  return (
    <>
      <Header isCms />
      <AppNav />
      <Outlet />
      {/* <Footer /> */}
    </>
  );
}

export default CmsTemplate;
