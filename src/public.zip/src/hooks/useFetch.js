import { useState, useEffect } from 'react';
import axios from 'axios';

function useFetch(url) {
    const [increment, setIncrement] = useState(0);
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(null);
    const [error, setError] = useState(null);

    const reFetch = () => setIncrement((prev) => prev + 1)
    useEffect(() => {
        setLoading('loading...')
        setData(null);
        setError(null);
        const source = axios.CancelToken.source();
        const token = JSON.parse(localStorage.getItem('token'))[0]?.idToken;
        axios.get(url, {
            cancelToken: source.token, headers: {
                Authorization: token,
                'url':'cms'
            }
        })
            .then(res => {
                setLoading(false);
                res.data.data && setData(res.data.data);
                res.data && setData(res.data);
            })
            .catch(err => {
                setLoading(false)
                setError('An error occurred. Awkward..')
            })
        return () => {
            source.cancel();
        }
    }, [url, increment])

    return { data, loading, reFetch, error }
}
export default useFetch;