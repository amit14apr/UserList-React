import axios from "axios"

export const COCKPIT_BASE_URL = 'https://dev.cockpit.jnj.com/api/pages'


export const updateContent = async (url, payload) => {
    console.log("🚀 ~ updateContent ~ payload:", payload)
    const token = JSON.parse(localStorage.getItem('token'))[0].idToken;
    try {
        const result = await axios.put(`${COCKPIT_BASE_URL}/${url}`, payload,{
            headers: {
                Authorization: token,
                'url': 'cms'
            },
            
        })
        return result
    } catch (e) {
        console.log('Error occured', e)
    }
}

