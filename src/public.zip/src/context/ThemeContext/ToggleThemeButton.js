import React from "react";
import { useTheme } from "./index";

const ToggleThemeButton = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <div>
      <button
        onClick={() => toggleTheme("lightMode")}
        style={{
          width: "100px",
          margin: "5px",
          display: theme === "lightMode" ? "none" : "",
        }}
      >
        Light Mode
      </button>
      <button
        onClick={() => toggleTheme("midMode")}
        style={{
          width: "100px",
          margin: "5px",
          display: theme === "midMode" ? "none" : "",
        }}
      >
        Mid Mode
      </button>
      <button
        onClick={() => toggleTheme("darkMode")}
        style={{
          width: "100px",
          margin: "5px",
          display: theme === "darkMode" ? "none" : "",
        }}
      >
        Dark Mode
      </button>
    </div>
  );
};

export default ToggleThemeButton;
